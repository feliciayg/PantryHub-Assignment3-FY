# InventoryHub Demo Notes

InventoryHub is a lightweight inventory and expiry management app for small food-based teams such as cafes, bakeries, school canteens, mini marts, community food pantries, or small restaurants.

## Compatibility Notes

Some internal names are intentionally still legacy PantryHub names because the app is using the existing Firebase data model safely during the pivot:

- `FoodItem` still represents an inventory or stock item.
- `ShoppingItem` still represents a restock order item.
- `households/{householdId}/foods` still stores inventory items.
- `households/{householdId}/shoppingItems` still stores restock orders.
- Existing package, navigation, resource, and style names may still include `pantry`, `food`, `shopping`, or `household` when changing them would risk breaking generated bindings, navigation, or Firestore compatibility.

## Demo Data Cleanup

Do not delete Firebase records during normal app use. For a fresh demo later, it is safe to clear test records inside the selected test store/team only:

- `foods`
- `shoppingItems`
- `activityLogs`

Keep the store/team document, user profiles, members, and invite code so login, shared access, and team setup continue to work.

## Suggested Demo Flow

1. Sign in and show the shared store/team workspace.
2. Add a stock item with quantity, unit, expiry date, low-stock threshold, and optional supplier details.
3. Show Inventory Health, Expiring, Expired, Low Stock, Priority Today, and Inventory Insights on Home.
4. Create a restock order and move it through To Order, Ordered, In Transit, and Received.
5. Confirm inventory quantity only increases when the order is Received.
6. Export inventory CSV, import inventory CSV, then import a sales CSV to deduct sold quantities.
7. Show Activity History recording stock, restock, waste, and sales import actions.
