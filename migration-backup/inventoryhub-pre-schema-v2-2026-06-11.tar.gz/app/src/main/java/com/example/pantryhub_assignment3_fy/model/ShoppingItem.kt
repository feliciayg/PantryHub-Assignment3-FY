package com.example.pantryhub_assignment3_fy.model

data class ShoppingItem(
    val id: String = "",
    val name: String = "",
    val quantity: Double = 0.0,
    val unit: String = "",
    val status: String = ShoppingStatus.TO_ORDER.name,
    val sourceFoodItemId: String? = null,
    val addedBy: String = "",
    val updatedBy: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val orderedAt: Long = 0L,
    val inTransitAt: Long = 0L,
    val receivedAt: Long = 0L,
    val cancelledAt: Long = 0L,
    val sortOrder: Int = 0
)
