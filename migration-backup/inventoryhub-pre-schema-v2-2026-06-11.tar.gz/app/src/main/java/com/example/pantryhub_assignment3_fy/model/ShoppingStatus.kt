package com.example.pantryhub_assignment3_fy.model

enum class ShoppingStatus {
    TO_ORDER,
    ORDERED,
    IN_TRANSIT,
    RECEIVED,
    CANCELLED,
    TO_BUY,
    BOUGHT,
    STORED
}
