package com.example.pantryhub_assignment3_fy.ui.storage

import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.ShoppingItem

data class StorageUiState(
    val isLoading: Boolean = true,
    val foods: List<FoodItem> = emptyList(),
    val shoppingItems: List<ShoppingItem> = emptyList(),
    val visibleFoods: List<FoodItem> = emptyList(),
    val readyToStoreItems: List<ShoppingItem> = emptyList(),
    val selectedLocation: String = FilterOptions.ALL_LOCATION,
    val selectedCategory: String = FilterOptions.ALL_CATEGORY,
    val selectedStatus: String = FilterOptions.ALL_STATUS,
    val sortOption: SortOption = SortOption.EXPIRY_SOONEST,
    val searchQuery: String = "",
    val csvExportContent: String? = null,
    val csvSummaryTitle: String? = null,
    val csvSummaryMessage: String? = null,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

data class FoodFormData(
    val id: String = "",
    val name: String = "",
    val category: String = "",
    val storageLocation: String = "",
    val quantity: Double = 0.0,
    val unit: String = "",
    val lowStockThreshold: Double = 0.0,
    val addedDate: Long = 0L,
    val expiryDate: Long = 0L,
    val shelfLifeDays: Int = 0,
    val reminderDaysBefore: Int = 0,
    val notes: String = "",
    val supplierName: String = "",
    val supplierPhone: String = "",
    val supplierEmail: String = "",
    val imageUrl: String = ""
)

enum class SortOption(val label: String) {
    EXPIRY_SOONEST("Expiry Date: Soonest First"),
    EXPIRY_LATEST("Expiry Date: Latest First"),
    NAME_ASC("Name: A-Z"),
    NAME_DESC("Name: Z-A"),
    CATEGORY("Category"),
    QUANTITY_LOW("Quantity: Low to High"),
    RECENTLY_ADDED("Recently Added")
}

object FilterOptions {
    const val ALL_LOCATION = "All"
    const val ALL_CATEGORY = "All Categories"
    const val ALL_STATUS = "All"
    const val LOW_STOCK_STATUS = "Low Stock"

    val locations = listOf(ALL_LOCATION, "Inventory", "Fridge", "Freezer", "Crisper")
    val categories = listOf(ALL_CATEGORY, "Vegetable", "Dairy", "Drinks", "Meat", "Fruit", "Frozen", "Canned", "Snacks", "Other")
    // Used and Wasted are explicit filters for archived zero-stock items hidden from the default Storage list.
    val statuses = listOf(ALL_STATUS, "Fresh", "Priority Today", "Expiring Soon", "Expired", LOW_STOCK_STATUS, "Used", "Wasted")
    val units = listOf("pack", "g", "kg", "bottle", "can", "pcs", "ml", "L")
}
