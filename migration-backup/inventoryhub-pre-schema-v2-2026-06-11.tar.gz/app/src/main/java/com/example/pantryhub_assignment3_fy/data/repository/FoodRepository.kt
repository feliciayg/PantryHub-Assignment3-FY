package com.example.pantryhub_assignment3_fy.data.repository

import com.example.pantryhub_assignment3_fy.data.firebase.FirebaseAuthManager
import com.example.pantryhub_assignment3_fy.data.firebase.FirestoreDataSource
import com.example.pantryhub_assignment3_fy.model.ActivityActionType
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.model.UserProfile
import com.example.pantryhub_assignment3_fy.util.Constants
import com.example.pantryhub_assignment3_fy.util.FoodStatusCalculator
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.ListenerRegistration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Repository for the shared pantry food collection.
 *
 * All Firebase reads/writes for `households/{householdId}/foods` live here so
 * Fragments and ViewModels do not need to know Firestore paths or document mapping.
 */
class FoodRepository(
    private val authManager: FirebaseAuthManager = FirebaseAuthManager(),
    private val firestoreDataSource: FirestoreDataSource = FirestoreDataSource()
) {
    private val activityRepository = ActivityRepository(authManager, firestoreDataSource)

    /**
     * Streams live food updates for the signed-in user's current household.
     */
    fun observeFoods(): Flow<Result<List<FoodItem>>> = callbackFlow {
        val userProfile = currentUserProfile()
        val householdId = userProfile?.currentHouseholdId
        if (householdId.isNullOrBlank()) {
            trySend(Result.failure(IllegalStateException("No store selected.")))
            close()
            return@callbackFlow
        }

        // Food items are loaded only from the signed-in user's current household for shared pantry isolation.
        var migrationInProgress = false
        var registration: ListenerRegistration? = firestoreDataSource.db
            .collection(Constants.HOUSEHOLDS_COLLECTION)
            .document(householdId)
            .collection(Constants.FOODS_COLLECTION)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(Result.failure(error))
                    return@addSnapshotListener
                }

                val documents = snapshot?.documents.orEmpty()
                if (!migrationInProgress && documents.any { it.hasLegacyNumericDates() }) {
                    migrationInProgress = true
                    launch {
                        runCatching { migrateLegacyFoodDates(documents) }
                        migrationInProgress = false
                    }
                }

                val foods = documents
                    .map { it.toFoodItem() }
                    .map { food ->
                        val calculatedStatus = FoodStatusCalculator.calculate(food)
                        if (calculatedStatus.name == food.status) food else food.copy(status = calculatedStatus.name)
                    }
                trySend(Result.success(foods))
            }

        awaitClose {
            registration?.remove()
            registration = null
        }
    }

    /**
     * Reads one food document from the current household.
     */
    suspend fun getFood(foodId: String): Result<FoodItem> = runCatching {
        val householdId = currentHouseholdId()
        val snapshot = foodsCollection(householdId).document(foodId).get().await()
        if (!snapshot.exists()) error("Stock item not found.")
        snapshot.toFoodItem()
    }

    /**
     * Creates a new food document and writes an activity log for the action.
     */
    suspend fun addFood(input: FoodItem, restockedFromShopping: Boolean = false): Result<String> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val document = foodsCollection(householdId).document()
        val now = System.currentTimeMillis()
        val food = input.copy(
            id = document.id,
            shelfLifeDays = input.shelfLifeDays,
            status = FoodStatusCalculator.calculate(
                input.expiryDate,
                input.quantity,
                input.lowStockThreshold
            ).name,
            createdBy = userId,
            updatedBy = userId,
            createdAt = now,
            updatedAt = now
        )

        // Add creates a new food document below households/{householdId}/foods.
        document.set(food.toFirestoreMap()).await()
        activityRepository.addActivityLog(
            actionType = if (restockedFromShopping) ActivityActionType.RESTOCKED_FOOD else ActivityActionType.ADDED_FOOD,
            foodItemId = document.id,
            foodName = food.name,
            quantity = food.quantity,
            unit = food.unit,
            xpChange = if (restockedFromShopping) 10 else 10,
            note = if (restockedFromShopping) "Restocked from restock list" else "Added to inventory"
        ).getOrThrow()
        document.id
    }

    /**
     * Replaces an existing food document while preserving the original creator metadata.
     */
    suspend fun updateFood(food: FoodItem): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val existing = getFood(food.id).getOrThrow()
        val now = System.currentTimeMillis()
        val updated = food.copy(
            status = FoodStatusCalculator.calculate(food).name,
            createdBy = existing.createdBy.ifBlank { userId },
            createdAt = existing.createdAt.takeIf { it > 0L }
                ?: existing.updatedAt.takeIf { it > 0L }
                ?: now,
            updatedBy = userId,
            updatedAt = now
        )

        // Creator metadata is immutable; only updater metadata changes when food is edited.
        foodsCollection(householdId).document(food.id).set(updated.toFirestoreMap()).await()
    }

    /**
     * Adds quantity into an existing matching food item instead of creating a duplicate card.
     */
    suspend fun mergeFoodQuantity(existingFoodId: String, quantityToAdd: Double, restockedFromShopping: Boolean = false): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        require(quantityToAdd > 0.0) { "Quantity to add must be greater than 0." }
        val householdId = currentHouseholdId()
        val document = foodsCollection(householdId).document(existingFoodId)
        val now = System.currentTimeMillis()
        var mergedFood: FoodItem? = null

        // Duplicate merging runs in a Firestore transaction so two quick saves cannot overwrite
        // each other's quantity changes on the same existing food document.
        firestoreDataSource.db.runTransaction { transaction ->
            val existing = transaction.get(document).toFoodItem()
            val newQuantity = existing.quantity + quantityToAdd
            val updated = existing.copy(
                quantity = newQuantity,
                status = FoodStatusCalculator.calculate(existing.copy(quantity = newQuantity)).name,
                updatedBy = userId,
                updatedAt = now
            )
            transaction.set(document, updated.toFirestoreMap())
            mergedFood = updated
        }.await()

        val food = mergedFood ?: getFood(existingFoodId).getOrThrow()
        activityRepository.addActivityLog(
            actionType = if (restockedFromShopping) ActivityActionType.RESTOCKED_FOOD else ActivityActionType.ADDED_FOOD,
            foodItemId = food.id,
            foodName = food.name,
            quantity = quantityToAdd,
            unit = food.unit,
            xpChange = 10,
            note = if (restockedFromShopping) "Merged restock into existing inventory item" else "Merged duplicate inventory item"
        ).getOrThrow()
    }

    /**
     * Deletes one food document and records the deletion in the household activity log.
     */
    suspend fun deleteFood(foodId: String): Result<Unit> = runCatching {
        val householdId = currentHouseholdId()
        val food = getFood(foodId).getOrThrow()
        // Delete removes the food document from the household collection.
        foodsCollection(householdId).document(foodId).delete().await()
        activityRepository.addActivityLog(
            actionType = ActivityActionType.DELETED_FOOD,
            foodItemId = food.id,
            foodName = food.name,
            quantity = food.quantity,
            unit = food.unit,
            xpChange = 0,
            note = "Deleted from inventory"
        ).getOrThrow()
    }

    /**
     * Decreases food quantity when it is consumed and awards XP only if it was used by expiry.
     */
    suspend fun markUsed(foodId: String, quantityUsed: Double): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val food = getFood(foodId).getOrThrow()
        require(quantityUsed > 0) { "Quantity used must be greater than 0." }
        require(quantityUsed <= food.quantity) { "Quantity used cannot be more than current quantity." }

        val remaining = (food.quantity - quantityUsed).coerceAtLeast(0.0)
        val status = if (remaining == 0.0) {
            FoodStatus.USED
        } else {
            FoodStatusCalculator.calculate(food.copy(quantity = remaining))
        }

        // Mark used decreases stock; fully consumed food stays in history with USED status.
        foodsCollection(householdId).document(foodId)
            .update(
                mapOf(
                    "quantity" to remaining,
                    "status" to status.name,
                    "updatedBy" to userId,
                    "updatedAt" to Timestamp.now()
                )
            )
            .await()
        val usedBeforeOrOnExpiry = !LocalDate.now().isAfter(food.expiryLocalDate())
        activityRepository.addActivityLog(
            actionType = ActivityActionType.USED_FOOD,
            foodItemId = food.id,
            foodName = food.name,
            quantity = quantityUsed,
            unit = food.unit,
            xpChange = if (usedBeforeOrOnExpiry) 30 else 0,
            note = if (usedBeforeOrOnExpiry) "Used before expiry" else "Used after expiry"
        ).getOrThrow()
    }

    suspend fun deductSalesImport(foodId: String, quantitySold: Double, note: String? = null): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val document = foodsCollection(householdId).document(foodId)
        val now = System.currentTimeMillis()
        var updatedFood: FoodItem? = null

        require(quantitySold > 0.0) { "Quantity sold must be greater than 0." }
        firestoreDataSource.db.runTransaction { transaction ->
            val food = transaction.get(document).toFoodItem()
            require(quantitySold <= food.quantity) { "Quantity sold cannot reduce stock below 0." }
            val remaining = (food.quantity - quantitySold).coerceAtLeast(0.0)
            val updated = food.copy(
                quantity = remaining,
                status = if (remaining == 0.0) {
                    FoodStatus.USED.name
                } else {
                    FoodStatusCalculator.calculate(food.copy(quantity = remaining)).name
                },
                updatedBy = userId,
                updatedAt = now
            )

            // Sales CSV deduction is transactional so sold quantity cannot push stock negative.
            transaction.set(document, updated.toFirestoreMap())
            updatedFood = updated
        }.await()

        val food = updatedFood ?: getFood(foodId).getOrThrow()
        activityRepository.addActivityLog(
            actionType = ActivityActionType.USED_FOOD,
            foodItemId = food.id,
            foodName = food.name,
            quantity = quantitySold,
            unit = food.unit,
            xpChange = 0,
            note = listOfNotNull("Sales import deducted ${quantitySold.toCleanString()} ${food.unit}", note?.takeIf { it.isNotBlank() })
                .joinToString(" - ")
        ).getOrThrow()
    }

    /**
     * Decreases food quantity for waste, stores the reason, and keeps XP unchanged.
     */
    suspend fun logWaste(foodId: String, quantityWasted: Double, reason: String): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val food = getFood(foodId).getOrThrow()
        require(reason.isNotBlank()) { "Waste reason is required." }
        require(quantityWasted > 0) { "Quantity wasted must be greater than 0." }
        require(quantityWasted <= food.quantity) { "Quantity wasted cannot be more than current quantity." }

        val remaining = (food.quantity - quantityWasted).coerceAtLeast(0.0)
        val status = if (remaining == 0.0) {
            FoodStatus.WASTED
        } else {
            FoodStatusCalculator.calculate(food.copy(quantity = remaining))
        }
        val existingNotes = food.notes.trim()
        val wasteNote = "Waste logged: $quantityWasted ${food.unit} ($reason)"
        val notes = if (existingNotes.isBlank()) wasteNote else "$existingNotes\n$wasteNote"

        // Log waste decreases stock and records the reason in notes until the Activity Log module exists.
        foodsCollection(householdId).document(foodId)
            .update(
                mapOf(
                    "quantity" to remaining,
                    "status" to status.name,
                    "notes" to notes,
                    "updatedBy" to userId,
                    "updatedAt" to Timestamp.now()
                )
            )
            .await()
        activityRepository.addActivityLog(
            actionType = ActivityActionType.WASTED_FOOD,
            foodItemId = food.id,
            foodName = food.name,
            quantity = quantityWasted,
            unit = food.unit,
            xpChange = 0,
            note = reason
        ).getOrThrow()
    }

    private suspend fun currentHouseholdId(): String {
        return currentUserProfile()?.currentHouseholdId ?: error("No store selected.")
    }

    private suspend fun currentUserProfile(): UserProfile? {
        val uid = authManager.currentUserId ?: return null
        val snapshot = firestoreDataSource.db.collection(Constants.USERS_COLLECTION)
            .document(uid)
            .get()
            .await()
        return snapshot.toObject(UserProfile::class.java)
    }

    private fun foodsCollection(householdId: String) =
        firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION)
            .document(householdId)
            .collection(Constants.FOODS_COLLECTION)

    /**
     * Converts a Firestore document into the app's FoodItem model.
     */
    private fun DocumentSnapshot.toFoodItem(): FoodItem {
        return FoodItem(
            id = getString("id").orEmpty().ifBlank { id },
            name = getString("name").orEmpty(),
            category = getString("category").orEmpty(),
            storageLocation = getString("storageLocation").orEmpty(),
            quantity = number("quantity")?.toDouble() ?: 0.0,
            unit = getString("unit").orEmpty(),
            lowStockThreshold = number("lowStockThreshold")?.toDouble() ?: 0.0,
            addedDate = dateMillis("addedDate"),
            expiryDate = dateMillis("expiryDate"),
            shelfLifeDays = number("shelfLifeDays")?.toInt() ?: 0,
            reminderDaysBefore = number("reminderDaysBefore")?.toInt() ?: 0,
            notes = getString("notes").orEmpty(),
            supplierName = getString("supplierName").orEmpty(),
            supplierPhone = getString("supplierPhone").orEmpty(),
            supplierEmail = getString("supplierEmail").orEmpty(),
            imageUrl = getString("imageUrl").orEmpty(),
            status = getString("status").orEmpty().ifBlank { FoodStatus.FRESH.name },
            createdBy = getString("createdBy").orEmpty(),
            updatedBy = getString("updatedBy").orEmpty(),
            createdAt = dateMillis("createdAt"),
            updatedAt = dateMillis("updatedAt")
        )
    }

    private fun FoodItem.toFirestoreMap(): Map<String, Any> = mapOf(
        "id" to id,
        "name" to name,
        "category" to category,
        "storageLocation" to storageLocation,
        "quantity" to quantity,
        "unit" to unit,
        "lowStockThreshold" to lowStockThreshold,
        "addedDate" to addedDate.toFirestoreDateValue(),
        "expiryDate" to expiryDate.toFirestoreDateValue(),
        "shelfLifeDays" to shelfLifeDays,
        "reminderDaysBefore" to reminderDaysBefore,
        "notes" to notes,
        "supplierName" to supplierName,
        "supplierPhone" to supplierPhone,
        "supplierEmail" to supplierEmail,
        "imageUrl" to imageUrl,
        "status" to status,
        "createdBy" to createdBy,
        "updatedBy" to updatedBy,
        "createdAt" to createdAt.toFirestoreDateValue(),
        "updatedAt" to updatedAt.toFirestoreDateValue()
    )

    /**
     * Converts older numeric date fields into Firestore Timestamp values without changing UI behavior.
     */
    private suspend fun migrateLegacyFoodDates(documents: List<DocumentSnapshot>) {
        val batch = firestoreDataSource.db.batch()
        var hasUpdates = false

        documents.forEach { document ->
            val updates = mutableMapOf<String, Any>()
            FOOD_DATE_FIELDS.forEach { field ->
                val value = document.get(field)
                if (value is Number && value.toLong() > 0L) {
                    updates[field] = value.toLong().toFirestoreDateValue()
                }
            }
            if (document.dateMillis("createdAt") <= 0L) {
                val bestCreatedAt = document.dateMillis("updatedAt")
                    .takeIf { it > 0L }
                    ?: document.dateMillis("addedDate").takeIf { it > 0L }
                if (bestCreatedAt != null) updates["createdAt"] = bestCreatedAt.toFirestoreDateValue()
            }
            if (document.dateMillis("updatedAt") <= 0L) {
                val bestUpdatedAt = document.dateMillis("createdAt")
                    .takeIf { it > 0L }
                    ?: document.dateMillis("addedDate").takeIf { it > 0L }
                if (bestUpdatedAt != null) updates["updatedAt"] = bestUpdatedAt.toFirestoreDateValue()
            }
            if (updates.isNotEmpty()) {
                batch.update(document.reference, updates)
                hasUpdates = true
            }
        }

        if (hasUpdates) batch.commit().await()
    }

    private fun DocumentSnapshot.hasLegacyNumericDates(): Boolean =
        FOOD_DATE_FIELDS.any { field ->
            val value = get(field)
            value is Number && value.toLong() > 0L
        } || dateMillis("createdAt") <= 0L && (
            dateMillis("updatedAt") > 0L || dateMillis("addedDate") > 0L
        ) || dateMillis("updatedAt") <= 0L && (
            dateMillis("createdAt") > 0L || dateMillis("addedDate") > 0L
        )

    private fun DocumentSnapshot.dateMillis(field: String): Long =
        when (val value = get(field)) {
            is Timestamp -> value.toDate().time
            is Number -> value.toLong()
            else -> 0L
        }

    private fun Long.toFirestoreDateValue(): Any =
        if (this > 0L) Timestamp(Date(this)) else this

    private fun DocumentSnapshot.number(field: String): Number? = get(field) as? Number

    private fun FoodItem.expiryLocalDate(): LocalDate =
        Instant.ofEpochMilli(expiryDate).atZone(ZoneId.systemDefault()).toLocalDate()

    private fun Double.toCleanString(): String = if (this % 1.0 == 0.0) toInt().toString() else toString()

    private companion object {
        val FOOD_DATE_FIELDS = listOf("addedDate", "expiryDate", "createdAt", "updatedAt")
    }
}
