package com.example.pantryhub_assignment3_fy.ui.activity

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.ItemActivityLogBinding
import com.example.pantryhub_assignment3_fy.model.ActivityActionType
import com.example.pantryhub_assignment3_fy.model.ActivityLog
import java.util.concurrent.TimeUnit

class ActivityAdapter : ListAdapter<ActivityLog, ActivityAdapter.ActivityViewHolder>(ActivityDiff) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActivityViewHolder {
        return ActivityViewHolder(
            ItemActivityLogBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ActivityViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ActivityViewHolder(
        private val binding: ItemActivityLogBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(log: ActivityLog) {
            val context = binding.root.context
            val positive = log.xpChange > 0
            val negative = log.actionType == ActivityActionType.WASTED_FOOD.name || log.actionType == ActivityActionType.DELETED_FOOD.name || log.looksExpired()
            val accentColor = when {
                positive -> ContextCompat.getColor(context, R.color.pantry_green)
                negative -> ContextCompat.getColor(context, R.color.pantry_coral)
                else -> ContextCompat.getColor(context, R.color.pantry_text_secondary)
            }
            val backgroundColor = when {
                positive -> ContextCompat.getColor(context, R.color.pantry_green_light)
                negative -> ContextCompat.getColor(context, R.color.pantry_coral_light)
                else -> ContextCompat.getColor(context, R.color.image_placeholder)
            }

            binding.foodNameTextView.text = log.foodName.ifBlank { "Inventory activity" }
            binding.descriptionTextView.text = "${log.description()} • ${log.relativeDate()}"
            binding.xpTextView.text = if (log.xpChange > 0) "Positive" else "Logged"
            binding.xpTextView.setTextColor(accentColor)
            binding.iconContainer.backgroundTintList = ColorStateList.valueOf(backgroundColor)
            binding.activityIcon.setColorFilter(accentColor)
            binding.activityIcon.setImageResource(log.iconRes())
        }

        private fun ActivityLog.description(): String {
            return when (actionType) {
                ActivityActionType.ADDED_FOOD.name -> "Added to inventory"
                ActivityActionType.USED_FOOD.name -> note ?: "Used before expiry"
                ActivityActionType.WASTED_FOOD.name -> quantityText()
                    ?.let { "Logged $it as wasted" }
                    ?: "Logged as wasted"
                ActivityActionType.RESTOCKED_FOOD.name -> "Restocked from restock list"
                ActivityActionType.ADDED_SHOPPING_ITEM.name -> "Added to restock list"
                ActivityActionType.BOUGHT_SHOPPING_ITEM.name -> "Received from restock list"
                ActivityActionType.DELETED_FOOD.name -> "Deleted from inventory"
                else -> note ?: "Inventory update"
            }
        }

        private fun ActivityLog.quantityText(): String? {
            val amount = quantity ?: return null
            val unitLabel = unit.orEmpty().trim()
            return if (unitLabel.isBlank()) amount.toCleanString() else "${amount.toCleanString()} $unitLabel"
        }

        private fun Double.toCleanString(): String {
            return if (this % 1.0 == 0.0) toInt().toString() else toString()
        }

        private fun ActivityLog.iconRes(): Int {
            return when (actionType) {
                ActivityActionType.WASTED_FOOD.name,
                ActivityActionType.DELETED_FOOD.name -> R.drawable.ic_delete
                ActivityActionType.RESTOCKED_FOOD.name,
                ActivityActionType.ADDED_FOOD.name -> R.drawable.ic_storage
                else -> R.drawable.ic_activity
            }
        }

        private fun ActivityLog.relativeDate(): String {
            val days = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - timestamp).toInt()
            return when {
                days <= 0 -> "Today"
                days == 1 -> "Yesterday"
                else -> "$days days ago"
            }
        }

        private fun ActivityLog.looksExpired(): Boolean {
            return note?.contains("expired", ignoreCase = true) == true || actionType == "EXPIRED"
        }
    }
}

private object ActivityDiff : DiffUtil.ItemCallback<ActivityLog>() {
    override fun areItemsTheSame(oldItem: ActivityLog, newItem: ActivityLog): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: ActivityLog, newItem: ActivityLog): Boolean = oldItem == newItem
}
