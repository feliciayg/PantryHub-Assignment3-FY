package com.example.pantryhub_assignment3_fy.ui.calendar

import com.example.pantryhub_assignment3_fy.model.FoodItem
import java.time.LocalDate
import java.time.YearMonth

data class CalendarUiState(
    val isLoading: Boolean = true,
    val visibleMonth: YearMonth = YearMonth.now(),
    val selectedDate: LocalDate = LocalDate.now(),
    val monthDays: List<CalendarDayUi> = emptyList(),
    val selectedDateFoods: List<FoodItem> = emptyList(),
    val upcomingWeekFoods: List<FoodItem> = emptyList(),
    val hasExpiryItems: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

data class CalendarDayUi(
    val date: LocalDate,
    val isInVisibleMonth: Boolean,
    val isToday: Boolean,
    val isSelected: Boolean,
    val marker: CalendarMarker = CalendarMarker.NONE
)

enum class CalendarMarker {
    NONE,
    UPCOMING,
    AMBER,
    RED
}
