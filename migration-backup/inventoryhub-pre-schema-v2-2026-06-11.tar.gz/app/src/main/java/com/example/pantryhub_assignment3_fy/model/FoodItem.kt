package com.example.pantryhub_assignment3_fy.model

data class FoodItem(
    val id: String = "",
    val name: String = "",
    val category: String = "",
    val storageLocation: String = "",
    val quantity: Double = 0.0,
    val unit: String = "",
    val lowStockThreshold: Double = 0.0,
    val addedDate: Long = 0L,
    val expiryDate: Long = 0L,
    val shelfLifeDays: Int = 0,
    val reminderDaysBefore: Int = 0,
    val notes: String = "",
    val supplierName: String = "",
    val supplierPhone: String = "",
    val supplierEmail: String = "",
    val imageUrl: String = "",
    val status: String = FoodStatus.FRESH.name,
    val createdBy: String = "",
    val updatedBy: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
)
