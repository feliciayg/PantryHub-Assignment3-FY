package com.example.pantryhub_assignment3_fy.ui.activity

import com.example.pantryhub_assignment3_fy.model.ActivityLog

data class ActivityUiState(
    val isLoading: Boolean = true,
    val logs: List<ActivityLog> = emptyList(),
    val visibleLogs: List<ActivityLog> = emptyList(),
    val selectedFilter: ActivityFilter = ActivityFilter.ALL,
    val selectedSort: ActivitySortOption = ActivitySortOption.NEWEST_FIRST,
    val selectedDateRange: ActivityDateRange = ActivityDateRange.LAST_30_DAYS,
    val customStartDate: Long? = null,
    val customEndDate: Long? = null,
    val savedCount: Int = 0,
    val wastedCount: Int = 0,
    val expiredFoodCount: Int = 0,
    val wasteRate: Int = 0,
    val errorMessage: String? = null
)

enum class ActivityFilter(val label: String) {
    ALL("All"),
    ADDED_FOOD("Added Stock"),
    USED("Used"),
    WASTED("Wasted"),
    RESTOCKED("Restocked"),
    ADDED_SHOPPING_ITEM("Added Restock"),
    BOUGHT_SHOPPING_ITEM("Received Restock"),
    DELETED_FOOD("Deleted Stock")
}

enum class ActivitySortOption(val label: String) {
    NEWEST_FIRST("Newest first"),
    OLDEST_FIRST("Oldest first"),
    XP_GAINED_FIRST("Positive movement first"),
    WASTED_FIRST("Wasted first"),
    EXPIRED_FIRST("Expired first")
}

enum class ActivityDateRange(val label: String) {
    ALL_TIME("All time"),
    TODAY("Today"),
    LAST_7_DAYS("Last 7 days"),
    LAST_30_DAYS("Last 30 days"),
    CUSTOM("Custom range")
}
