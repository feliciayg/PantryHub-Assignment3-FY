package com.example.pantryhub_assignment3_fy.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.FragmentLoginBinding
import com.example.pantryhub_assignment3_fy.util.UiState
import com.google.android.material.snackbar.Snackbar

class LoginFragment : Fragment() {
    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AuthViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.loginButton.setOnClickListener {
            clearErrors()
            if (!validateForm()) return@setOnClickListener
            viewModel.login(
                binding.usernameEditText.text.toString(),
                binding.passwordEditText.text.toString()
            )
        }

        viewModel.authState.observe(viewLifecycleOwner) { state ->
            renderState(state)
        }
    }

    private fun renderState(state: UiState<com.example.pantryhub_assignment3_fy.model.UserProfile>) {
        val isLoading = state is UiState.Loading
        binding.loginButton.isEnabled = !isLoading
        binding.loginButton.text = getString(if (isLoading) R.string.logging_in else R.string.login)
        when (state) {
            is UiState.Error -> Snackbar.make(binding.root, state.message, Snackbar.LENGTH_LONG).show()
            is UiState.Success -> {
                // Login routes users based on whether their profile is already linked to a household.
                if (state.data.currentHouseholdId.isNullOrBlank()) {
                    findNavController().navigate(R.id.action_loginFragment_to_householdSetupFragment)
                } else {
                    findNavController().navigate(R.id.action_global_homeFragment)
                }
            }
            else -> Unit
        }
    }

    private fun validateForm(): Boolean {
        var isValid = true
        val username = binding.usernameEditText.text.toString().trim()
        val password = binding.passwordEditText.text.toString()

        // Local validation marks the exact field in red before Firebase receives the request.
        if (username.isBlank()) {
            binding.usernameLayout.error = getString(R.string.username_required)
            isValid = false
        }
        if (password.isBlank()) {
            binding.passwordLayout.error = getString(R.string.password_required)
            isValid = false
        }
        return isValid
    }

    private fun clearErrors() {
        binding.usernameLayout.error = null
        binding.passwordLayout.error = null
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
