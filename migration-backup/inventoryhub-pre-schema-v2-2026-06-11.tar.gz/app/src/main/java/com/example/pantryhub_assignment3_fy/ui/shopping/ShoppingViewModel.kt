package com.example.pantryhub_assignment3_fy.ui.shopping

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantryhub_assignment3_fy.data.repository.FoodRepository
import com.example.pantryhub_assignment3_fy.data.repository.ShoppingRepository
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.model.ShoppingStatus
import com.example.pantryhub_assignment3_fy.util.update
import kotlinx.coroutines.launch

/**
 * Coordinates the Restock page.
 *
 * Restock data still comes from ShoppingRepository for now, while restock suggestions
 * are derived from FoodRepository so low-stock inventory items can become restock tasks.
 */
class ShoppingViewModel(
    private val shoppingRepository: ShoppingRepository = ShoppingRepository(),
    private val foodRepository: FoodRepository = FoodRepository()
) : ViewModel() {
    private val _uiState = MutableLiveData(ShoppingUiState())
    val uiState: LiveData<ShoppingUiState> = _uiState

    private var latestFoods: List<FoodItem> = emptyList()

    init {
        observeShoppingItems()
        observeFoods()
    }

    /**
     * Filters active, received, and suggestion sections by text.
     */
    fun search(query: String) {
        _uiState.update {
            val next = it.copy(searchQuery = query)
            deriveSections(next)
        }
    }

    /**
     * Switches between All, To Order, Received, and Low Stock views.
     */
    fun filter(filter: ShoppingFilter) {
        _uiState.update {
            val next = it.copy(selectedFilter = filter)
            deriveSections(next)
        }
    }

    /**
     * Creates a manually entered restock item.
     */
    fun addItem(form: ShoppingFormData) {
        viewModelScope.launch {
            shoppingRepository.addShoppingItem(form.name, form.quantity, form.unit, form.sourceFoodItemId)
                .onSuccess { showSuccess("Restock item added.") }
                .onFailure { showError(it.message ?: "Could not add restock item.") }
        }
    }

    /**
     * Saves edits from the restock item bottom sheet.
     */
    fun updateItem(form: ShoppingFormData) {
        val existing = (_uiState.value ?: ShoppingUiState()).shoppingItems.firstOrNull { it.id == form.id } ?: return
        viewModelScope.launch {
            shoppingRepository.updateShoppingItem(
                existing.copy(
                    name = form.name,
                    quantity = form.quantity,
                    unit = form.unit
                )
            )
                .onSuccess { showSuccess("Restock item updated.") }
                .onFailure { showError(it.message ?: "Could not update restock item.") }
        }
    }

    /**
     * Deletes a restock item from Firestore.
     */
    fun deleteItem(itemId: String) {
        viewModelScope.launch {
            shoppingRepository.deleteShoppingItem(itemId)
                .onSuccess { showSuccess("Restock item deleted.") }
                .onFailure { showError(it.message ?: "Could not delete restock item.") }
        }
    }

    fun advanceRestockStatus(itemId: String) {
        viewModelScope.launch {
            shoppingRepository.advanceRestockStatus(itemId)
                .onSuccess { status -> showSuccess(status.successMessage()) }
                .onFailure { showError(it.message ?: "Could not update restock order.") }
        }
    }

    fun cancelRestockOrder(itemId: String) {
        viewModelScope.launch {
            shoppingRepository.cancelRestockOrder(itemId)
                .onSuccess { showSuccess("Restock order cancelled.") }
                .onFailure { showError(it.message ?: "Could not cancel restock order.") }
        }
    }

    /**
     * Saves drag-and-drop order changes for active restock items.
     */
    fun reorderActiveItems(orderedItems: List<ShoppingItem>) {
        if (orderedItems.isEmpty()) return
        // The UI reorders optimistically first; this saves the final dropped order to Firestore.
        viewModelScope.launch {
            shoppingRepository.updateShoppingOrder(orderedItems)
                .onFailure { showError(it.message ?: "Could not update restock order.") }
        }
    }

    /**
     * Turns a low-stock inventory suggestion into a restock item.
     */
    fun addSuggestion(food: FoodItem) {
        viewModelScope.launch {
            shoppingRepository.addShoppingItem(food.name, food.lowStockThreshold.coerceAtLeast(1.0), food.unit, food.id)
                .onSuccess { showSuccess("Restock suggestion added.") }
                .onFailure { showError(it.message ?: "Could not add suggestion.") }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }

    private fun observeShoppingItems() {
        viewModelScope.launch {
            shoppingRepository.observeShoppingItems().collect { result ->
                result
                    .onSuccess { items ->
                        _uiState.update {
                            val next = it.copy(isLoading = false, shoppingItems = items, errorMessage = null)
                            deriveSections(next)
                        }
                    }
                    .onFailure { throwable ->
                        _uiState.update {
                            it.copy(isLoading = false, errorMessage = throwable.message ?: "Could not load restock list.")
                        }
                    }
            }
        }
    }

    private fun observeFoods() {
        viewModelScope.launch {
            foodRepository.observeFoods().collect { result ->
                result
                    .onSuccess { foods ->
                        latestFoods = foods
                        _uiState.update { deriveSections(it.copy(errorMessage = null)) }
                    }
                    .onFailure { throwable ->
                        _uiState.update { it.copy(errorMessage = throwable.message ?: "Could not load restock suggestions.") }
                    }
            }
        }
    }

    /**
     * Splits raw restock/inventory data into the three lists displayed by the Restock page.
     */
    private fun deriveSections(state: ShoppingUiState): ShoppingUiState {
        val query = state.searchQuery.trim()
        val active = state.shoppingItems
            .filter { it.isActiveRestockOrder() }
            .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
            .sortedWith(compareBy<ShoppingItem> { it.sortOrder }.thenBy { it.name.lowercase() })
        val bought = ShoppingSectionRules.boughtReadyToStoreItems(state.shoppingItems, query)
        val suggestions = latestFoods
            .filter { it.isRestockCandidate() }
            .filterNot { food -> state.shoppingItems.any { it.blocksSuggestionFor(food) } }
            .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
            .sortedBy { it.name.lowercase() }

        return when (state.selectedFilter) {
            ShoppingFilter.ALL -> state.copy(activeItems = active, boughtItems = bought, suggestedFoods = suggestions)
            ShoppingFilter.TO_BUY -> state.copy(activeItems = active, boughtItems = emptyList(), suggestedFoods = emptyList())
            ShoppingFilter.BOUGHT -> state.copy(activeItems = emptyList(), boughtItems = bought, suggestedFoods = emptyList())
            ShoppingFilter.LOW_STOCK -> state.copy(activeItems = emptyList(), boughtItems = emptyList(), suggestedFoods = suggestions)
        }
    }

    private fun ShoppingItem.blocksSuggestionFor(food: FoodItem): Boolean {
        if (!isActiveRestockOrder() && status != ShoppingStatus.RECEIVED.name) return false
        val linkedToFood = !sourceFoodItemId.isNullOrBlank() && sourceFoodItemId == food.id
        val sameRestockName = name.normalizedName() == food.name.normalizedName()

        // Source id is the strongest match, but a normalized name match prevents manual entries
        // like "grape" and stored foods like "grapes" from appearing as separate restock tasks.
        return linkedToFood || sameRestockName
    }

    private fun FoodItem.isRestockCandidate(): Boolean {
        val isFullyUsed = status == FoodStatus.USED.name && quantity <= 0.0
        val isActiveLowStock = status != FoodStatus.WASTED.name && quantity <= lowStockThreshold

        // Used-up food should still be suggested for restock, but wasted items are kept out of
        // shopping suggestions because they represent discarded stock rather than normal usage.
        return isFullyUsed || isActiveLowStock
    }

    private fun String.normalizedName(): String {
        val compactName = trim()
            .lowercase()
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // This lightweight singular form prevents common duplicate suggestions like grape/grapes.
        return compactName.split(" ").joinToString(" ") { word ->
            when {
                word.endsWith("ies") && word.length > 3 -> word.dropLast(3) + "y"
                word.endsWith("oes") && word.length > 3 -> word.dropLast(2)
                word.endsWith("ses") || word.endsWith("xes") || word.endsWith("ches") || word.endsWith("shes") -> word.dropLast(2)
                word.endsWith("s") && word.length > 1 -> word.dropLast(1)
                else -> word
            }
        }
    }

    private fun ShoppingItem.isActiveRestockOrder(): Boolean {
        return status == ShoppingStatus.TO_ORDER.name ||
            status == ShoppingStatus.ORDERED.name ||
            status == ShoppingStatus.IN_TRANSIT.name
    }

    private fun ShoppingStatus.successMessage(): String {
        return when (this) {
            ShoppingStatus.ORDERED -> "Restock order marked ordered."
            ShoppingStatus.IN_TRANSIT -> "Restock order marked in transit."
            ShoppingStatus.RECEIVED -> "Restock order received."
            else -> "Restock order updated."
        }
    }

    private fun showSuccess(message: String) {
        _uiState.update { it.copy(successMessage = message) }
    }

    private fun showError(message: String) {
        _uiState.update { it.copy(errorMessage = message) }
    }
}
