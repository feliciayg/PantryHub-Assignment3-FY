package com.example.pantryhub_assignment3_fy.data.repository

import com.example.pantryhub_assignment3_fy.data.firebase.FirebaseAuthManager
import com.example.pantryhub_assignment3_fy.data.firebase.FirestoreDataSource
import com.example.pantryhub_assignment3_fy.model.ActivityActionType
import com.example.pantryhub_assignment3_fy.model.ActivityLog
import com.example.pantryhub_assignment3_fy.model.UserProfile
import com.example.pantryhub_assignment3_fy.util.Constants
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.util.Date
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Repository for household activity history.
 *
 * Activity logs are append-only records under
 * `households/{householdId}/activityLogs` and are used by the Activity page,
 * Kitchen Level XP, and household history.
 */
class ActivityRepository(
    private val authManager: FirebaseAuthManager = FirebaseAuthManager(),
    private val firestoreDataSource: FirestoreDataSource = FirestoreDataSource()
) {
    /**
     * Streams household activity logs in newest-first order.
     */
    fun observeActivityLogs(): Flow<Result<List<ActivityLog>>> = callbackFlow {
        val userProfile = currentUserProfile()
        val householdId = userProfile?.currentHouseholdId
        if (householdId.isNullOrBlank()) {
            trySend(Result.failure(IllegalStateException("No store selected.")))
            close()
            return@callbackFlow
        }

        var migrationInProgress = false
        var registration: ListenerRegistration? = activityCollection(householdId)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(Result.failure(error))
                    return@addSnapshotListener
                }

                val documents = snapshot?.documents.orEmpty()
                if (!migrationInProgress && documents.any { it.hasLegacyNumericTimestamp() }) {
                    migrationInProgress = true
                    launch {
                        runCatching { migrateLegacyActivityTimestamps(documents) }
                        migrationInProgress = false
                    }
                }

                trySend(Result.success(documents.map { it.toActivityLog() }))
            }

        awaitClose {
            registration?.remove()
            registration = null
        }
    }

    /**
     * Inserts one activity record after inventory or restock actions complete successfully.
     */
    suspend fun addActivityLog(
        actionType: ActivityActionType,
        foodItemId: String?,
        foodName: String,
        quantity: Double?,
        unit: String?,
        xpChange: Int,
        note: String? = null
    ): Result<String> = runCatching {
        val userProfile = currentUserProfile() ?: error("You must be logged in.")
        val householdId = userProfile.currentHouseholdId ?: error("No store selected.")
        val document = activityCollection(householdId).document()
        val log = ActivityLog(
            id = document.id,
            actionType = actionType.name,
            foodItemId = foodItemId,
            foodName = foodName.trim(),
            quantity = quantity,
            unit = unit?.trim(),
            userId = userProfile.userId,
            userName = userProfile.displayName.ifBlank { userProfile.username },
            timestamp = System.currentTimeMillis(),
            xpChange = xpChange,
            note = note?.trim()?.takeIf { it.isNotBlank() }
        )

        document.set(log.toFirestoreMap()).await()
        document.id
    }

    private suspend fun currentUserProfile(): UserProfile? {
        val uid = authManager.currentUserId ?: return null
        val snapshot = firestoreDataSource.db.collection(Constants.USERS_COLLECTION)
            .document(uid)
            .get()
            .await()
        return snapshot.toObject(UserProfile::class.java)
    }

    private fun activityCollection(householdId: String) =
        firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION)
            .document(householdId)
            .collection(Constants.ACTIVITY_LOGS_COLLECTION)

    /**
     * Maps Firestore fields into an ActivityLog used by adapters and ViewModels.
     */
    private fun DocumentSnapshot.toActivityLog(): ActivityLog {
        return ActivityLog(
            id = getString("id").orEmpty().ifBlank { id },
            actionType = getString("actionType").orEmpty(),
            foodItemId = getString("foodItemId"),
            foodName = getString("foodName").orEmpty(),
            quantity = number("quantity")?.toDouble(),
            unit = getString("unit"),
            userId = getString("userId").orEmpty(),
            userName = getString("userName").orEmpty(),
            timestamp = dateMillis("timestamp"),
            xpChange = number("xpChange")?.toInt() ?: 0,
            note = getString("note")
        )
    }

    private fun ActivityLog.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "actionType" to actionType,
        "foodItemId" to foodItemId,
        "foodName" to foodName,
        "quantity" to quantity,
        "unit" to unit,
        "userId" to userId,
        "userName" to userName,
        "timestamp" to timestamp.toFirestoreDateValue(),
        "xpChange" to xpChange,
        "note" to note
    )

    /**
     * Updates old millisecond timestamp values to Firestore Timestamp values.
     */
    private suspend fun migrateLegacyActivityTimestamps(documents: List<DocumentSnapshot>) {
        val batch = firestoreDataSource.db.batch()
        var hasUpdates = false

        documents.forEach { document ->
            val value = document.get("timestamp")
            if (value is Number && value.toLong() > 0L) {
                batch.update(document.reference, "timestamp", value.toLong().toFirestoreDateValue())
                hasUpdates = true
            }
        }

        if (hasUpdates) batch.commit().await()
    }

    private fun DocumentSnapshot.hasLegacyNumericTimestamp(): Boolean {
        val value = get("timestamp")
        return value is Number && value.toLong() > 0L
    }

    private fun DocumentSnapshot.dateMillis(field: String): Long =
        when (val value = get(field)) {
            is Timestamp -> value.toDate().time
            is Number -> value.toLong()
            else -> 0L
        }

    private fun Long.toFirestoreDateValue(): Any =
        if (this > 0L) Timestamp(Date(this)) else this

    private fun DocumentSnapshot.number(field: String): Number? = get(field) as? Number
}
