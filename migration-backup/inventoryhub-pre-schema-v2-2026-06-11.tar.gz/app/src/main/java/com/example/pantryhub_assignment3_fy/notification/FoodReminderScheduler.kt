package com.example.pantryhub_assignment3_fy.notification

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.util.AppPreferences
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId

/**
 * Schedules local device reminders for food expiry dates.
 *
 * This uses AlarmManager on the current phone only. Firestore stores the food data,
 * but each member's device schedules its own reminders after loading that data.
 */
object FoodReminderScheduler {
    const val CHANNEL_ID = "food_expiry_reminders"
    const val EXTRA_FOOD_ID = "extra_food_id"
    const val EXTRA_FOOD_NAME = "extra_food_name"
    const val EXTRA_EXPIRY_DATE = "extra_expiry_date"
    private const val REMINDER_HOUR = 9

    /**
     * Creates the notification channel required before Android can show expiry reminders.
     */
    fun ensureNotificationChannel(context: Context) {
        val notificationManager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.food_reminder_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = context.getString(R.string.food_reminder_channel_description)
        }
        notificationManager.createNotificationChannel(channel)
    }

    /**
     * Schedules or replaces one reminder alarm for a food item.
     */
    fun schedule(context: Context, food: FoodItem) {
        if (!AppPreferences.expiryRemindersEnabled(context)) {
            cancel(context, food.id)
            return
        }

        if (!food.canHaveReminder()) {
            cancel(context, food.id)
            return
        }

        val reminderAt = calculateReminderTimeMillis(food)
        if (reminderAt <= System.currentTimeMillis()) {
            cancel(context, food.id)
            return
        }

        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, FoodReminderReceiver::class.java).apply {
            putExtra(EXTRA_FOOD_ID, food.id)
            putExtra(EXTRA_FOOD_NAME, food.name)
            putExtra(EXTRA_EXPIRY_DATE, food.expiryDate)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            food.stableReminderRequestCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // AlarmManager stores the reminder locally on this device. Reusing the same request code
        // replaces older reminders for the same food after the user edits the expiry/reminder date.
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderAt, pendingIntent)
    }

    /**
     * Rebuilds reminder alarms for all currently loaded food items.
     */
    fun scheduleAll(context: Context, foods: List<FoodItem>) {
        if (!AppPreferences.expiryRemindersEnabled(context)) {
            foods.forEach { cancel(context, it.id) }
            return
        }
        foods.forEach { schedule(context, it) }
    }

    /**
     * Cancels the local reminder alarm for one food item.
     */
    fun cancel(context: Context, foodId: String) {
        if (foodId.isBlank()) return
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, FoodReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            foodId.stableReminderRequestCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
    }

    /**
     * Checks whether this app currently has notification permission.
     */
    fun canPostNotifications(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun FoodItem.canHaveReminder(): Boolean {
        val archived = status == FoodStatus.USED.name || status == FoodStatus.WASTED.name
        // A value of 0 means the Add/Edit Food checkbox is off, so no alarm should be stored.
        return reminderDaysBefore > 0 && id.isNotBlank() && name.isNotBlank() && expiryDate > 0L && quantity > 0.0 && !archived
    }

    private fun calculateReminderTimeMillis(food: FoodItem): Long {
        val zone = ZoneId.systemDefault()
        val expiryDate = Instant.ofEpochMilli(food.expiryDate).atZone(zone).toLocalDate()

        // The stored expiry date is a calendar day, so reminders are scheduled at 9 AM on
        // the user-selected reminder day instead of midnight, which is easier to notice.
        return expiryDate
            .minusDays(food.reminderDaysBefore.coerceAtLeast(0).toLong())
            .atTime(LocalTime.of(REMINDER_HOUR, 0))
            .atZone(zone)
            .toInstant()
            .toEpochMilli()
    }

    private fun FoodItem.stableReminderRequestCode(): Int = id.stableReminderRequestCode()

    private fun String.stableReminderRequestCode(): Int = hashCode()
}
