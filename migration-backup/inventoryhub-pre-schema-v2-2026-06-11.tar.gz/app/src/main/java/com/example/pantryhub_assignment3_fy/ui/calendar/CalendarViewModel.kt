package com.example.pantryhub_assignment3_fy.ui.calendar

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantryhub_assignment3_fy.data.repository.FoodRepository
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.notification.FoodReminderScheduler
import com.example.pantryhub_assignment3_fy.util.update
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * Turns FoodItem expiry dates into a monthly calendar and selected-day lists.
 *
 * The Calendar page reads only the pantry food collection; it does not create
 * a separate calendar table or duplicate expiry data.
 */
class CalendarViewModel(
    private val foodRepository: FoodRepository = FoodRepository()
) : ViewModel() {
    private val _uiState = MutableLiveData(CalendarUiState())
    val uiState: LiveData<CalendarUiState> = _uiState

    private var foods: List<FoodItem> = emptyList()

    init {
        observeFoods()
    }

    /**
     * Moves the visible calendar one month backward.
     */
    fun previousMonth() {
        // Month navigation keeps the same selected day when possible, then regenerates month cells.
        _uiState.update {
            val month = it.visibleMonth.minusMonths(1)
            val selected = it.selectedDate.withMonthSafely(month)
            buildState(month, selected, isLoading = false, successMessage = it.successMessage)
        }
    }

    /**
     * Moves the visible calendar one month forward.
     */
    fun nextMonth() {
        // Month navigation keeps the same selected day when possible, then regenerates month cells.
        _uiState.update {
            val month = it.visibleMonth.plusMonths(1)
            val selected = it.selectedDate.withMonthSafely(month)
            buildState(month, selected, isLoading = false, successMessage = it.successMessage)
        }
    }

    /**
     * Resets visible month and selected day to the device's current date.
     */
    fun today() {
        // Today navigation jumps both selected date and visible month back to the real current date.
        val today = LocalDate.now()
        _uiState.update { buildState(YearMonth.from(today), today, isLoading = false, successMessage = it.successMessage) }
    }

    /**
     * Selects a date and rebuilds the selected-date and upcoming sections.
     */
    fun selectDate(date: LocalDate) {
        _uiState.update {
            buildState(YearMonth.from(date), date, isLoading = false, successMessage = it.successMessage)
        }
    }

    /**
     * Marks a food item from the calendar as used and refreshes its reminder alarm.
     */
    fun markUsed(context: Context, food: FoodItem, quantityToUse: Double) {
        if (quantityToUse <= 0.0) {
            showError("This item has no quantity left to use.")
            return
        }
        viewModelScope.launch {
            // Calendar receives the selected quantity from the shared Mark Used sheet, matching Home behavior.
            foodRepository.markUsed(food.id, quantityToUse)
                .onSuccess {
                    val remainingQuantity = (food.quantity - quantityToUse).coerceAtLeast(0.0)
                    if (remainingQuantity <= 0.0) {
                        FoodReminderScheduler.cancel(context, food.id)
                    } else {
                        FoodReminderScheduler.schedule(context, food.copy(quantity = remainingQuantity))
                    }
                    showSuccess("Marked ${food.name} as used.")
                }
                .onFailure { showError(it.message ?: "Could not mark item as used.") }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }

    private fun observeFoods() {
        viewModelScope.launch {
            foodRepository.observeFoods().collect { result ->
                result
                    .onSuccess { loaded ->
                        foods = loaded.filterNot {
                            it.status == FoodStatus.USED.name || it.status == FoodStatus.WASTED.name
                        }
                        _uiState.update {
                            buildState(it.visibleMonth, it.selectedDate, isLoading = false, successMessage = it.successMessage)
                        }
                    }
                    .onFailure { showError(it.message ?: "Could not load calendar items.") }
            }
        }
    }

    /**
     * Combines visible month, selected date, date markers, and food lists into one UI state.
     */
    private fun buildState(
        visibleMonth: YearMonth,
        selectedDate: LocalDate,
        isLoading: Boolean,
        successMessage: String?
    ): CalendarUiState {
        val foodsByDate = foods.groupBy { it.expiryLocalDate() }
        return CalendarUiState(
            isLoading = isLoading,
            visibleMonth = visibleMonth,
            selectedDate = selectedDate,
            monthDays = generateMonthDays(visibleMonth, selectedDate, foodsByDate),
            selectedDateFoods = selectedDateItems(selectedDate),
            upcomingWeekFoods = upcomingWeekItems(selectedDate),
            hasExpiryItems = foods.isNotEmpty(),
            successMessage = successMessage
        )
    }

    private fun generateMonthDays(
        month: YearMonth,
        selectedDate: LocalDate,
        foodsByDate: Map<LocalDate, List<FoodItem>>
    ): List<CalendarDayUi> {
        // Generate a Monday-starting 6-week grid so month navigation never changes the RecyclerView shape.
        val firstOfMonth = month.atDay(1)
        val leadingDays = firstOfMonth.dayOfWeek.value - 1
        val firstGridDate = firstOfMonth.minusDays(leadingDays.toLong())
        return (0 until 42).map { index ->
            val date = firstGridDate.plusDays(index.toLong())
            CalendarDayUi(
                date = date,
                isInVisibleMonth = YearMonth.from(date) == month,
                isToday = date == LocalDate.now(),
                isSelected = date == selectedDate,
                marker = markerForDate(date, foodsByDate[date].orEmpty())
            )
        }
    }

    private fun markerForDate(date: LocalDate, expiringFoods: List<FoodItem>): CalendarMarker {
        // Expiry dates become dots: red for today/past, amber for 1-3 days, and green for later.
        if (expiringFoods.isEmpty()) return CalendarMarker.NONE
        val daysFromToday = ChronoUnit.DAYS.between(LocalDate.now(), date)
        return when {
            daysFromToday <= 0 -> CalendarMarker.RED
            daysFromToday <= 3 -> CalendarMarker.AMBER
            else -> CalendarMarker.UPCOMING
        }
    }

    private fun selectedDateItems(selectedDate: LocalDate): List<FoodItem> {
        // Selected date filtering only includes foods whose expiryDate falls on the chosen calendar day.
        return foods
            .filter { it.expiryLocalDate() == selectedDate }
            .sortedBy { it.expiryDate }
    }

    private fun upcomingWeekItems(selectedDate: LocalDate): List<FoodItem> {
        // Upcoming week starts today and excludes selected-date items to keep the two sections distinct.
        val today = LocalDate.now()
        val end = today.plusDays(7)
        return foods
            .filter {
                val expiry = it.expiryLocalDate()
                expiry in today..end && expiry != selectedDate
            }
            .sortedBy { it.expiryDate }
    }

    private fun FoodItem.expiryLocalDate(): LocalDate {
        return Instant.ofEpochMilli(expiryDate).atZone(ZoneId.systemDefault()).toLocalDate()
    }

    private fun LocalDate.withMonthSafely(month: YearMonth): LocalDate {
        return month.atDay(dayOfMonth.coerceAtMost(month.lengthOfMonth()))
    }

    private fun showSuccess(message: String) {
        _uiState.update { it.copy(successMessage = message) }
    }

    private fun showError(message: String) {
        _uiState.update { it.copy(isLoading = false, errorMessage = message) }
    }
}
