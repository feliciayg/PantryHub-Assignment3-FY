package com.example.pantryhub_assignment3_fy.ui.storage

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetLogWasteBinding
import com.example.pantryhub_assignment3_fy.databinding.FragmentFoodDetailBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.ui.common.FoodActionSheets
import com.example.pantryhub_assignment3_fy.util.DateUtils
import com.example.pantryhub_assignment3_fy.util.loadFoodImage
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.snackbar.Snackbar

/**
 * Shows one inventory item and lets the user edit, delete, use, waste, or contact its supplier.
 */
class FoodDetailFragment : Fragment() {
    private var _binding: FragmentFoodDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: StorageViewModel by activityViewModels()
    private lateinit var foodId: String
    private var currentFood: FoodItem? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFoodDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        foodId = arguments?.getString(ARG_FOOD_ID).orEmpty()
        setupToolbar()
        binding.markUsedButton.setOnClickListener { currentFood?.let { showMarkUsedSheet(it) } }
        binding.logWasteButton.setOnClickListener { currentFood?.let { showLogWasteSheet(it) } }
        binding.addToShopButton.setOnClickListener {
            currentFood?.let { viewModel.addFoodToShopping(it) }
        }
        binding.callSupplierButton.setOnClickListener {
            currentFood?.supplierPhone?.let { dialSupplier(it) }
        }
        binding.emailSupplierButton.setOnClickListener {
            currentFood?.supplierEmail?.let { emailSupplier(it) }
        }

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            val food = state.foods.firstOrNull { it.id == foodId }
            if (food != null) {
                currentFood = food
                render(food)
            }
            state.errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                viewModel.clearMessages()
            }
            state.successMessage?.let {
                showSuccessSnackbar(it)
                viewModel.clearMessages()
            }
        }
    }

    private fun setupToolbar() {
        binding.detailToolbar.setNavigationIcon(R.drawable.ic_back)
        binding.detailToolbar.setNavigationOnClickListener { findNavController().popBackStack() }
        binding.detailToolbar.inflateMenu(R.menu.menu_food_detail)
        binding.detailToolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.editFood -> {
                    findNavController().navigate(
                        R.id.action_foodDetailFragment_to_addEditFoodFragment,
                        bundleOf(AddEditFoodFragment.ARG_MODE to AddEditFoodFragment.MODE_EDIT, AddEditFoodFragment.ARG_FOOD_ID to foodId)
                    )
                    true
                }
                R.id.deleteFood -> {
                    currentFood?.let { confirmDelete(it) }
                    true
                }
                else -> false
            }
        }
    }

    /**
     * Binds a FoodItem into the detail card fields.
     */
    private fun render(food: FoodItem) {
        binding.detailToolbar.title = getString(R.string.stock_item_detail)
        binding.nameTextView.text = food.name
        binding.foodImageView.loadFoodImage(food.imageUrl)
        binding.categoryChip.text = food.category
        binding.locationChip.text = food.storageLocation
        val reminderText = if (food.reminderDaysBefore > 0) {
            getString(R.string.reminder_one_day_at_9)
        } else {
            getString(R.string.reminder_off)
        }
        binding.expiryCard.cardTitleTextView.text = "Expiry Information"
        binding.expiryCard.cardBodyTextView.text =
            "Status: ${food.status.toDisplay()}\nShelf life: ${food.shelfLifeDays} days\nAdded: ${DateUtils.formatDisplayDate(food.addedDate)}\nExpiry: ${DateUtils.formatDisplayDate(food.expiryDate)}\nReminder: $reminderText"
        binding.stockCard.cardTitleTextView.text = "Stock Level"
        binding.stockCard.cardBodyTextView.text =
            "Current: ${food.quantity.toCleanString()} ${food.unit}\nThreshold: ${food.lowStockThreshold.toCleanString()} ${food.unit}\nLow stock: ${if (food.quantity <= food.lowStockThreshold) "Yes" else "No"}"
        binding.supplierCard.cardTitleTextView.text = getString(R.string.supplier_details)
        val supplierDetails = listOfNotNull(
            food.supplierName.takeIf { it.isNotBlank() }?.let { "${getString(R.string.supplier_name)}: $it" },
            food.supplierPhone.takeIf { it.isNotBlank() }?.let { "${getString(R.string.supplier_phone)}: $it" },
            food.supplierEmail.takeIf { it.isNotBlank() }?.let { "${getString(R.string.supplier_email)}: $it" }
        )
        binding.supplierCard.cardBodyTextView.text = supplierDetails
            .takeIf { it.isNotEmpty() }
            ?.joinToString(separator = "\n")
            ?: getString(R.string.no_supplier_details)
        binding.supplierActionsLayout.isVisible = food.supplierPhone.isNotBlank() || food.supplierEmail.isNotBlank()
        binding.callSupplierButton.isVisible = food.supplierPhone.isNotBlank()
        binding.emailSupplierButton.isVisible = food.supplierEmail.isNotBlank()
        binding.notesCard.cardTitleTextView.text = getString(R.string.notes)
        binding.notesCard.cardBodyTextView.text = food.notes.ifBlank { "No notes added." }
    }

    private fun dialSupplier(phone: String) {
        if (phone.isBlank()) return
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}"))
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Snackbar.make(binding.root, R.string.no_app_for_call, Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun emailSupplier(email: String) {
        if (email.isBlank()) return
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${Uri.encode(email)}"))
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Snackbar.make(binding.root, R.string.no_app_for_email, Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun showSuccessSnackbar(message: String) {
        val snackbar = Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG)
        if (message.contains("added to Restock", ignoreCase = true)) {
            snackbar.setAction(R.string.view) {
                findNavController().navigate(R.id.shoppingFragment)
            }
        }
        snackbar.show()
    }

    /**
     * Opens the reusable Mark Used sheet for this detail item.
     */
    private fun showMarkUsedSheet(food: FoodItem) {
        FoodActionSheets.showMarkUsedSheet(binding.root, requireContext(), food) { quantity ->
            viewModel.markUsed(requireContext().applicationContext, food.id, quantity)
        }
    }

    /**
     * Opens the Log Waste sheet and passes quantity/reason to StorageViewModel.
     */
    private fun showLogWasteSheet(food: FoodItem) {
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetLogWasteBinding.inflate(layoutInflater)
        dialog.setContentView(sheetBinding.root)

        val maxQuantity = food.quantity.toInt().coerceAtLeast(1)
        var selectedQuantity = 1.coerceAtMost(maxQuantity)
        var syncingFullyWasted = false

        fun renderQuantity() {
            sheetBinding.quantityValueTextView.text = selectedQuantity.toString()
            syncingFullyWasted = true
            sheetBinding.fullyWastedCheckBox.isChecked = selectedQuantity == maxQuantity
            syncingFullyWasted = false
        }

        sheetBinding.currentQuantityTextView.text = "Current: ${food.quantity.toCleanString()} ${food.unit}"
        sheetBinding.minusButton.setOnClickListener {
            selectedQuantity = (selectedQuantity - 1).coerceAtLeast(1)
            renderQuantity()
        }
        sheetBinding.plusButton.setOnClickListener {
            selectedQuantity = (selectedQuantity + 1).coerceAtMost(maxQuantity)
            renderQuantity()
        }
        sheetBinding.fullyWastedCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (syncingFullyWasted) return@setOnCheckedChangeListener
            // Fully wasted mirrors the Mark Used sheet: checked means remove all remaining stock,
            // unchecked returns to one unit so users can choose a partial waste amount again.
            selectedQuantity = if (isChecked) maxQuantity else 1
            renderQuantity()
        }
        sheetBinding.logWasteButton.setOnClickListener {
            viewModel.logWaste(
                requireContext().applicationContext,
                food.id,
                selectedQuantity.toDouble(),
                sheetBinding.reasonChipGroup.checkedChipText()
            )
            dialog.dismiss()
        }
        sheetBinding.cancelButton.setOnClickListener { dialog.dismiss() }
        renderQuantity()
        dialog.show()
    }

    private fun confirmDelete(food: FoodItem) {
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.delete))
            .setMessage("Delete ${food.name}?")
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                viewModel.deleteFood(requireContext().applicationContext, food.id)
                findNavController().popBackStack()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun ChipGroup.checkedChipText(): String {
        return findViewById<Chip>(checkedChipId)?.text?.toString().orEmpty()
    }

    private fun String.toDisplay(): String {
        return if (this == FoodStatus.USE_TODAY.name) {
            "Priority Today"
        } else {
            lowercase().replace("_", " ").replaceFirstChar { it.uppercase() }
        }
    }

    private fun Double.toCleanString(): String = if (this % 1.0 == 0.0) toInt().toString() else toString()

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val ARG_FOOD_ID = "foodId"
    }
}
