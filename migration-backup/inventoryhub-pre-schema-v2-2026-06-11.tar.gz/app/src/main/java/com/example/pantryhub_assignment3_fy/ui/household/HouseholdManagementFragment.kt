package com.example.pantryhub_assignment3_fy.ui.household

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.FragmentHouseholdManagementBinding
import com.example.pantryhub_assignment3_fy.databinding.ItemHouseholdMemberBinding
import com.example.pantryhub_assignment3_fy.model.HouseholdMember
import com.example.pantryhub_assignment3_fy.ui.shell.ShellViewModel
import com.google.android.material.snackbar.Snackbar

/**
 * Shows invite code actions and the current household member list.
 */
class HouseholdManagementFragment : Fragment() {
    private var _binding: FragmentHouseholdManagementBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ShellViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHouseholdManagementBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }
        binding.copyCodeButton.setOnClickListener { copyInviteCode() }
        binding.shareCodeButton.setOnClickListener { shareInviteCode() }
        viewModel.load()

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            state.details?.let {
                binding.householdNameTextView.text = it.household.name
                binding.inviteCodeTextView.text = it.household.inviteCode
                renderMembers(it.members)
            }
            state.errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                viewModel.clearMessage()
            }
        }
    }

    /**
     * Rebuilds the simple member list from the latest household details.
     */
    private fun renderMembers(members: List<HouseholdMember>) {
        binding.memberListContainer.removeAllViews()
        members.forEach { member ->
            val item = ItemHouseholdMemberBinding.inflate(layoutInflater, binding.memberListContainer, false)
            item.memberInitialTextView.text = member.displayName.firstOrNull()?.uppercase() ?: "?"
            item.memberNameTextView.text = member.displayName
            item.memberRoleTextView.text = member.role.replaceFirstChar { it.uppercase() }
            binding.memberListContainer.addView(item.root)
        }
    }

    /**
     * Copies the invite code to the Android clipboard.
     */
    private fun copyInviteCode() {
        val code = binding.inviteCodeTextView.text.toString()
        val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(getString(R.string.invite_code), code))
        Snackbar.make(binding.root, R.string.invite_code_copied, Snackbar.LENGTH_SHORT).show()
    }

    /**
     * Opens the system share sheet with the household invite code.
     */
    private fun shareInviteCode() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Join my InventoryHub store/team with code ${binding.inviteCodeTextView.text}")
        }
        startActivity(Intent.createChooser(shareIntent, getString(R.string.share_household_code)))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
