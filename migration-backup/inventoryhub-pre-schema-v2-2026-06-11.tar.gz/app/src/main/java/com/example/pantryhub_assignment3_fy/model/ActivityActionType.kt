package com.example.pantryhub_assignment3_fy.model

enum class ActivityActionType {
    ADDED_FOOD,
    USED_FOOD,
    WASTED_FOOD,
    RESTOCKED_FOOD,
    ADDED_SHOPPING_ITEM,
    BOUGHT_SHOPPING_ITEM,
    DELETED_FOOD
}
