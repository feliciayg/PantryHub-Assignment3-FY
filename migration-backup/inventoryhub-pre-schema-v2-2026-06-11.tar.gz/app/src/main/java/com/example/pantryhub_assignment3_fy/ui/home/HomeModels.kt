package com.example.pantryhub_assignment3_fy.ui.home

import com.example.pantryhub_assignment3_fy.model.FoodItem

data class HomeUiState(
    val isLoading: Boolean = true,
    val foods: List<FoodItem> = emptyList(),
    val useTodayFoods: List<FoodItem> = emptyList(),
    val expiringSoonFoods: List<FoodItem> = emptyList(),
    val lowStockFoods: List<FoodItem> = emptyList(),
    val expiredCount: Int = 0,
    val expiringCount: Int = 0,
    val lowStockCount: Int = 0,
    val pantryHealthPercent: Int = 0,
    val activeInventoryCount: Int = 0,
    val activeLowStockCount: Int = 0,
    val restockToOrderCount: Int = 0,
    val restockOrderedCount: Int = 0,
    val restockInTransitCount: Int = 0,
    val restockReceivedCount: Int = 0,
    val wastedCount: Int = 0,
    val wastedQuantity: Double = 0.0,
    val wasteRatePercent: Int = 0,
    val healthyStockPercent: Int = 0,
    val expiredStockPercent: Int = 0,
    val expiringStockPercent: Int = 0,
    val lowStockPercent: Int = 0,
    val shoppingFoodIds: Set<String> = emptySet(),
    val shoppingNames: Set<String> = emptySet(),
    val errorMessage: String? = null,
    val successMessage: String? = null
)
