package com.example.pantryhub_assignment3_fy.ui.calendar

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.FragmentCalendarBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.ui.common.FoodActionSheets
import com.example.pantryhub_assignment3_fy.ui.home.HomePriorityAdapter
import com.example.pantryhub_assignment3_fy.ui.storage.AddEditFoodFragment
import com.example.pantryhub_assignment3_fy.ui.storage.FoodDetailFragment
import com.google.android.material.snackbar.Snackbar
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Displays food expiry dates in a month grid and selected-date list.
 */
class CalendarFragment : Fragment() {
    private var _binding: FragmentCalendarBinding? = null
    private val binding get() = _binding!!
    private val viewModel: CalendarViewModel by viewModels()
    private lateinit var calendarDayAdapter: CalendarDayAdapter
    private lateinit var selectedDateAdapter: HomePriorityAdapter
    private lateinit var upcomingWeekAdapter: HomePriorityAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCalendarBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupAdapters()
        setupActions()

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            render(state)
            state.errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                viewModel.clearMessages()
            }
            state.successMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_SHORT).show()
                viewModel.clearMessages()
            }
        }
    }

    private fun setupAdapters() {
        calendarDayAdapter = CalendarDayAdapter { day -> viewModel.selectDate(day.date) }
        selectedDateAdapter = HomePriorityAdapter(::navigateToFoodDetail, ::showMarkUsedSheet)
        upcomingWeekAdapter = HomePriorityAdapter(::navigateToFoodDetail, ::showMarkUsedSheet)

        binding.calendarRecyclerView.apply {
            layoutManager = GridLayoutManager(requireContext(), 7)
            adapter = calendarDayAdapter
        }
        binding.selectedDateRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = selectedDateAdapter
        }
        binding.upcomingWeekRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = upcomingWeekAdapter
        }
    }

    private fun setupActions() {
        binding.previousMonthButton.setOnClickListener { viewModel.previousMonth() }
        binding.nextMonthButton.setOnClickListener { viewModel.nextMonth() }
        binding.todayButton.setOnClickListener { viewModel.today() }
        binding.addFoodFab.setOnClickListener { navigateToAddFood() }
    }

    /**
     * Renders the selected month, selected date section, and upcoming week cards.
     */
    private fun render(state: CalendarUiState) {
        binding.loadingIndicator.isVisible = state.isLoading
        binding.emptyTextView.isVisible = !state.isLoading && !state.hasExpiryItems
        binding.contentScrollView.isVisible = !state.isLoading

        binding.monthTitleTextView.text = state.visibleMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault()))
        binding.selectedDateTitleTextView.text = state.selectedDate.format(DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault()))
        binding.selectedDateWarningTextView.text = selectedDateWarning(state.selectedDate, state.selectedDateFoods.size)
        binding.selectedDateWarningTextView.isVisible = state.selectedDateFoods.isNotEmpty()

        calendarDayAdapter.submitList(state.monthDays)
        selectedDateAdapter.submitList(state.selectedDateFoods)
        upcomingWeekAdapter.submitList(state.upcomingWeekFoods)

        binding.selectedDateRecyclerView.isVisible = state.selectedDateFoods.isNotEmpty()
        binding.emptySelectedDateTextView.isVisible = state.selectedDateFoods.isEmpty()
        binding.upcomingWeekRecyclerView.isVisible = state.upcomingWeekFoods.isNotEmpty()
        binding.emptyUpcomingWeekTextView.isVisible = state.upcomingWeekFoods.isEmpty()
    }

    private fun selectedDateWarning(date: LocalDate, count: Int): String {
        val itemLabel = if (count == 1) "item" else "items"
        return if (date == LocalDate.now()) {
            "$count $itemLabel expires today"
        } else {
            "$count $itemLabel expires on this date"
        }
    }

    private fun navigateToFoodDetail(food: FoodItem) {
        findNavController().navigate(
            R.id.action_calendarFragment_to_foodDetailFragment,
            bundleOf(FoodDetailFragment.ARG_FOOD_ID to food.id)
        )
    }

    private fun navigateToAddFood() {
        findNavController().navigate(
            R.id.action_calendarFragment_to_addEditFoodFragment,
            bundleOf(AddEditFoodFragment.ARG_MODE to AddEditFoodFragment.MODE_ADD)
        )
    }

    private fun showMarkUsedSheet(food: FoodItem) {
        FoodActionSheets.showMarkUsedSheet(binding.root, requireContext(), food) { quantity ->
            viewModel.markUsed(requireContext().applicationContext, food, quantity)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
