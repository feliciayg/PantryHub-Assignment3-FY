package com.example.pantryhub_assignment3_fy.ui.shopping

import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.model.ShoppingStatus

object ShoppingSectionRules {
    fun boughtReadyToStoreItems(items: List<ShoppingItem>, query: String = ""): List<ShoppingItem> {
        return items
            .filter { it.status == ShoppingStatus.RECEIVED.name }
            .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
            .sortedByDescending { it.updatedAt }
    }
}
