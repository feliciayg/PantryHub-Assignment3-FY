package com.example.pantryhub_assignment3_fy.model

enum class FoodStatus {
    FRESH,
    USE_TODAY,
    EXPIRING_SOON,
    EXPIRED,
    LOW_STOCK,
    USED,
    WASTED
}
