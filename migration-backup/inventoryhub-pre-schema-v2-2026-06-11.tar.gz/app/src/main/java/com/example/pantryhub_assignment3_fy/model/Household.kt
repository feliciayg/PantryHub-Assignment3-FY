package com.example.pantryhub_assignment3_fy.model

import com.google.firebase.Timestamp

data class Household(
    val householdId: String = "",
    val name: String = "",
    val inviteCode: String = "",
    val createdBy: String = "",
    val createdAt: Timestamp? = null
)
