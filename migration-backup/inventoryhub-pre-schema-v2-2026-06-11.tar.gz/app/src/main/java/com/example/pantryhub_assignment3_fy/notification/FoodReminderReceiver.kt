package com.example.pantryhub_assignment3_fy.notification

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.pantryhub_assignment3_fy.MainActivity
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.util.DateUtils

/**
 * Receives AlarmManager reminder broadcasts and turns them into visible notifications.
 */
class FoodReminderReceiver : BroadcastReceiver() {
    /**
     * Builds the notification and deep-link intent when a scheduled expiry reminder fires.
     */
    override fun onReceive(context: Context, intent: Intent) {
        if (!FoodReminderScheduler.canPostNotifications(context)) return

        val foodId = intent.getStringExtra(FoodReminderScheduler.EXTRA_FOOD_ID).orEmpty()
        val foodName = intent.getStringExtra(FoodReminderScheduler.EXTRA_FOOD_NAME).orEmpty()
        val expiryDate = intent.getLongExtra(FoodReminderScheduler.EXTRA_EXPIRY_DATE, 0L)
        if (foodId.isBlank() || foodName.isBlank()) return

        FoodReminderScheduler.ensureNotificationChannel(context)
        val tapIntent = Intent(context, MainActivity::class.java).apply {
            putExtra(FoodReminderScheduler.EXTRA_FOOD_ID, foodId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val tapPendingIntent = PendingIntent.getActivity(
            context,
            foodId.hashCode(),
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // The notification only carries enough data to alert the user and deep-link back
        // to FoodDetailFragment. Fresh food data is still loaded from Firestore in the app.
        val notification = NotificationCompat.Builder(context, FoodReminderScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_storage)
            .setContentTitle(context.getString(R.string.food_reminder_title, foodName))
            .setContentText(context.getString(R.string.food_reminder_body, DateUtils.countdownText(expiryDate)))
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    context.getString(
                        R.string.food_reminder_body_detailed,
                        foodName,
                        DateUtils.formatDisplayDate(expiryDate)
                    )
                )
            )
            .setContentIntent(tapPendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        context.getSystemService(NotificationManager::class.java)
            .notify(foodId.hashCode(), notification)
    }
}
