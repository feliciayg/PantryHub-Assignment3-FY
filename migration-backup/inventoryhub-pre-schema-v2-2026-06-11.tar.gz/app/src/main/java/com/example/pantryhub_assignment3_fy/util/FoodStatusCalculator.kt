package com.example.pantryhub_assignment3_fy.util

import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/**
 * Central place for deriving a food item's status from expiry date and quantity.
 */
object FoodStatusCalculator {
    /**
     * Calculates status from an existing FoodItem.
     */
    fun calculate(item: FoodItem): FoodStatus {
        return calculate(
            expiryDate = item.expiryDate,
            quantity = item.quantity,
            lowStockThreshold = item.lowStockThreshold,
            currentStatus = item.status
        )
    }

    /**
     * Calculates freshness, expiry urgency, or low-stock state without changing Firestore.
     */
    fun calculate(
        expiryDate: Long,
        quantity: Double,
        lowStockThreshold: Double,
        currentStatus: String = FoodStatus.FRESH.name
    ): FoodStatus {
        if (currentStatus == FoodStatus.USED.name) return FoodStatus.USED
        if (currentStatus == FoodStatus.WASTED.name) return FoodStatus.WASTED

        val today = LocalDate.now()
        val expiry = millisToLocalDate(expiryDate)
        val daysUntilExpiry = ChronoUnit.DAYS.between(today, expiry)

        // Expiry urgency is calculated before low stock so the list visually prioritises food waste risk.
        return when {
            daysUntilExpiry < 0 -> FoodStatus.EXPIRED
            daysUntilExpiry == 0L -> FoodStatus.USE_TODAY
            daysUntilExpiry in 1..3 -> FoodStatus.EXPIRING_SOON
            quantity <= lowStockThreshold -> FoodStatus.LOW_STOCK
            else -> FoodStatus.FRESH
        }
    }

    private fun millisToLocalDate(value: Long): LocalDate {
        return Instant.ofEpochMilli(value).atZone(ZoneId.systemDefault()).toLocalDate()
    }
}
