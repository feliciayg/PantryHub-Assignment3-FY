package com.example.pantryhub_assignment3_fy.ui.storage

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetFilterStorageBinding
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetLogWasteBinding
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetSortStorageBinding
import com.example.pantryhub_assignment3_fy.databinding.FragmentStorageBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.ui.common.FoodActionSheets
import com.example.pantryhub_assignment3_fy.ui.shopping.BoughtShoppingAdapter
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.snackbar.Snackbar

/**
 * Displays inventory items and entry points for stock CRUD actions.
 */
class StorageFragment : Fragment() {
    private var _binding: FragmentStorageBinding? = null
    private val binding get() = _binding!!
    private val viewModel: StorageViewModel by activityViewModels()
    private lateinit var adapter: FoodAdapter
    private lateinit var readyToStoreAdapter: BoughtShoppingAdapter
    private var pendingCsvExportContent: String? = null
    private val importCsvLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val csv = runCatching {
            requireContext().contentResolver.openInputStream(uri)
                ?.bufferedReader()
                ?.use { it.readText() }
                .orEmpty()
        }.getOrNull()
        if (csv.isNullOrBlank()) {
            Snackbar.make(binding.root, R.string.csv_import_failed, Snackbar.LENGTH_LONG).show()
        } else {
            viewModel.importInventoryCsv(requireContext().applicationContext, csv)
        }
    }
    private val importSalesCsvLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val csv = runCatching {
            requireContext().contentResolver.openInputStream(uri)
                ?.bufferedReader()
                ?.use { it.readText() }
                .orEmpty()
        }.getOrNull()
        if (csv.isNullOrBlank()) {
            Snackbar.make(binding.root, R.string.sales_csv_import_failed, Snackbar.LENGTH_LONG).show()
        } else {
            viewModel.importSalesCsv(csv)
        }
    }
    private val exportCsvLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) {
            pendingCsvExportContent = null
            return@registerForActivityResult
        }
        val csv = pendingCsvExportContent ?: return@registerForActivityResult
        runCatching {
            requireContext().contentResolver.openOutputStream(uri)?.use { outputStream ->
                outputStream.write(csv.toByteArray(Charsets.UTF_8))
            } ?: error("Could not open export file.")
        }
            .onSuccess { Snackbar.make(binding.root, R.string.csv_export_saved, Snackbar.LENGTH_SHORT).show() }
            .onFailure { Snackbar.make(binding.root, R.string.csv_export_failed, Snackbar.LENGTH_LONG).show() }
        pendingCsvExportContent = null
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentStorageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupRecyclerView()
        setupSearch()
        applyInitialStatusFilter()
        binding.addFoodFab.setOnClickListener {
            findNavController().navigate(
                R.id.action_storageFragment_to_addEditFoodFragment,
                bundleOf(AddEditFoodFragment.ARG_MODE to AddEditFoodFragment.MODE_ADD)
            )
        }
        binding.filterButton.setOnClickListener { showFilterSheet() }
        binding.sortButton.setOnClickListener { showSortSheet() }
        binding.importCsvButton.setOnClickListener { openCsvImportPicker() }
        binding.importSalesCsvButton.setOnClickListener { openSalesCsvImportPicker() }
        binding.exportCsvButton.setOnClickListener { viewModel.prepareInventoryCsvExport() }

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            val isLowStockFilter = state.selectedStatus == FilterOptions.LOW_STOCK_STATUS
            binding.loadingIndicator.isVisible = state.isLoading
            binding.needToBuyHeaderTextView.isVisible = isLowStockFilter
            binding.readyToStoreHeaderTextView.isVisible = isLowStockFilter && state.readyToStoreItems.isNotEmpty()
            binding.readyToStoreRecyclerView.isVisible = isLowStockFilter && state.readyToStoreItems.isNotEmpty()
            binding.emptyTextView.text = if (isLowStockFilter) {
                getString(R.string.empty_low_stock_need_to_buy)
            } else {
                getString(R.string.empty_storage)
            }
            binding.emptyTextView.isVisible = !state.isLoading &&
                state.visibleFoods.isEmpty() &&
                (!isLowStockFilter || state.readyToStoreItems.isEmpty())
            adapter.submitList(state.visibleFoods)
            readyToStoreAdapter.submitList(state.readyToStoreItems)
            viewModel.scheduleLoadedFoodReminders(requireContext().applicationContext)
            state.errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                viewModel.clearMessages()
            }
            state.successMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_SHORT).show()
                viewModel.clearMessages()
            }
            state.csvExportContent?.let {
                // Export uses Android's document picker so the user chooses a safe save location.
                pendingCsvExportContent = it
                exportCsvLauncher.launch(getString(R.string.inventory_csv_filename))
                viewModel.clearCsvExportContent()
            }
            if (state.csvSummaryTitle != null && state.csvSummaryMessage != null) {
                AlertDialog.Builder(requireContext())
                    .setTitle(state.csvSummaryTitle)
                    .setMessage(state.csvSummaryMessage)
                    .setPositiveButton(R.string.ok, null)
                    .show()
                viewModel.clearCsvSummary()
            }
        }
    }

    private fun openCsvImportPicker() {
        // Import uses OpenDocument so Android grants temporary read access to the selected CSV.
        importCsvLauncher.launch(arrayOf("text/*", "text/csv", "application/csv", "application/vnd.ms-excel"))
    }

    private fun openSalesCsvImportPicker() {
        // Sales CSV import only reads the picked file; all deduction logic stays in the ViewModel/repository.
        importSalesCsvLauncher.launch(arrayOf("text/*", "text/csv", "application/csv", "application/vnd.ms-excel"))
    }

    /**
     * Configures food cards plus swipe gestures for use, waste, and delete actions.
     */
    private fun setupRecyclerView() {
        adapter = FoodAdapter(
            onClick = ::navigateToFoodDetail,
            onUsed = ::showMarkUsedSheet,
            onShop = viewModel::addFoodToShopping,
            onEdit = ::navigateToEditFood,
            onDelete = ::confirmDelete
        )
        binding.foodRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.foodRecyclerView.adapter = adapter
        readyToStoreAdapter = BoughtShoppingAdapter(::navigateToAddBoughtItemToStorage)
        binding.readyToStoreRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.readyToStoreRecyclerView.adapter = readyToStoreAdapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT) {
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder) = false

            override fun onChildDraw(
                c: android.graphics.Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE && viewHolder is FoodAdapter.FoodViewHolder) {
                    val revealWidth = resources.getDimensionPixelSize(R.dimen.food_swipe_action_width) * 4f
                    val startingOffset = if (viewHolder.foregroundView.translationX < 0f && dX > 0f) -revealWidth else 0f
                    viewHolder.setSwipeOffset(startingOffset + dX)
                    return
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                val position = viewHolder.bindingAdapterPosition
                val food = adapter.currentList.getOrNull(position)
                if (food != null && viewHolder is FoodAdapter.FoodViewHolder) {
                    // Releasing the swipe chooses whether the action row stays visible or closes.
                    viewHolder.settleSwipe(
                        food = food,
                        onOpened = {
                            adapter.setOpenFood(food.id)
                            viewHolder.revealActions()
                        },
                        onClosed = { adapter.closeOpenItem() }
                    )
                }
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) adapter.notifyItemChanged(position)
            }

            override fun getSwipeThreshold(viewHolder: RecyclerView.ViewHolder): Float {
                return 1f
            }
        })
        touchHelper.attachToRecyclerView(binding.foodRecyclerView)

        binding.foodRecyclerView.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN && rv.findChildViewUnder(e.x, e.y) == null) {
                    adapter.closeOpenItem()
                }
                return false
            }
        })
    }

    private fun navigateToFoodDetail(food: FoodItem) {
        findNavController().navigate(
            R.id.action_storageFragment_to_foodDetailFragment,
            bundleOf(FoodDetailFragment.ARG_FOOD_ID to food.id)
        )
    }

    private fun navigateToEditFood(food: FoodItem) {
        findNavController().navigate(
            R.id.action_storageFragment_to_addEditFoodFragment,
            bundleOf(AddEditFoodFragment.ARG_MODE to AddEditFoodFragment.MODE_EDIT, AddEditFoodFragment.ARG_FOOD_ID to food.id)
        )
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.search(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    /**
     * Applies an optional status filter passed from Home status cards.
     */
    private fun applyInitialStatusFilter() {
        val statusFilter = arguments?.getString(ARG_STATUS_FILTER).orEmpty()
        if (statusFilter.isBlank()) return

        // Home status cards open Storage with the matching filter already applied.
        val current = viewModel.uiState.value ?: StorageUiState()
        viewModel.filter(current.selectedLocation, current.selectedCategory, statusFilter)
    }

    private fun navigateToAddBoughtItemToStorage(item: ShoppingItem) {
        findNavController().navigate(
            R.id.action_storageFragment_to_addEditFoodFragment,
            bundleOf(
                AddEditFoodFragment.ARG_MODE to AddEditFoodFragment.MODE_ADD,
                AddEditFoodFragment.ARG_PREFILL_NAME to item.name,
                AddEditFoodFragment.ARG_PREFILL_QUANTITY to item.quantity.toString(),
                AddEditFoodFragment.ARG_PREFILL_UNIT to item.unit,
                AddEditFoodFragment.ARG_SOURCE_SHOPPING_ITEM_ID to item.id
            )
        )
    }

    /**
     * Opens the Storage filter sheet for location, category, and status.
     */
    private fun showFilterSheet() {
        val current = viewModel.uiState.value ?: StorageUiState()
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetFilterStorageBinding.inflate(layoutInflater)
        dialog.setContentView(sheetBinding.root)
        sheetBinding.locationChipGroup.check(locationChipId(current.selectedLocation))
        sheetBinding.categoryChipGroup.check(categoryChipId(current.selectedCategory))
        sheetBinding.statusChipGroup.check(statusChipId(current.selectedStatus))

        sheetBinding.applyButton.setOnClickListener {
            viewModel.filter(
                sheetBinding.locationChipGroup.checkedChipText(),
                sheetBinding.categoryChipGroup.checkedChipText(),
                sheetBinding.statusChipGroup.checkedChipText()
            )
            dialog.dismiss()
        }
        sheetBinding.clearButton.setOnClickListener {
            viewModel.filter(FilterOptions.ALL_LOCATION, FilterOptions.ALL_CATEGORY, FilterOptions.ALL_STATUS)
            dialog.dismiss()
        }
        dialog.show()
    }

    /**
     * Opens the Storage sort sheet.
     */
    private fun showSortSheet() {
        val current = viewModel.uiState.value ?: StorageUiState()
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetSortStorageBinding.inflate(layoutInflater)
        dialog.setContentView(sheetBinding.root)
        sheetBinding.sortRadioGroup.check(sortRadioId(current.sortOption))

        sheetBinding.applyButton.setOnClickListener {
            viewModel.sort(sortOptionFromRadioId(sheetBinding.sortRadioGroup.checkedRadioButtonId))
            dialog.dismiss()
        }
        sheetBinding.resetButton.setOnClickListener {
            viewModel.sort(SortOption.EXPIRY_SOONEST)
            dialog.dismiss()
        }
        dialog.show()
    }

    /**
     * Opens the shared Mark Used sheet from a Storage card.
     */
    fun showMarkUsedSheet(food: FoodItem) {
        FoodActionSheets.showMarkUsedSheet(binding.root, requireContext(), food) { quantity ->
            viewModel.markUsed(requireContext().applicationContext, food.id, quantity)
        }
    }

    /**
     * Opens the Log Waste sheet and returns selected quantity/reason to StorageViewModel.
     */
    fun showLogWasteSheet(food: FoodItem) {
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetLogWasteBinding.inflate(layoutInflater)
        dialog.setContentView(sheetBinding.root)

        val maxQuantity = food.quantity.toInt().coerceAtLeast(1)
        var selectedQuantity = 1.coerceAtMost(maxQuantity)
        var syncingFullyWasted = false

        fun renderQuantity() {
            sheetBinding.quantityValueTextView.text = selectedQuantity.toString()
            syncingFullyWasted = true
            sheetBinding.fullyWastedCheckBox.isChecked = selectedQuantity == maxQuantity
            syncingFullyWasted = false
        }

        sheetBinding.currentQuantityTextView.text = "Current: ${food.quantity.toCleanString()} ${food.unit}"
        sheetBinding.minusButton.setOnClickListener {
            selectedQuantity = (selectedQuantity - 1).coerceAtLeast(1)
            renderQuantity()
        }
        sheetBinding.plusButton.setOnClickListener {
            selectedQuantity = (selectedQuantity + 1).coerceAtMost(maxQuantity)
            renderQuantity()
        }
        sheetBinding.fullyWastedCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (syncingFullyWasted) return@setOnCheckedChangeListener
            // Fully wasted mirrors the Mark Used sheet: checked means remove all remaining stock,
            // unchecked returns to one unit so users can choose a partial waste amount again.
            selectedQuantity = if (isChecked) maxQuantity else 1
            renderQuantity()
        }
        sheetBinding.logWasteButton.setOnClickListener {
            viewModel.logWaste(
                requireContext().applicationContext,
                food.id,
                selectedQuantity.toDouble(),
                sheetBinding.reasonChipGroup.checkedChipText()
            )
            dialog.dismiss()
        }
        sheetBinding.cancelButton.setOnClickListener { dialog.dismiss() }
        renderQuantity()
        dialog.show()
    }

    private fun confirmDelete(food: FoodItem) {
        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.delete))
            .setMessage("Delete ${food.name}?")
            .setPositiveButton(getString(R.string.delete)) { _, _ -> viewModel.deleteFood(requireContext().applicationContext, food.id) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun ChipGroup.checkedChipText(): String {
        return findViewById<Chip>(checkedChipId)?.text?.toString().orEmpty()
    }

    private fun locationChipId(location: String): Int = when (location) {
        "Inventory" -> R.id.locationPantryChip
        "Fridge" -> R.id.locationFridgeChip
        "Freezer" -> R.id.locationFreezerChip
        "Crisper" -> R.id.locationCrisperChip
        else -> R.id.locationAllChip
    }

    private fun categoryChipId(category: String): Int = when (category) {
        "Vegetable" -> R.id.categoryVegetableChip
        "Dairy" -> R.id.categoryDairyChip
        "Drinks" -> R.id.categoryDrinksChip
        "Meat" -> R.id.categoryMeatChip
        "Fruit" -> R.id.categoryFruitChip
        "Frozen" -> R.id.categoryFrozenChip
        "Canned" -> R.id.categoryCannedChip
        "Snacks" -> R.id.categorySnacksChip
        "Other" -> R.id.categoryOtherChip
        else -> R.id.categoryAllChip
    }

    private fun statusChipId(status: String): Int = when (status) {
        "Fresh" -> R.id.statusFreshChip
        "Priority Today" -> R.id.statusUseTodayChip
        "Expiring Soon" -> R.id.statusExpiringSoonChip
        "Expired" -> R.id.statusExpiredChip
        FilterOptions.LOW_STOCK_STATUS -> R.id.statusLowStockChip
        "Used" -> R.id.statusUsedChip
        "Wasted" -> R.id.statusWastedChip
        else -> R.id.statusAllChip
    }

    private fun sortRadioId(option: SortOption): Int = when (option) {
        SortOption.EXPIRY_SOONEST -> R.id.expirySoonestRadioButton
        SortOption.EXPIRY_LATEST -> R.id.expiryLatestRadioButton
        SortOption.NAME_ASC -> R.id.nameAscRadioButton
        SortOption.NAME_DESC -> R.id.nameDescRadioButton
        SortOption.CATEGORY -> R.id.categoryRadioButton
        SortOption.QUANTITY_LOW -> R.id.quantityLowRadioButton
        SortOption.RECENTLY_ADDED -> R.id.recentlyAddedRadioButton
    }

    private fun sortOptionFromRadioId(checkedId: Int): SortOption = when (checkedId) {
        R.id.expiryLatestRadioButton -> SortOption.EXPIRY_LATEST
        R.id.nameAscRadioButton -> SortOption.NAME_ASC
        R.id.nameDescRadioButton -> SortOption.NAME_DESC
        R.id.categoryRadioButton -> SortOption.CATEGORY
        R.id.quantityLowRadioButton -> SortOption.QUANTITY_LOW
        R.id.recentlyAddedRadioButton -> SortOption.RECENTLY_ADDED
        else -> SortOption.EXPIRY_SOONEST
    }

    private fun Double.toCleanString(): String = if (this % 1.0 == 0.0) toInt().toString() else toString()

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val ARG_STATUS_FILTER = "statusFilter"
    }
}
