package com.example.pantryhub_assignment3_fy.util

object Constants {
    const val AUTH_EMAIL_DOMAIN = "pantryhub.app"
    const val USERS_COLLECTION = "users"
    const val HOUSEHOLDS_COLLECTION = "households"
    const val MEMBERS_COLLECTION = "members"
    const val FOODS_COLLECTION = "foods"
    const val SHOPPING_ITEMS_COLLECTION = "shoppingItems"
    const val ACTIVITY_LOGS_COLLECTION = "activityLogs"
    const val OWNER_ROLE = "owner"
    const val MEMBER_ROLE = "member"
}
