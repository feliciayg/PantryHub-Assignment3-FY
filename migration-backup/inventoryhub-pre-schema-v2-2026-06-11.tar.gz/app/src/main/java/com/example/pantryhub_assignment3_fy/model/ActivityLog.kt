package com.example.pantryhub_assignment3_fy.model

data class ActivityLog(
    val id: String = "",
    val actionType: String = "",
    val foodItemId: String? = null,
    val foodName: String = "",
    val quantity: Double? = null,
    val unit: String? = null,
    val userId: String = "",
    val userName: String = "",
    val timestamp: Long = 0L,
    val xpChange: Int = 0,
    val note: String? = null
)
