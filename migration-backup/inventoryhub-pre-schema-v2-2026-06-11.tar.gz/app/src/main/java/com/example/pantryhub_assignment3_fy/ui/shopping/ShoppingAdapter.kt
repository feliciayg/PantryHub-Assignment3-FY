package com.example.pantryhub_assignment3_fy.ui.shopping

import android.graphics.Paint
import android.view.MotionEvent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.ItemFoodRestockCardBinding
import com.example.pantryhub_assignment3_fy.databinding.ItemShoppingActiveBinding
import com.example.pantryhub_assignment3_fy.databinding.ItemShoppingBoughtBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.model.ShoppingStatus
import com.example.pantryhub_assignment3_fy.util.loadFoodImage

class ActiveShoppingAdapter(
    private val onItemClick: (ShoppingItem) -> Unit,
    private val onAdvance: (ShoppingItem) -> Unit,
    private val onCancel: (ShoppingItem) -> Unit,
    private val onDragStarted: (RecyclerView.ViewHolder) -> Unit
) : ListAdapter<ShoppingItem, ActiveShoppingAdapter.ActiveViewHolder>(ShoppingDiff) {
    private var draggedOrder: List<ShoppingItem>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActiveViewHolder {
        return ActiveViewHolder(
            ItemShoppingActiveBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ActiveViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun submitShoppingItems(items: List<ShoppingItem>) {
        draggedOrder = null
        submitList(items)
    }

    fun currentDraggedOrder(): List<ShoppingItem> = draggedOrder ?: currentList

    fun moveItem(fromPosition: Int, toPosition: Int): Boolean {
        val currentOrder = draggedOrder ?: currentList
        if (fromPosition !in currentOrder.indices || toPosition !in currentOrder.indices) return false
        val movedItems = currentOrder.toMutableList()
        val movedItem = movedItems.removeAt(fromPosition)
        movedItems.add(toPosition, movedItem)
        draggedOrder = movedItems
        submitList(movedItems)
        return true
    }

    inner class ActiveViewHolder(
        private val binding: ItemShoppingActiveBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ShoppingItem) {
            binding.itemNameTextView.text = item.name
            binding.quantityTextView.text = "${item.quantity.toCleanString()} ${item.unit}"
            binding.statusChip.text = item.statusLabel(binding.root.context)
            binding.progressTextView.setText(R.string.restock_progress_tracker)
            binding.nextStatusButton.text = item.nextActionLabel(binding.root.context)
            binding.nextStatusButton.setOnClickListener { onAdvance(item) }
            binding.cancelOrderButton.setOnClickListener { onCancel(item) }
            binding.root.setOnClickListener { onItemClick(item) }
            binding.dragHandleTextView.setOnTouchListener { _, event ->
                // Drag begins only from the six-dot handle so normal row taps still open edit.
                if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                    onDragStarted(this)
                }
                false
            }
        }
    }
}

private fun ShoppingItem.statusLabel(context: android.content.Context): String {
    return when (status) {
        ShoppingStatus.ORDERED.name -> context.getString(R.string.ordered)
        ShoppingStatus.IN_TRANSIT.name -> context.getString(R.string.in_transit)
        else -> context.getString(R.string.to_buy)
    }
}

private fun ShoppingItem.nextActionLabel(context: android.content.Context): String {
    return when (status) {
        ShoppingStatus.ORDERED.name -> context.getString(R.string.mark_in_transit)
        ShoppingStatus.IN_TRANSIT.name -> context.getString(R.string.receive_stock)
        else -> context.getString(R.string.mark_ordered)
    }
}

class BoughtShoppingAdapter(
    private val onAddToStorage: (ShoppingItem) -> Unit
) : ListAdapter<ShoppingItem, BoughtShoppingAdapter.BoughtViewHolder>(ShoppingDiff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BoughtViewHolder {
        return BoughtViewHolder(
            ItemShoppingBoughtBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: BoughtViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class BoughtViewHolder(
        private val binding: ItemShoppingBoughtBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ShoppingItem) {
            binding.itemNameTextView.text = item.name
            binding.itemNameTextView.paintFlags = binding.itemNameTextView.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            binding.quantityTextView.text = "${item.quantity.toCleanString()} ${item.unit}"
            binding.statusChip.setText(R.string.received)
            binding.addToStorageButton.isVisible = item.sourceFoodItemId.isNullOrBlank()
            binding.addToStorageButton.setOnClickListener { onAddToStorage(item) }
        }
    }
}

class RestockSuggestionAdapter(
    private val onAdd: (FoodItem) -> Unit
) : ListAdapter<FoodItem, RestockSuggestionAdapter.SuggestionViewHolder>(FoodDiff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SuggestionViewHolder {
        return SuggestionViewHolder(
            ItemFoodRestockCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: SuggestionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class SuggestionViewHolder(
        private val binding: ItemFoodRestockCardBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(food: FoodItem) {
            binding.nameTextView.text = food.name
            binding.quantityTextView.text = "${food.quantity.toCleanString()} ${food.unit} left"
            binding.foodImageView.loadFoodImage(food.imageUrl, R.drawable.ic_storage)
            binding.addToShopButton.setText(R.string.add)
            binding.addToShopButton.setOnClickListener { onAdd(food) }
        }
    }
}

private object ShoppingDiff : DiffUtil.ItemCallback<ShoppingItem>() {
    override fun areItemsTheSame(oldItem: ShoppingItem, newItem: ShoppingItem): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: ShoppingItem, newItem: ShoppingItem): Boolean = oldItem == newItem
}

private object FoodDiff : DiffUtil.ItemCallback<FoodItem>() {
    override fun areItemsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean = oldItem == newItem
}

private fun Double.toCleanString(): String {
    return if (this % 1.0 == 0.0) toInt().toString() else toString()
}
