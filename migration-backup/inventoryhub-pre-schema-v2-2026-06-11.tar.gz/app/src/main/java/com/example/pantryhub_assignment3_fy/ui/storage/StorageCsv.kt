package com.example.pantryhub_assignment3_fy.ui.storage

import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.util.DateUtils

object StorageCsv {
    private val exportHeaders = listOf(
        "id",
        "name",
        "category",
        "quantity",
        "unit",
        "lowStockThreshold",
        "storageLocation",
        "expiryDate",
        "status",
        "supplierName",
        "supplierPhone",
        "supplierEmail",
        "notes"
    )

    fun exportFoods(foods: List<FoodItem>): String {
        return buildString {
            appendLine(exportHeaders.joinToString(","))
            foods.forEach { food ->
                appendLine(
                    listOf(
                        food.id,
                        food.name,
                        food.category,
                        food.quantity.toCleanString(),
                        food.unit,
                        food.lowStockThreshold.toCleanString(),
                        food.storageLocation,
                        food.expiryDate.takeIf { it > 0L }?.let(DateUtils::formatInputDate).orEmpty(),
                        food.status,
                        food.supplierName,
                        food.supplierPhone,
                        food.supplierEmail,
                        food.notes
                    ).joinToString(",") { it.csvEscaped() }
                )
            }
        }
    }

    fun parseRows(csv: String): CsvParseResult {
        val lines = csv.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return CsvParseResult(emptyList(), listOf("CSV file is empty."))

        // Header names are normalized so column order can vary while required names stay stable.
        val headers = parseLine(lines.first()).map { it.trim().lowercase() }
        val headerIndex = headers.withIndex().associate { it.value to it.index }
        val errors = mutableListOf<String>()
        REQUIRED_HEADERS.forEach { header ->
            if (header !in headerIndex) errors += "Missing required column: $header"
        }
        if (errors.isNotEmpty()) return CsvParseResult(emptyList(), errors)

        val rows = lines.drop(1).mapIndexed { index, line ->
            val values = parseLine(line)
            CsvRow(
                rowNumber = index + 2,
                values = headerIndex.mapValues { (_, columnIndex) -> values.getOrNull(columnIndex).orEmpty().trim() }
            )
        }
        return CsvParseResult(rows, emptyList())
    }

    fun parseSalesRows(csv: String): CsvSalesParseResult {
        val lines = csv.lineSequence().filter { it.isNotBlank() }.toList()
        if (lines.isEmpty()) return CsvSalesParseResult(emptyList(), listOf("CSV file is empty."))

        // Sales header mapping accepts either itemId or name plus quantitySold.
        val headers = parseLine(lines.first()).map { it.trim().lowercase() }
        val headerIndex = headers.withIndex().associate { it.value to it.index }
        val errors = mutableListOf<String>()
        if ("itemid" !in headerIndex && "name" !in headerIndex) errors += "Missing required column: itemId or name"
        if ("quantitysold" !in headerIndex) errors += "Missing required column: quantitySold"
        if (errors.isNotEmpty()) return CsvSalesParseResult(emptyList(), errors)

        val rows = lines.drop(1).mapIndexed { index, line ->
            val values = parseLine(line)
            CsvSalesRow(
                rowNumber = index + 2,
                values = headerIndex.mapValues { (_, columnIndex) -> values.getOrNull(columnIndex).orEmpty().trim() }
            )
        }
        return CsvSalesParseResult(rows, emptyList())
    }

    private fun parseLine(line: String): List<String> {
        val values = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var index = 0

        while (index < line.length) {
            val char = line[index]
            when {
                char == '"' && inQuotes && line.getOrNull(index + 1) == '"' -> {
                    current.append('"')
                    index++
                }
                char == '"' -> inQuotes = !inQuotes
                char == ',' && !inQuotes -> {
                    values += current.toString()
                    current.clear()
                }
                else -> current.append(char)
            }
            index++
        }
        values += current.toString()
        return values
    }

    private fun String.csvEscaped(): String {
        val escaped = replace("\"", "\"\"")
        return if (escaped.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) {
            "\"$escaped\""
        } else {
            escaped
        }
    }

    private fun Double.toCleanString(): String = if (this % 1.0 == 0.0) toInt().toString() else toString()

    private val REQUIRED_HEADERS = setOf("name", "quantity", "unit")
}

data class CsvParseResult(
    val rows: List<CsvRow>,
    val errors: List<String>
)

data class CsvRow(
    val rowNumber: Int,
    val values: Map<String, String>
) {
    fun value(header: String): String = values[header.lowercase()].orEmpty()
}

data class CsvSalesParseResult(
    val rows: List<CsvSalesRow>,
    val errors: List<String>
)

data class CsvSalesRow(
    val rowNumber: Int,
    val values: Map<String, String>
) {
    fun value(header: String): String = values[header.lowercase()].orEmpty()
}
