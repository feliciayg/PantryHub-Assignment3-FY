package com.example.pantryhub_assignment3_fy.data.repository

import com.example.pantryhub_assignment3_fy.data.firebase.FirebaseAuthManager
import com.example.pantryhub_assignment3_fy.data.firebase.FirestoreDataSource
import com.example.pantryhub_assignment3_fy.model.UserProfile
import com.example.pantryhub_assignment3_fy.util.Constants
import com.google.firebase.firestore.FieldValue
import kotlinx.coroutines.tasks.await

/**
 * Handles authentication and the InventoryHub user profile document.
 *
 * Firebase Auth stores the login credential, while Firestore `users/{uid}` stores
 * app-specific data such as username, display name, and current store/team id.
 */
class AuthRepository(
    private val authManager: FirebaseAuthManager = FirebaseAuthManager(),
    private val firestoreDataSource: FirestoreDataSource = FirestoreDataSource()
) {
    /**
     * Creates a Firebase Auth account and matching Firestore user profile.
     */
    suspend fun signUp(username: String, displayName: String, password: String): Result<UserProfile> {
        return runCatching {
            val normalizedUsername = username.trim().lowercase()
            require(normalizedUsername.length >= 3) { "Username must be at least 3 characters." }
            require(displayName.trim().isNotEmpty()) { "Display name is required." }
            require(password.length >= 6) { "Password must be at least 6 characters." }

            if (isUsernameTaken(normalizedUsername)) {
                error("Username already taken.")
            }

            val authEmail = authManager.authEmailForUsername(normalizedUsername)
            val authResult = authManager.firebaseAuth()
                .createUserWithEmailAndPassword(authEmail, password)
                .await()
            val uid = authResult.user?.uid ?: error("Could not create account.")
            val userData = hashMapOf(
                "userId" to uid,
                "username" to normalizedUsername,
                "displayName" to displayName.trim(),
                "createdAt" to FieldValue.serverTimestamp(),
                "currentHouseholdId" to null
            )

            // The user profile is stored separately from Firebase Auth so store/team data can reference it.
            firestoreDataSource.db.collection(Constants.USERS_COLLECTION)
                .document(uid)
                .set(userData)
                .await()

            loadUserProfile(uid) ?: error("Could not load created profile.")
        }
    }

    /**
     * Logs in by converting the app username into the hidden Firebase Auth email.
     */
    suspend fun login(username: String, password: String): Result<UserProfile> {
        return runCatching {
            val normalizedUsername = username.trim().lowercase()
            require(normalizedUsername.isNotEmpty()) { "Username is required." }
            require(password.isNotEmpty()) { "Password is required." }

            val authEmail = authManager.authEmailForUsername(normalizedUsername)
            val authResult = authManager.firebaseAuth()
                .signInWithEmailAndPassword(authEmail, password)
                .await()
            val uid = authResult.user?.uid ?: error("Login failed.")

            loadUserProfile(uid) ?: error("Could not load your InventoryHub profile.")
        }
    }

    /**
     * Loads the profile for the currently signed-in Firebase user.
     */
    suspend fun loadCurrentUserProfile(): UserProfile? {
        val uid = authManager.currentUserId ?: return null
        return loadUserProfile(uid)
    }

    /**
     * Clears the local Firebase Auth session.
     */
    fun signOut() {
        authManager.signOut()
    }

    private suspend fun isUsernameTaken(username: String): Boolean {
        // Firestore is checked before account creation so usernames stay unique in the InventoryHub UI.
        val snapshot = firestoreDataSource.db.collection(Constants.USERS_COLLECTION)
            .whereEqualTo("username", username)
            .limit(1)
            .get()
            .await()
        return !snapshot.isEmpty
    }

    private suspend fun loadUserProfile(uid: String): UserProfile? {
        // Login decisions depend on this read because currentHouseholdId controls the next screen.
        val snapshot = firestoreDataSource.db.collection(Constants.USERS_COLLECTION)
            .document(uid)
            .get()
            .await()
        return snapshot.toObject(UserProfile::class.java)
    }
}
