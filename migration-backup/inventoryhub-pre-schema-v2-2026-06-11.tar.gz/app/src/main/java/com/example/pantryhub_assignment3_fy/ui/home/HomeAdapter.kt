package com.example.pantryhub_assignment3_fy.ui.home

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.ItemFoodRestockCardBinding
import com.example.pantryhub_assignment3_fy.databinding.ItemHomeFoodHorizontalBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.util.DateUtils
import com.example.pantryhub_assignment3_fy.util.loadFoodImage

class HomePriorityAdapter(
    private val onClick: (FoodItem) -> Unit,
    private val onUse: (FoodItem) -> Unit
) : ListAdapter<FoodItem, HomePriorityAdapter.PriorityViewHolder>(FoodDiff) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PriorityViewHolder {
        return PriorityViewHolder(
            ItemHomeFoodHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false),
            onClick,
            onUse
        )
    }

    override fun onBindViewHolder(holder: PriorityViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class PriorityViewHolder(
        private val binding: ItemHomeFoodHorizontalBinding,
        private val onClick: (FoodItem) -> Unit,
        private val onUse: (FoodItem) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(food: FoodItem) {
            val context = binding.root.context
            binding.nameTextView.text = food.name
            binding.locationTextView.text = food.storageLocation
            binding.countdownTextView.text = DateUtils.countdownText(food.expiryDate).uppercase()
            binding.countdownTextView.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(context, if (DateUtils.countdownText(food.expiryDate) == "Today") R.color.pantry_coral_light else R.color.chip_yellow)
            )
            binding.foodImageView.loadFoodImage(food.imageUrl)
            binding.root.setOnClickListener { onClick(food) }
            binding.useButton.setOnClickListener { onUse(food) }
        }
    }
}

class HomeLowStockAdapter(
    private val onClick: (FoodItem) -> Unit,
    private val onAddToShop: (FoodItem) -> Unit
) : ListAdapter<FoodItem, HomeLowStockAdapter.LowStockViewHolder>(FoodDiff) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LowStockViewHolder {
        return LowStockViewHolder(
            ItemFoodRestockCardBinding.inflate(LayoutInflater.from(parent.context), parent, false),
            onClick,
            onAddToShop
        )
    }

    override fun onBindViewHolder(holder: LowStockViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class LowStockViewHolder(
        private val binding: ItemFoodRestockCardBinding,
        private val onClick: (FoodItem) -> Unit,
        private val onAddToShop: (FoodItem) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(food: FoodItem) {
            binding.nameTextView.text = food.name
            binding.quantityTextView.text = "${food.quantity.toCleanString()} ${food.unit} left"
            binding.foodImageView.loadFoodImage(food.imageUrl, R.drawable.ic_storage)
            binding.root.setOnClickListener { onClick(food) }
            binding.addToShopButton.setOnClickListener { onAddToShop(food) }
        }
    }
}

private object FoodDiff : DiffUtil.ItemCallback<FoodItem>() {
    override fun areItemsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean = oldItem == newItem
}

private fun Double.toCleanString(): String {
    return if (this % 1.0 == 0.0) toInt().toString() else toString()
}
