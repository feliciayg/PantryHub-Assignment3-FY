package com.example.pantryhub_assignment3_fy

import android.Manifest
import android.content.Intent
import android.content.res.Configuration
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.Insets
import androidx.core.os.bundleOf
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.NavController
import androidx.navigation.ui.setupWithNavController
import com.example.pantryhub_assignment3_fy.databinding.ActivityMainBinding
import com.example.pantryhub_assignment3_fy.notification.FoodReminderScheduler
import com.example.pantryhub_assignment3_fy.ui.shell.ShellViewModel
import com.example.pantryhub_assignment3_fy.ui.storage.FoodDetailFragment
import com.example.pantryhub_assignment3_fy.util.AppPreferences
import com.google.android.material.snackbar.Snackbar

/**
 * Hosts the whole PantryHub app.
 *
 * This activity owns the shared navigation shell: toolbar, drawer, bottom navigation,
 * system-bar spacing, theme setup, and notification deep links. Individual fragments
 * stay focused on their own page content.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private val shellViewModel: ShellViewModel by viewModels()
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Snackbar.make(binding.root, R.string.notification_permission_needed, Snackbar.LENGTH_SHORT).show()
        }
    }

    /**
     * Builds the shared app frame and connects Navigation Component to the toolbar,
     * bottom tabs, drawer menu, shell ViewModel, and notification entry point.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        AppPreferences.applySavedTheme(this)
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applySystemBarAppearance()

        navController = (supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment).navController
        FoodReminderScheduler.ensureNotificationChannel(this)
        requestNotificationPermissionIfNeeded()
        val mainDestinations = setOf(
            R.id.homeFragment,
            R.id.storageFragment,
            R.id.calendarFragment,
            R.id.shoppingFragment,
            R.id.activityFragment
        )
        val baseBottomNavigationHeight = resources.getDimensionPixelSize(R.dimen.bottom_navigation_height)
        var systemBarInsets = Insets.NONE

        fun applySystemBarInsets(isMainDestination: Boolean) {
            // Main pages use the shared app bar and bottom nav, so only those shared
            // containers receive status/navigation bar padding. Full-screen auth/detail
            // pages receive the padding directly on the NavHost instead.
            binding.appBarLayout.updatePadding(top = if (isMainDestination) systemBarInsets.top else 0)
            binding.bottomNavigation.updatePadding(bottom = if (isMainDestination) systemBarInsets.bottom else 0)
            binding.bottomNavigation.updateLayoutParams {
                height = baseBottomNavigationHeight + if (isMainDestination) systemBarInsets.bottom else 0
            }
            binding.navHostFragment.updatePadding(
                top = if (isMainDestination) 0 else systemBarInsets.top,
                bottom = if (isMainDestination) 0 else systemBarInsets.bottom
            )
            binding.navigationView.updatePadding(top = systemBarInsets.top, bottom = systemBarInsets.bottom)
        }

        ViewCompat.setOnApplyWindowInsetsListener(binding.drawerLayout) { _, insets ->
            systemBarInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            applySystemBarInsets(navController.currentDestination?.id in mainDestinations)
            WindowInsetsCompat.CONSUMED
        }

        binding.bottomNavigation.setupWithNavController(navController)
        binding.topAppBar.setNavigationOnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }
        binding.inventoryInsightsPill.setOnClickListener {
            Snackbar.make(binding.root, R.string.inventory_insights_available, Snackbar.LENGTH_SHORT).show()
        }
        binding.navigationView.setNavigationItemSelectedListener { item ->
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            when (item.itemId) {
                R.id.drawer_household -> navController.navigate(R.id.householdManagementFragment)
                R.id.drawer_profile -> navController.navigate(R.id.profileFragment)
                R.id.drawer_settings -> navController.navigate(R.id.settingsFragment)
                R.id.drawer_sign_out -> {
                    shellViewModel.signOut()
                    navController.navigate(R.id.action_global_welcomeFragment)
                }
            }
            true
        }

        navController.addOnDestinationChangedListener { _, destination, _ ->
            val isMainDestination = destination.id in mainDestinations
            binding.appBarLayout.isVisible = isMainDestination
            binding.bottomNavigation.isVisible = isMainDestination
            binding.drawerLayout.setDrawerLockMode(
                if (isMainDestination) androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_UNLOCKED
                else androidx.drawerlayout.widget.DrawerLayout.LOCK_MODE_LOCKED_CLOSED
            )
            applySystemBarInsets(isMainDestination)
            if (isMainDestination) shellViewModel.load()
        }
        handleFoodReminderIntent(intent)

        val drawerHeader = binding.navigationView.getHeaderView(0)
        shellViewModel.uiState.observe(this) { state ->
            state.details?.let { details ->
                drawerHeader.findViewById<android.widget.TextView>(R.id.drawerHouseholdNameTextView).text =
                    details.household.name
                drawerHeader.findViewById<android.widget.TextView>(R.id.drawerDisplayNameTextView).text =
                    details.currentUser.displayName.ifBlank { details.currentUser.username }
                drawerHeader.findViewById<android.widget.TextView>(R.id.drawerRoleTextView).text =
                    details.currentMember.role.replaceFirstChar { it.uppercase() }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                } else if (!navController.popBackStack()) {
                    finish()
                }
            }
        })
    }

    /**
     * Handles notification taps while the app is already open.
     */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleFoodReminderIntent(intent)
    }

    /**
     * Android 13+ requires runtime notification permission before reminders can appear.
     */
    private fun requestNotificationPermissionIfNeeded() {
        if (!AppPreferences.expiryRemindersEnabled(this)) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun applySystemBarAppearance() {
        // The theme setting can switch the app between light and dark mode, so system-bar icon
        // colors need to follow the active mode instead of staying fixed in XML.
        val isDarkMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !isDarkMode
            isAppearanceLightNavigationBars = !isDarkMode
        }
    }

    /**
     * Reads the food id from a reminder notification and navigates to its detail screen.
     */
    private fun handleFoodReminderIntent(intent: Intent?) {
        val foodId = intent?.getStringExtra(FoodReminderScheduler.EXTRA_FOOD_ID).orEmpty()
        if (foodId.isBlank()) return

        // Notification taps jump directly to the food detail screen. The detail screen
        // then reads the latest food data from the current household through StorageViewModel.
        navController.navigate(
            R.id.foodDetailFragment,
            bundleOf(FoodDetailFragment.ARG_FOOD_ID to foodId)
        )
        intent?.removeExtra(FoodReminderScheduler.EXTRA_FOOD_ID)
    }
}
