package com.example.pantryhub_assignment3_fy.ui.household

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.FragmentCreateHouseholdBinding
import com.example.pantryhub_assignment3_fy.util.UiState
import com.google.android.material.snackbar.Snackbar

class CreateHouseholdFragment : Fragment() {
    private var _binding: FragmentCreateHouseholdBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HouseholdViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCreateHouseholdBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.createHouseholdButton.setOnClickListener {
            binding.householdNameLayout.error = null
            val householdName = binding.householdNameEditText.text.toString()
            if (householdName.isBlank()) {
                binding.householdNameLayout.error = getString(R.string.household_name_required)
                return@setOnClickListener
            }
            viewModel.createHousehold(householdName)
        }

        viewModel.householdState.observe(viewLifecycleOwner) { state ->
            binding.progressBar.isVisible = state is UiState.Loading
            binding.createHouseholdButton.isEnabled = state !is UiState.Loading
            when (state) {
                is UiState.Error -> Snackbar.make(binding.root, state.message, Snackbar.LENGTH_LONG).show()
                is UiState.Success -> findNavController().navigate(R.id.action_global_homeFragment)
                else -> Unit
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
