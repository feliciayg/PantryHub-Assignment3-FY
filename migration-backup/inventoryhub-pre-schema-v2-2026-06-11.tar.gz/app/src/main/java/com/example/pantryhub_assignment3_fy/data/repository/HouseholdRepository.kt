package com.example.pantryhub_assignment3_fy.data.repository

import com.example.pantryhub_assignment3_fy.data.firebase.FirebaseAuthManager
import com.example.pantryhub_assignment3_fy.data.firebase.FirestoreDataSource
import com.example.pantryhub_assignment3_fy.model.UserProfile
import com.example.pantryhub_assignment3_fy.model.Household
import com.example.pantryhub_assignment3_fy.model.HouseholdDetails
import com.example.pantryhub_assignment3_fy.model.HouseholdMember
import com.example.pantryhub_assignment3_fy.util.Constants
import com.google.firebase.firestore.FieldValue
import kotlinx.coroutines.tasks.await
import java.util.Locale
import kotlin.random.Random

/**
 * Repository for household setup, joining, member profile data, and drawer/profile details.
 */
class HouseholdRepository(
    private val authManager: FirebaseAuthManager = FirebaseAuthManager(),
    private val firestoreDataSource: FirestoreDataSource = FirestoreDataSource()
) {
    /**
     * Creates a household, adds the current user as owner, and links the user profile to it.
     */
    suspend fun createHousehold(name: String): Result<String> {
        return runCatching {
            require(name.trim().isNotEmpty()) { "Store name is required." }
            val userProfile = currentUserProfile() ?: error("You must be logged in first.")
            val householdRef = firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION).document()
            val inviteCode = generateInviteCode()

            val householdData = hashMapOf(
                "householdId" to householdRef.id,
                "name" to name.trim(),
                "inviteCode" to inviteCode,
                "createdBy" to userProfile.userId,
                "createdAt" to FieldValue.serverTimestamp()
            )
            val memberData = hashMapOf(
                "userId" to userProfile.userId,
                "displayName" to userProfile.displayName,
                "role" to Constants.OWNER_ROLE,
                "joinedAt" to FieldValue.serverTimestamp()
            )

            // Household creation is batched so the household, owner member, and user profile stay consistent.
            val batch = firestoreDataSource.db.batch()
            batch.set(householdRef, householdData)
            batch.set(householdRef.collection(Constants.MEMBERS_COLLECTION).document(userProfile.userId), memberData)
            batch.update(
                firestoreDataSource.db.collection(Constants.USERS_COLLECTION).document(userProfile.userId),
                "currentHouseholdId",
                householdRef.id
            )
            batch.commit().await()
            householdRef.id
        }
    }

    /**
     * Finds a household by invite code and adds the current user as a member.
     */
    suspend fun joinHousehold(inviteCode: String): Result<String> {
        return runCatching {
            val normalizedCode = inviteCode.trim().uppercase(Locale.getDefault())
            require(normalizedCode.isNotEmpty()) { "Invite code is required." }
            val userProfile = currentUserProfile() ?: error("You must be logged in first.")

            // The invite code lookup finds the household document before adding the current user as a member.
            val householdSnapshot = firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION)
                .whereEqualTo("inviteCode", normalizedCode)
                .limit(1)
                .get()
                .await()
            val householdDocument = householdSnapshot.documents.firstOrNull()
                ?: error("Store not found.")
            val householdId = householdDocument.id
            val householdRef = firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION).document(householdId)
            val memberData = hashMapOf(
                "userId" to userProfile.userId,
                "displayName" to userProfile.displayName,
                "role" to Constants.MEMBER_ROLE,
                "joinedAt" to FieldValue.serverTimestamp()
            )

            val batch = firestoreDataSource.db.batch()
            batch.set(householdRef.collection(Constants.MEMBERS_COLLECTION).document(userProfile.userId), memberData)
            batch.update(
                firestoreDataSource.db.collection(Constants.USERS_COLLECTION).document(userProfile.userId),
                "currentHouseholdId",
                householdId
            )
            batch.commit().await()
            householdId
        }
    }

    /**
     * Loads household, current user, current member role, and full member list together.
     */
    suspend fun loadCurrentHouseholdDetails(): Result<HouseholdDetails> {
        return runCatching {
            val userProfile = currentUserProfile() ?: error("You must be logged in first.")
            val householdId = userProfile.currentHouseholdId ?: error("No store selected.")
            val householdRef = firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION).document(householdId)
            val household = householdRef.get().await().toObject(Household::class.java)
                ?: error("Store not found.")
            val members = householdRef.collection(Constants.MEMBERS_COLLECTION)
                .get()
                .await()
                .toObjects(HouseholdMember::class.java)
                .sortedWith(compareBy<HouseholdMember> { it.role != Constants.OWNER_ROLE }.thenBy { it.displayName })
            val currentMember = members.firstOrNull { it.userId == userProfile.userId }
                ?: HouseholdMember(userId = userProfile.userId, displayName = userProfile.displayName)
            HouseholdDetails(household, userProfile, currentMember, members)
        }
    }

    /**
     * Updates display name in both the user profile and household member record.
     */
    suspend fun updateCurrentUserDisplayName(displayName: String): Result<Unit> {
        return runCatching {
            val normalizedName = displayName.trim()
            require(normalizedName.isNotEmpty()) { "Display name is required." }
            val userProfile = currentUserProfile() ?: error("You must be logged in first.")
            val householdId = userProfile.currentHouseholdId ?: error("No store selected.")
            val batch = firestoreDataSource.db.batch()
            batch.update(
                firestoreDataSource.db.collection(Constants.USERS_COLLECTION).document(userProfile.userId),
                "displayName",
                normalizedName
            )
            batch.update(
                firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION)
                    .document(householdId)
                    .collection(Constants.MEMBERS_COLLECTION)
                    .document(userProfile.userId),
                "displayName",
                normalizedName
            )
            batch.commit().await()
        }
    }

    private suspend fun currentUserProfile(): UserProfile? {
        val uid = authManager.currentUserId ?: return null
        val snapshot = firestoreDataSource.db.collection(Constants.USERS_COLLECTION)
            .document(uid)
            .get()
            .await()
        return snapshot.toObject(UserProfile::class.java)
    }

    /**
     * Generates a short human-readable invite code for joining households.
     */
    private fun generateInviteCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..6).map { alphabet[Random.nextInt(alphabet.length)] }.joinToString("")
    }
}
