package com.example.pantryhub_assignment3_fy.ui.settings

import android.Manifest
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.data.repository.FoodRepository
import com.example.pantryhub_assignment3_fy.databinding.FragmentSettingsBinding
import com.example.pantryhub_assignment3_fy.notification.FoodReminderScheduler
import com.example.pantryhub_assignment3_fy.util.AppPreferences
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Local settings page for appearance theme and device notification reminders.
 */
class SettingsFragment : Fragment() {
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val foodRepository = FoodRepository()
    private var syncingControls = false

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val binding = _binding ?: return@registerForActivityResult
        if (granted) {
            updateReminderPreference(enabled = true)
        } else {
            syncingControls = true
            binding.expiryReminderSwitch.isChecked = false
            syncingControls = false
            AppPreferences.setExpiryRemindersEnabled(requireContext(), false)
            Snackbar.make(binding.root, R.string.notification_permission_needed, Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }
        renderSavedPreferences()
        setupThemeControls()
        setupReminderSwitch()
    }

    /**
     * Reads SharedPreferences and updates the controls to match saved values.
     */
    private fun renderSavedPreferences() {
        syncingControls = true
        binding.themeToggleGroup.check(
            when (AppPreferences.themeMode(requireContext())) {
                AppPreferences.THEME_LIGHT -> R.id.lightThemeButton
                AppPreferences.THEME_DARK -> R.id.darkThemeButton
                else -> R.id.systemThemeButton
            }
        )
        binding.expiryReminderSwitch.isChecked = AppPreferences.expiryRemindersEnabled(requireContext())
        syncingControls = false
    }

    /**
     * Saves theme selection and asks AppCompat to recreate screens in the chosen mode.
     */
    private fun setupThemeControls() {
        binding.themeToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (syncingControls || !isChecked) return@addOnButtonCheckedListener
            val mode = when (checkedId) {
                R.id.lightThemeButton -> AppPreferences.THEME_LIGHT
                R.id.darkThemeButton -> AppPreferences.THEME_DARK
                else -> AppPreferences.THEME_SYSTEM
            }

            // Saving the theme locally lets this device remember the user's appearance choice
            // without changing household data for other members.
            AppPreferences.setThemeMode(requireContext(), mode)
            AppPreferences.applySavedTheme(requireContext())
        }
    }

    /**
     * Saves whether this device should schedule food expiry notifications.
     */
    private fun setupReminderSwitch() {
        binding.expiryReminderSwitch.setOnCheckedChangeListener { _, enabled ->
            if (syncingControls) return@setOnCheckedChangeListener
            if (enabled && !FoodReminderScheduler.canPostNotifications(requireContext())) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                updateReminderPreference(enabled)
            }
        }
    }

    private fun updateReminderPreference(enabled: Boolean) {
        AppPreferences.setExpiryRemindersEnabled(requireContext(), enabled)

        lifecycleScope.launch {
            val result = foodRepository.observeFoods().first()
            result
                .onSuccess { foods ->
                    // When reminders are turned off, scheduleAll cancels any existing local alarms.
                    // When turned on, it rebuilds alarms for foods that already have reminder dates.
                    FoodReminderScheduler.scheduleAll(requireContext(), foods)
                    Snackbar.make(
                        binding.root,
                        if (enabled) R.string.expiry_reminders_on else R.string.expiry_reminders_off,
                        Snackbar.LENGTH_SHORT
                    ).show()
                }
                .onFailure {
                    Snackbar.make(binding.root, R.string.reminder_preference_saved, Snackbar.LENGTH_SHORT).show()
                }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
