package com.example.pantryhub_assignment3_fy.ui.activity

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantryhub_assignment3_fy.data.repository.ActivityRepository
import com.example.pantryhub_assignment3_fy.data.repository.FoodRepository
import com.example.pantryhub_assignment3_fy.model.ActivityActionType
import com.example.pantryhub_assignment3_fy.model.ActivityLog
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.util.update
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlinx.coroutines.launch

/**
 * Prepares activity history for the Activity page.
 *
 * It observes Firestore activity logs, applies filter/sort/date choices locally,
 * and derives the saved/wasted/waste-rate summary cards.
 */
class ActivityViewModel(
    private val activityRepository: ActivityRepository = ActivityRepository(),
    private val foodRepository: FoodRepository = FoodRepository()
) : ViewModel() {
    private val _uiState = MutableLiveData(ActivityUiState())
    val uiState: LiveData<ActivityUiState> = _uiState

    init {
        observeActivityLogs()
        observeFoods()
    }

    private fun observeFoods() {
        viewModelScope.launch {
            foodRepository.observeFoods().collect { result ->
                result.onSuccess { foods ->
                    _uiState.update { state ->
                        deriveState(state.copy(expiredFoodCount = foods.count { it.status == FoodStatus.EXPIRED.name }))
                    }
                }
            }
        }
    }

    /**
     * Applies an activity-type chip filter.
     */
    fun filter(filter: ActivityFilter) {
        _uiState.update {
            val next = it.copy(selectedFilter = filter)
            deriveState(next)
        }
    }

    /**
     * Applies the selected sort option to the visible activity list.
     */
    fun sort(sortOption: ActivitySortOption) {
        _uiState.update {
            val next = it.copy(selectedSort = sortOption)
            deriveState(next)
        }
    }

    /**
     * Applies built-in or custom date ranges before the list is filtered and sorted.
     */
    fun dateRange(dateRange: ActivityDateRange, customStartDate: Long? = null, customEndDate: Long? = null) {
        _uiState.update {
            val next = it.copy(
                selectedDateRange = dateRange,
                customStartDate = customStartDate,
                customEndDate = customEndDate
            )
            deriveState(next)
        }
    }

    private fun observeActivityLogs() {
        viewModelScope.launch {
            activityRepository.observeActivityLogs().collect { result ->
                result
                    .onSuccess { logs ->
                        _uiState.update {
                            deriveState(it.copy(isLoading = false, logs = logs, errorMessage = null))
                        }
                    }
                    .onFailure { throwable ->
                        _uiState.update {
                            it.copy(isLoading = false, errorMessage = throwable.message ?: "Could not load activity.")
                        }
                    }
            }
        }
    }

    /**
     * Recomputes visible logs and summary numbers from the raw activity history.
     */
    private fun deriveState(state: ActivityUiState): ActivityUiState {
        // Date range is applied before type chips so summaries and visible rows reflect the selected period.
        val dateFiltered = state.logs.filter { it.isInsideDateRange(state) }
        val filtered = dateFiltered.filter { it.matches(state.selectedFilter) }
        val sorted = when (state.selectedSort) {
            ActivitySortOption.NEWEST_FIRST -> filtered.sortedByDescending { it.timestamp }
            ActivitySortOption.OLDEST_FIRST -> filtered.sortedBy { it.timestamp }
            ActivitySortOption.XP_GAINED_FIRST -> filtered.sortedWith(compareByDescending<ActivityLog> { it.xpChange }.thenByDescending { it.timestamp })
            ActivitySortOption.WASTED_FIRST -> filtered.sortedWith(compareByDescending<ActivityLog> { it.actionType == ActivityActionType.WASTED_FOOD.name }.thenByDescending { it.timestamp })
            ActivitySortOption.EXPIRED_FIRST -> filtered.sortedWith(compareByDescending<ActivityLog> { it.looksExpired() }.thenByDescending { it.timestamp })
        }
        val saved = dateFiltered.count { it.xpChange > 0 }
        val wasted = dateFiltered.count { it.actionType == ActivityActionType.WASTED_FOOD.name }
        val used = dateFiltered.count { it.actionType == ActivityActionType.USED_FOOD.name }
        val wastedOrExpired = wasted + state.expiredFoodCount
        val wasteRate = if (used + wastedOrExpired == 0) {
            0
        } else {
            ((wastedOrExpired.toDouble() / (used + wastedOrExpired)) * 100).toInt()
        }

        return state.copy(
            visibleLogs = sorted,
            savedCount = saved,
            wastedCount = wasted,
            wasteRate = wasteRate
        )
    }

    private fun ActivityLog.matches(filter: ActivityFilter): Boolean {
        return when (filter) {
            ActivityFilter.ALL -> true
            ActivityFilter.ADDED_FOOD -> actionType == ActivityActionType.ADDED_FOOD.name
            ActivityFilter.USED -> actionType == ActivityActionType.USED_FOOD.name
            ActivityFilter.WASTED -> actionType == ActivityActionType.WASTED_FOOD.name
            ActivityFilter.RESTOCKED -> actionType == ActivityActionType.RESTOCKED_FOOD.name
            ActivityFilter.ADDED_SHOPPING_ITEM -> actionType == ActivityActionType.ADDED_SHOPPING_ITEM.name
            ActivityFilter.BOUGHT_SHOPPING_ITEM -> actionType == ActivityActionType.BOUGHT_SHOPPING_ITEM.name
            ActivityFilter.DELETED_FOOD -> actionType == ActivityActionType.DELETED_FOOD.name
        }
    }

    private fun ActivityLog.looksExpired(): Boolean {
        return note?.contains("expired", ignoreCase = true) == true || actionType == "EXPIRED"
    }

    private fun ActivityLog.isInsideDateRange(state: ActivityUiState): Boolean {
        val logDate = timestamp.toLocalDate()
        val today = LocalDate.now()
        return when (state.selectedDateRange) {
            ActivityDateRange.ALL_TIME -> true
            ActivityDateRange.TODAY -> logDate == today
            ActivityDateRange.LAST_7_DAYS -> logDate in today.minusDays(6)..today
            ActivityDateRange.LAST_30_DAYS -> logDate in today.minusDays(29)..today
            ActivityDateRange.CUSTOM -> {
                // Custom date filtering is inclusive so activity on the start/end dates is still shown.
                val start = state.customStartDate?.toLocalDate()
                val end = state.customEndDate?.toLocalDate()
                start != null && end != null && logDate in start..end
            }
        }
    }

    private fun Long.toLocalDate(): LocalDate {
        return Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()
    }
}
