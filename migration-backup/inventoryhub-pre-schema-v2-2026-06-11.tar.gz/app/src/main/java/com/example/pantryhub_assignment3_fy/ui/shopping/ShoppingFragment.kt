package com.example.pantryhub_assignment3_fy.ui.shopping

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetShoppingItemBinding
import com.example.pantryhub_assignment3_fy.databinding.FragmentShoppingBinding
import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.ui.storage.AddEditFoodFragment
import com.example.pantryhub_assignment3_fy.ui.storage.FilterOptions
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar

/**
 * Displays shared restock orders, received items, and inventory restock suggestions.
 */
class ShoppingFragment : Fragment() {
    private var _binding: FragmentShoppingBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ShoppingViewModel by viewModels()

    private lateinit var activeAdapter: ActiveShoppingAdapter
    private lateinit var boughtAdapter: BoughtShoppingAdapter
    private lateinit var suggestionAdapter: RestockSuggestionAdapter
    private lateinit var activeItemTouchHelper: ItemTouchHelper

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentShoppingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupAdapters()
        setupSearch()
        setupFilters()
        setupActiveListGestures()
        binding.addShoppingFab.setOnClickListener { showShoppingSheet(null) }

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            render(state)
            state.errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                viewModel.clearMessages()
            }
            state.successMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_SHORT).show()
                viewModel.clearMessages()
            }
        }
    }

    private fun setupAdapters() {
        activeAdapter = ActiveShoppingAdapter(
            onItemClick = { showShoppingSheet(it) },
            onAdvance = { viewModel.advanceRestockStatus(it.id) },
            onCancel = { viewModel.cancelRestockOrder(it.id) },
            onDragStarted = { activeItemTouchHelper.startDrag(it) }
        )
        boughtAdapter = BoughtShoppingAdapter { navigateToAddStorage(it) }
        suggestionAdapter = RestockSuggestionAdapter { viewModel.addSuggestion(it) }

        binding.activeRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = activeAdapter
        }
        binding.boughtRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = boughtAdapter
        }
        binding.suggestionRecyclerView.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = suggestionAdapter
        }
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.search(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun setupFilters() {
        binding.filterChipGroup.setOnCheckedStateChangeListener { _, checkedIds ->
            val filter = when (checkedIds.firstOrNull()) {
                R.id.toBuyChip -> ShoppingFilter.TO_BUY
                R.id.boughtChip -> ShoppingFilter.BOUGHT
                R.id.lowStockChip -> ShoppingFilter.LOW_STOCK
                else -> ShoppingFilter.ALL
            }
            viewModel.filter(filter)
        }
    }

    /**
     * Adds drag-to-reorder and swipe-to-delete behavior to active restock items.
     */
    private fun setupActiveListGestures() {
        val deleteCornerRadius = resources.getDimension(R.dimen.card_corner_radius)
        val deleteBackground = GradientDrawable().apply {
            setColor(ContextCompat.getColor(requireContext(), R.color.swipe_delete))
            cornerRadii = floatArrayOf(
                0f, 0f,
                deleteCornerRadius, deleteCornerRadius,
                deleteCornerRadius, deleteCornerRadius,
                0f, 0f
            )
        }
        val deletePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ContextCompat.getColor(requireContext(), R.color.white)
            textAlign = Paint.Align.CENTER
            textSize = resources.getDimensionPixelSize(R.dimen.text_size_caption).toFloat()
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val callback = object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, ItemTouchHelper.LEFT) {
            override fun isLongPressDragEnabled(): Boolean = false

            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                // Reorder the visible adapter list immediately so the card follows the user's finger.
                return activeAdapter.moveItem(viewHolder.bindingAdapterPosition, target.bindingAdapterPosition)
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                // Persist the final dropped order once dragging ends to avoid writing on every tiny move.
                viewModel.reorderActiveItems(activeAdapter.currentDraggedOrder())
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                activeAdapter.currentList.getOrNull(viewHolder.bindingAdapterPosition)?.let {
                    viewModel.deleteItem(it.id)
                }
            }

            override fun onChildDraw(
                c: Canvas,
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                dX: Float,
                dY: Float,
                actionState: Int,
                isCurrentlyActive: Boolean
            ) {
                val itemView = viewHolder.itemView
                if (dX < 0) {
                    val revealedWidth = kotlin.math.abs(dX).coerceAtMost(resources.getDimension(R.dimen.food_swipe_action_width) * 1.6f)
                    deleteBackground.setBounds(
                        itemView.right + dX.toInt(),
                        itemView.top,
                        itemView.right,
                        itemView.bottom
                    )
                    deleteBackground.draw(c)
                    // The delete action uses a rounded right edge so it visually follows the card shape while swiping.
                    c.drawText(
                        getString(R.string.delete).uppercase(),
                        itemView.right - revealedWidth / 2f,
                        itemView.top + itemView.height / 2f + deletePaint.textSize / 3f,
                        deletePaint
                    )
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
            }
        }
        activeItemTouchHelper = ItemTouchHelper(callback).apply {
            attachToRecyclerView(binding.activeRecyclerView)
        }
    }

    /**
     * Binds ShoppingUiState into the active, received, and suggestion sections.
     */
    private fun render(state: ShoppingUiState) {
        binding.loadingIndicator.isVisible = state.isLoading
        activeAdapter.submitShoppingItems(state.activeItems)
        boughtAdapter.submitList(state.boughtItems)
        suggestionAdapter.submitList(state.suggestedFoods)

        binding.activeSection.isVisible = state.activeItems.isNotEmpty()
        binding.boughtSection.isVisible = state.boughtItems.isNotEmpty()
        binding.suggestionsSection.isVisible = state.suggestedFoods.isNotEmpty()
        binding.emptyTextView.isVisible = !state.isLoading &&
            state.activeItems.isEmpty() &&
            state.boughtItems.isEmpty() &&
            state.suggestedFoods.isEmpty()
    }

    /**
     * Opens the add/edit restock item bottom sheet.
     */
    private fun showShoppingSheet(item: ShoppingItem?) {
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetShoppingItemBinding.inflate(layoutInflater)
        dialog.setContentView(sheetBinding.root)

        val unitsAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, FilterOptions.units)
        sheetBinding.unitEditText.setAdapter(unitsAdapter)
        sheetBinding.sheetTitleTextView.setText(if (item == null) R.string.add_shopping_item else R.string.edit_shopping_item)
        sheetBinding.nameEditText.setText(item?.name.orEmpty())
        sheetBinding.quantityEditText.setText(item?.quantity?.toCleanString().orEmpty())
        sheetBinding.unitEditText.setText(item?.unit ?: "pack", false)

        sheetBinding.cancelButton.setOnClickListener { dialog.dismiss() }
        sheetBinding.saveButton.setOnClickListener {
            sheetBinding.nameLayout.error = null
            sheetBinding.quantityLayout.error = null
            sheetBinding.unitLayout.error = null

            val name = sheetBinding.nameEditText.text.toString().trim()
            val quantity = sheetBinding.quantityEditText.text.toString().toDoubleOrNull()
            val unit = sheetBinding.unitEditText.text.toString().trim()

            when {
                name.isBlank() -> sheetBinding.nameLayout.error = "Restock item name is required."
                quantity == null || quantity <= 0 -> sheetBinding.quantityLayout.error = "Quantity must be greater than 0."
                unit.isBlank() -> sheetBinding.unitLayout.error = "Unit is required."
                else -> {
                    val form = ShoppingFormData(
                        id = item?.id.orEmpty(),
                        name = name,
                        quantity = quantity,
                        unit = unit,
                        sourceFoodItemId = item?.sourceFoodItemId
                    )
                    if (item == null) viewModel.addItem(form) else viewModel.updateItem(form)
                    dialog.dismiss()
                }
            }
        }

        dialog.show()
    }

    private fun navigateToAddStorage(item: ShoppingItem) {
        findNavController().navigate(
            R.id.addEditFoodFragment,
            bundleOf(
                AddEditFoodFragment.ARG_MODE to AddEditFoodFragment.MODE_ADD,
                AddEditFoodFragment.ARG_PREFILL_NAME to item.name,
                AddEditFoodFragment.ARG_PREFILL_QUANTITY to item.quantity.toCleanString(),
                AddEditFoodFragment.ARG_PREFILL_UNIT to item.unit,
                AddEditFoodFragment.ARG_SOURCE_SHOPPING_ITEM_ID to item.id
            )
        )
    }

    private fun Double.toCleanString(): String {
        return if (this % 1.0 == 0.0) toInt().toString() else toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
