package com.example.pantryhub_assignment3_fy.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.FragmentHomeBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.ui.common.FoodActionSheets
import com.example.pantryhub_assignment3_fy.ui.storage.AddEditFoodFragment
import com.example.pantryhub_assignment3_fy.ui.storage.FoodDetailFragment
import com.example.pantryhub_assignment3_fy.ui.storage.StorageFragment
import com.google.android.material.snackbar.Snackbar

/**
 * Displays the household dashboard: health summary, expiring food, and low-stock actions.
 */
class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()

    private lateinit var useTodayAdapter: HomePriorityAdapter
    private lateinit var expiringSoonAdapter: HomePriorityAdapter
    private lateinit var lowStockAdapter: HomeLowStockAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setupAdapters()
        setupNavigation()
        binding.addFoodFab.setOnClickListener { navigateToAddFood() }

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            render(state)
            state.errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                viewModel.clearMessages()
            }
            state.successMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_SHORT).show()
                viewModel.clearMessages()
            }
        }
    }

    private fun setupAdapters() {
        useTodayAdapter = HomePriorityAdapter(::navigateToFoodDetail, ::showMarkUsedSheet)
        expiringSoonAdapter = HomePriorityAdapter(::navigateToFoodDetail, ::showMarkUsedSheet)
        lowStockAdapter = HomeLowStockAdapter(::navigateToFoodDetail, viewModel::addToShop)

        binding.useTodayRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = useTodayAdapter
        }
        binding.expiringSoonRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = expiringSoonAdapter
        }
        binding.lowStockRecyclerView.apply {
            // Low-stock cards use the same two-column vertical grid pattern as Restock suggestions.
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = lowStockAdapter
        }
    }

    private fun setupNavigation() {
        binding.expiredCard.setOnClickListener { navigateToStorageFilter("Expired") }
        binding.expiringCard.setOnClickListener { navigateToStorageFilter("Expiring Soon") }
        binding.lowStockCard.setOnClickListener { navigateToStorageFilter("Low Stock") }
    }

    /**
     * Binds HomeUiState into the dashboard cards and RecyclerViews.
     */
    private fun render(state: HomeUiState) {
        binding.loadingIndicator.isVisible = state.isLoading
        binding.emptyTextView.isVisible = !state.isLoading && state.foods.isEmpty()
        binding.contentScrollView.isVisible = !state.isLoading && state.foods.isNotEmpty()

        binding.healthProgress.progress = state.pantryHealthPercent
        binding.healthPercentTextView.text = "${state.pantryHealthPercent}%"
        binding.expiredCountTextView.text = state.expiredCount.toString()
        binding.expiringCountTextView.text = state.expiringCount.toString()
        binding.lowStockCountTextView.text = state.lowStockCount.toString()
        bindInventoryInsights(state)

        useTodayAdapter.submitList(state.useTodayFoods.take(3))
        expiringSoonAdapter.submitList(state.expiringSoonFoods.take(5))
        lowStockAdapter.submitList(state.lowStockFoods.take(8))

        binding.useTodaySection.isVisible = true
        binding.expiringSoonSection.isVisible = true
        binding.lowStockSection.isVisible = true
        binding.useTodayRecyclerView.isVisible = state.useTodayFoods.isNotEmpty()
        binding.expiringSoonRecyclerView.isVisible = state.expiringSoonFoods.isNotEmpty()
        binding.lowStockRecyclerView.isVisible = state.lowStockFoods.isNotEmpty()
        binding.emptyUseTodayTextView.isVisible = state.useTodayFoods.isEmpty()
        binding.emptyExpiringSoonTextView.isVisible = state.expiringSoonFoods.isEmpty()
        binding.emptyLowStockTextView.isVisible = state.lowStockFoods.isEmpty()
    }

    private fun bindInventoryInsights(state: HomeUiState) {
        binding.insightTotalActiveTextView.text = "${state.activeInventoryCount}\n${getString(R.string.total_active)}"
        binding.insightExpiredTextView.text = "${state.expiredCount}\n${getString(R.string.expired)}"
        binding.insightExpiringTextView.text = "${state.expiringCount}\n${getString(R.string.expiring)}"
        binding.insightLowStockTextView.text = "${state.activeLowStockCount}\n${getString(R.string.low_stock)}"

        binding.healthyStockProgress.progress = state.healthyStockPercent
        binding.expiringStockProgress.progress = state.expiringStockPercent
        binding.lowStockInsightProgress.progress = state.lowStockPercent
        binding.expiredStockProgress.progress = state.expiredStockPercent

        binding.insightToOrderTextView.text = "${state.restockToOrderCount}\n${getString(R.string.to_buy)}"
        binding.insightOrderedTextView.text = "${state.restockOrderedCount}\n${getString(R.string.ordered)}"
        binding.insightInTransitTextView.text = "${state.restockInTransitCount}\n${getString(R.string.in_transit)}"
        binding.insightReceivedTextView.text = "${state.restockReceivedCount}\n${getString(R.string.received)}"

        binding.insightWastedCountTextView.text = "${state.wastedCount}\n${getString(R.string.wasted)}"
        binding.insightWastedQuantityTextView.text = "${state.wastedQuantity.toCleanString()}\n${getString(R.string.wasted_quantity)}"
        binding.insightWasteRateTextView.text = "${state.wasteRatePercent}%\n${getString(R.string.waste_rate)}"
    }

    private fun navigateToFoodDetail(food: FoodItem) {
        findNavController().navigate(
            R.id.action_homeFragment_to_foodDetailFragment,
            bundleOf(FoodDetailFragment.ARG_FOOD_ID to food.id)
        )
    }

    private fun navigateToAddFood() {
        findNavController().navigate(
            R.id.action_homeFragment_to_addEditFoodFragment,
            bundleOf(AddEditFoodFragment.ARG_MODE to AddEditFoodFragment.MODE_ADD)
        )
    }

    private fun navigateToStorageFilter(status: String) {
        findNavController().navigate(
            R.id.storageFragment,
            bundleOf(StorageFragment.ARG_STATUS_FILTER to status)
        )
    }

    private fun showMarkUsedSheet(food: FoodItem) {
        FoodActionSheets.showMarkUsedSheet(binding.root, requireContext(), food) { quantity ->
            viewModel.markUsed(requireContext().applicationContext, food, quantity)
        }
    }

    private fun Double.toCleanString(): String {
        return if (this % 1.0 == 0.0) toInt().toString() else toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
