package com.example.pantryhub_assignment3_fy.ui.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantryhub_assignment3_fy.data.repository.AuthRepository
import com.example.pantryhub_assignment3_fy.model.UserProfile
import com.example.pantryhub_assignment3_fy.util.UiState
import com.google.firebase.auth.FirebaseAuthException
import kotlinx.coroutines.launch

/**
 * ViewModel for login and sign-up screens.
 *
 * It forwards credential work to AuthRepository and exposes simple loading/success/error state.
 */
class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {
    private val _authState = MutableLiveData<UiState<UserProfile>>(UiState.Idle)
    val authState: LiveData<UiState<UserProfile>> = _authState

    /**
     * Attempts to sign in and returns the loaded user profile on success.
     */
    fun login(username: String, password: String) {
        viewModelScope.launch {
            _authState.value = UiState.Loading
            // The ViewModel asks the repository to authenticate and exposes only UI-friendly state.
            authRepository.login(username, password)
                .onSuccess { _authState.value = UiState.Success(it) }
                .onFailure {
                    _authState.value = UiState.Error(
                        it.toFriendlyMessage(
                            fallback = "Invalid username or password. Please try again.",
                            hideAuthDetails = true
                        )
                    )
                }
        }
    }

    /**
     * Creates an account and matching PantryHub profile.
     */
    fun signUp(username: String, displayName: String, password: String) {
        viewModelScope.launch {
            _authState.value = UiState.Loading
            authRepository.signUp(username, displayName, password)
                .onSuccess { _authState.value = UiState.Success(it) }
                .onFailure { _authState.value = UiState.Error(it.toFriendlyMessage("Could not create account.")) }
        }
    }

    /**
     * Converts technical Firebase errors into messages that are safer and clearer for users.
     */
    private fun Throwable.toFriendlyMessage(fallback: String, hideAuthDetails: Boolean = false): String {
        val rawMessage = message.orEmpty()
        // Login should not expose Firebase's detailed credential wording, but sign-up still
        // returns helpful validation messages such as username taken or password too short.
        return when {
            rawMessage.contains("Default FirebaseApp is not initialized") ->
                "Firebase is not configured yet. Add google-services.json before testing account actions."
            hideAuthDetails && (this is FirebaseAuthException ||
                rawMessage.contains("auth credential", ignoreCase = true) ||
                rawMessage.contains("password is invalid", ignoreCase = true) ||
                rawMessage.contains("no user record", ignoreCase = true)) -> fallback
            else -> rawMessage.ifBlank { fallback }
        }
    }
}
