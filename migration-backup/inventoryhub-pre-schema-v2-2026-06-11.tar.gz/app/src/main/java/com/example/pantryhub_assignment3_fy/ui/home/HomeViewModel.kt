package com.example.pantryhub_assignment3_fy.ui.home

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantryhub_assignment3_fy.data.repository.ActivityRepository
import com.example.pantryhub_assignment3_fy.data.repository.FoodRepository
import com.example.pantryhub_assignment3_fy.data.repository.ShoppingRepository
import com.example.pantryhub_assignment3_fy.model.ActivityActionType
import com.example.pantryhub_assignment3_fy.model.ActivityLog
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.model.ShoppingStatus
import com.example.pantryhub_assignment3_fy.util.DateUtils
import com.example.pantryhub_assignment3_fy.util.update
import com.example.pantryhub_assignment3_fy.notification.FoodReminderScheduler
import kotlinx.coroutines.launch

/**
 * Builds the Home dashboard from existing inventory and restock repository data.
 *
 * Home does not own a Firestore collection; it derives inventory health, expiring
 * sections, and low-stock suggestions from the current store/team inventory.
 */
class HomeViewModel(
    private val foodRepository: FoodRepository = FoodRepository(),
    private val shoppingRepository: ShoppingRepository = ShoppingRepository(),
    private val activityRepository: ActivityRepository = ActivityRepository()
) : ViewModel() {
    private val _uiState = MutableLiveData(HomeUiState())
    val uiState: LiveData<HomeUiState> = _uiState

    private var latestFoods: List<FoodItem> = emptyList()
    private var latestShoppingItems: List<ShoppingItem> = emptyList()
    private var latestActivityLogs: List<ActivityLog> = emptyList()

    init {
        observeFoods()
        observeShoppingItems()
        observeActivityLogs()
    }

    /**
     * Marks a dashboard food card as used and updates its local expiry reminder.
     */
    fun markUsed(context: Context, food: FoodItem, quantityToUse: Double) {
        if (quantityToUse <= 0.0) {
            showError("This item has no quantity left to use.")
            return
        }
        viewModelScope.launch {
            foodRepository.markUsed(food.id, quantityToUse)
                .onSuccess {
                    val remainingQuantity = (food.quantity - quantityToUse).coerceAtLeast(0.0)
                    if (remainingQuantity <= 0.0) {
                        FoodReminderScheduler.cancel(context, food.id)
                    } else {
                        FoodReminderScheduler.schedule(context, food.copy(quantity = remainingQuantity))
                    }
                    showSuccess("Marked ${food.name} as used.")
                }
                .onFailure { showError(it.message ?: "Could not mark item as used.") }
        }
    }

    /**
     * Sends a low-stock Home item into the shared Restock list.
     */
    fun addToShop(food: FoodItem) {
        if (isAlreadyInShopping(food)) {
            showSuccess("${food.name} is already in Restock.")
            return
        }
        viewModelScope.launch {
            shoppingRepository.addShoppingItem(food.name, food.lowStockThreshold.coerceAtLeast(1.0), food.unit, food.id)
                .onSuccess { showSuccess("Added ${food.name} to Restock.") }
                .onFailure { showError(it.message ?: "Could not add to Restock.") }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }

    private fun observeFoods() {
        viewModelScope.launch {
            foodRepository.observeFoods().collect { result ->
                result
                    .onSuccess { foods ->
                        latestFoods = foods
                        publishState(isLoading = false, errorMessage = null)
                    }
                    .onFailure { showError(it.message ?: "Could not load inventory dashboard.") }
            }
        }
    }

    private fun observeShoppingItems() {
        viewModelScope.launch {
            shoppingRepository.observeShoppingItems().collect { result ->
                result
                    .onSuccess { items ->
                        latestShoppingItems = items
                        publishState(isLoading = false, errorMessage = null)
                    }
                    .onFailure { showError(it.message ?: "Could not load restock overview.") }
            }
        }
    }

    private fun observeActivityLogs() {
        viewModelScope.launch {
            activityRepository.observeActivityLogs().collect { result ->
                result
                    .onSuccess { logs ->
                        latestActivityLogs = logs
                        publishState(isLoading = false, errorMessage = null)
                    }
                    .onFailure { showError(it.message ?: "Could not load inventory insights.") }
            }
        }
    }

    private fun publishState(isLoading: Boolean, errorMessage: String?) {
        _uiState.update {
            val next = buildDashboardState()
            next.copy(isLoading = isLoading, errorMessage = errorMessage, successMessage = it.successMessage)
        }
    }

    /**
     * Calculates every Home section from the latest inventory and restock snapshots.
     */
    private fun buildDashboardState(): HomeUiState {
        val trackedFoods = latestFoods.filterNot { it.status == FoodStatus.USED.name }
        val actionableFoods = trackedFoods.filterNot { it.status == FoodStatus.WASTED.name }
        val today = DateUtils.todayMillis()
        val expiredFoods = actionableFoods.filter { it.status == FoodStatus.EXPIRED.name || DateUtils.daysBetween(today, it.expiryDate) < 0 }
        val expiredCount = expiredFoods.size
        val expiringFoods = actionableFoods.filter {
            val daysUntilExpiry = DateUtils.daysBetween(today, it.expiryDate)
            it !in expiredFoods &&
                (it.status == FoodStatus.USE_TODAY.name || it.status == FoodStatus.EXPIRING_SOON.name || daysUntilExpiry in 0..3)
        }
        val expiringCount = expiringFoods.size
        val activeInventoryCount = actionableFoods.size
        val activeLowStockCount = actionableFoods.count { it.quantity <= it.lowStockThreshold }
        val lowStockRiskCount = actionableFoods.count { it !in expiredFoods && it !in expiringFoods && it.quantity <= it.lowStockThreshold }
        val shoppingCandidates = latestShoppingItems.filter {
            it.status == ShoppingStatus.TO_ORDER.name ||
                it.status == ShoppingStatus.ORDERED.name ||
                it.status == ShoppingStatus.IN_TRANSIT.name ||
                it.status == ShoppingStatus.RECEIVED.name
        }
        val shoppingFoodIds = shoppingCandidates.mapNotNull { it.sourceFoodItemId }.filter { it.isNotBlank() }.toSet()
        val shoppingNames = shoppingCandidates.map { it.name.normalizedName() }.toSet()
        val lowStockFoods = latestFoods
            .filter { it.isRestockCandidate() }
            .filterNot { it.isAlreadyInShopping(shoppingFoodIds, shoppingNames) }
            .sortedBy { it.quantity }
        val useTodayFoods = actionableFoods
            .filter { DateUtils.daysBetween(today, it.expiryDate) == 0 }
            .sortedBy { it.expiryDate }
        val expiringSoonFoods = actionableFoods
            .filter {
                val days = DateUtils.daysBetween(today, it.expiryDate)
                days in 1..3
            }
            .sortedBy { it.expiryDate }
        val unhealthyCount = trackedFoods.count { it.status == FoodStatus.EXPIRED.name || it.status == FoodStatus.WASTED.name }
        val pantryHealth = if (trackedFoods.isEmpty()) {
            0
        } else {
            (((trackedFoods.size - unhealthyCount).toDouble() / trackedFoods.size) * 100).toInt()
        }
        val wastedCount = latestActivityLogs.count { it.actionType == ActivityActionType.WASTED_FOOD.name }
        val wastedQuantity = latestActivityLogs
            .filter { it.actionType == ActivityActionType.WASTED_FOOD.name }
            .sumOf { it.quantity ?: 0.0 }
        val usedCount = latestActivityLogs.count { it.actionType == ActivityActionType.USED_FOOD.name }
        val wastedOrExpired = wastedCount + expiredCount
        val wasteRate = if (usedCount + wastedOrExpired == 0) {
            0
        } else {
            ((wastedOrExpired.toDouble() / (usedCount + wastedOrExpired)) * 100).toInt()
        }
        val healthyCount = (activeInventoryCount - expiredCount - expiringCount - lowStockRiskCount).coerceAtLeast(0)
        fun percent(count: Int): Int = if (activeInventoryCount == 0) 0 else ((count.toDouble() / activeInventoryCount) * 100).toInt()
        return HomeUiState(
            isLoading = false,
            foods = trackedFoods,
            useTodayFoods = useTodayFoods,
            expiringSoonFoods = expiringSoonFoods,
            lowStockFoods = lowStockFoods,
            expiredCount = expiredCount,
            expiringCount = expiringCount,
            lowStockCount = lowStockFoods.size,
            pantryHealthPercent = pantryHealth,
            activeInventoryCount = activeInventoryCount,
            activeLowStockCount = activeLowStockCount,
            restockToOrderCount = latestShoppingItems.count { it.status == ShoppingStatus.TO_ORDER.name },
            restockOrderedCount = latestShoppingItems.count { it.status == ShoppingStatus.ORDERED.name },
            restockInTransitCount = latestShoppingItems.count { it.status == ShoppingStatus.IN_TRANSIT.name },
            restockReceivedCount = latestShoppingItems.count { it.status == ShoppingStatus.RECEIVED.name },
            wastedCount = wastedCount,
            wastedQuantity = wastedQuantity,
            wasteRatePercent = wasteRate,
            healthyStockPercent = percent(healthyCount),
            expiredStockPercent = percent(expiredCount),
            expiringStockPercent = percent(expiringCount),
            lowStockPercent = percent(lowStockRiskCount),
            shoppingFoodIds = shoppingFoodIds,
            shoppingNames = shoppingNames
        )
    }

    private fun isAlreadyInShopping(food: FoodItem): Boolean {
        val state = _uiState.value ?: HomeUiState()
        return food.id in state.shoppingFoodIds || food.name.normalizedName() in state.shoppingNames
    }

    private fun FoodItem.isAlreadyInShopping(shoppingFoodIds: Set<String>, shoppingNames: Set<String>): Boolean {
        // Active and received restock items both block restock cards, so Home should not
        // keep asking the user to order the same item again.
        return id in shoppingFoodIds || name.normalizedName() in shoppingNames
    }

    private fun FoodItem.isRestockCandidate(): Boolean {
        val isFullyUsed = status == FoodStatus.USED.name && quantity <= 0.0
        val isActiveLowStock = status != FoodStatus.WASTED.name && quantity <= lowStockThreshold

        // Used-up stock is hidden from active inventory sections, but it should still appear as a
        // restock candidate so the team remembers to order it again.
        return isFullyUsed || isActiveLowStock
    }

    private fun String.normalizedName(): String {
        val compactName = trim()
            .lowercase()
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // This lightweight singular form prevents common duplicate suggestions like grape/grapes.
        return compactName.split(" ").joinToString(" ") { word ->
            when {
                word.endsWith("ies") && word.length > 3 -> word.dropLast(3) + "y"
                word.endsWith("oes") && word.length > 3 -> word.dropLast(2)
                word.endsWith("ses") || word.endsWith("xes") || word.endsWith("ches") || word.endsWith("shes") -> word.dropLast(2)
                word.endsWith("s") && word.length > 1 -> word.dropLast(1)
                else -> word
            }
        }
    }

    private fun showSuccess(message: String) {
        _uiState.update { it.copy(successMessage = message) }
    }

    private fun showError(message: String) {
        _uiState.update { it.copy(isLoading = false, errorMessage = message) }
    }
}
