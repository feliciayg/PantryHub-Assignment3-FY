package com.example.pantryhub_assignment3_fy.ui.common

import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import androidx.core.content.ContextCompat
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetMarkUsedBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Shared bottom sheets for food actions used across Home, Calendar, Storage, and Detail pages.
 */
object FoodActionSheets {
    /**
     * Shows the reusable Mark Used sheet and returns the selected quantity to the caller.
     */
    fun showMarkUsedSheet(anchor: View, context: Context, food: FoodItem, onConfirm: (Double) -> Unit) {
        if (food.quantity <= 0.0) {
            Snackbar.make(anchor, "This item has no quantity left to use.", Snackbar.LENGTH_SHORT).show()
            return
        }

        val dialog = BottomSheetDialog(context)
        val binding = BottomSheetMarkUsedBinding.inflate(LayoutInflater.from(context))
        val maxQuantity = food.quantity.toInt().coerceAtLeast(1)
        var selectedQuantity = 1.coerceAtMost(maxQuantity)
        var syncingFullyConsumed = false

        fun renderQuantity() {
            binding.quantityValueTextView.text = selectedQuantity.toString()
            syncingFullyConsumed = true
            binding.fullyConsumedCheckBox.isChecked = selectedQuantity == maxQuantity
            syncingFullyConsumed = false
        }

        val usedBeforeOrOnExpiry = !LocalDate.now().isAfter(food.expiryLocalDate())
        binding.currentQuantityTextView.text = "Current: ${food.quantity.toCleanString()} ${food.unit}"
        binding.xpRewardTextView.setText(
            if (usedBeforeOrOnExpiry) R.string.xp_reward_before_expiry else R.string.xp_no_reward_after_expiry
        )
        binding.xpRewardTextView.setTextColor(
            ContextCompat.getColor(
                context,
                if (usedBeforeOrOnExpiry) R.color.pantry_green_dark else R.color.pantry_text_secondary
            )
        )
        binding.xpRewardTextView.backgroundTintList = ColorStateList.valueOf(
            ContextCompat.getColor(
                context,
                if (usedBeforeOrOnExpiry) R.color.pantry_green_light else R.color.image_placeholder
            )
        )
        binding.minusButton.setOnClickListener {
            selectedQuantity = (selectedQuantity - 1).coerceAtLeast(1)
            renderQuantity()
        }
        binding.plusButton.setOnClickListener {
            selectedQuantity = (selectedQuantity + 1).coerceAtMost(maxQuantity)
            renderQuantity()
        }
        binding.fullyConsumedCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (syncingFullyConsumed) return@setOnCheckedChangeListener
            // Fully consumed is a shortcut for using the complete remaining stock.
            // Unticking returns to 1 so the user can choose a partial amount again.
            selectedQuantity = if (isChecked) maxQuantity else 1
            renderQuantity()
        }
        binding.confirmUsedButton.setOnClickListener {
            // The same quantity picker is shared by Home and Calendar so a Use action never
            // silently consumes a fixed amount without letting the user choose.
            onConfirm(selectedQuantity.toDouble())
            dialog.dismiss()
        }
        binding.cancelButton.setOnClickListener { dialog.dismiss() }
        renderQuantity()

        dialog.setContentView(binding.root)
        dialog.show()
    }

    private fun Double.toCleanString(): String {
        return if (this % 1.0 == 0.0) toInt().toString() else toString()
    }

    private fun FoodItem.expiryLocalDate(): LocalDate {
        return Instant.ofEpochMilli(expiryDate).atZone(ZoneId.systemDefault()).toLocalDate()
    }
}
