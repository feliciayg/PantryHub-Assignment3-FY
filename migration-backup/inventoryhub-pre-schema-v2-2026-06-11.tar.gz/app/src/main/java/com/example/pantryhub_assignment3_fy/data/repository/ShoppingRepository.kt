package com.example.pantryhub_assignment3_fy.data.repository

import com.example.pantryhub_assignment3_fy.data.firebase.FirebaseAuthManager
import com.example.pantryhub_assignment3_fy.data.firebase.FirestoreDataSource
import com.example.pantryhub_assignment3_fy.model.ActivityActionType
import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.model.ShoppingStatus
import com.example.pantryhub_assignment3_fy.model.UserProfile
import com.example.pantryhub_assignment3_fy.util.Constants
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.util.Date
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

/**
 * Repository for the shared restock list.
 *
 * It stores items in `households/{householdId}/shoppingItems` and records
 * relevant actions in ActivityRepository.
 */
class ShoppingRepository(
    private val authManager: FirebaseAuthManager = FirebaseAuthManager(),
    private val firestoreDataSource: FirestoreDataSource = FirestoreDataSource()
) {
    private val activityRepository = ActivityRepository(authManager, firestoreDataSource)

    /**
     * Streams restock items ordered by their saved drag-and-drop sort order.
     */
    fun observeShoppingItems(): Flow<Result<List<ShoppingItem>>> = callbackFlow {
        val userProfile = currentUserProfile()
        val householdId = userProfile?.currentHouseholdId
        if (householdId.isNullOrBlank()) {
            trySend(Result.failure(IllegalStateException("No store selected.")))
            close()
            return@callbackFlow
        }

        var migrationInProgress = false
        var registration: ListenerRegistration? = shoppingCollection(householdId)
            .orderBy("sortOrder", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(Result.failure(error))
                    return@addSnapshotListener
                }

                val documents = snapshot?.documents.orEmpty()
                if (!migrationInProgress && documents.any { it.hasLegacyNumericDates() }) {
                    migrationInProgress = true
                    launch {
                        runCatching { migrateLegacyShoppingDates(documents) }
                        migrationInProgress = false
                    }
                }

                val items = documents.map { it.toShoppingItem() }
                trySend(Result.success(items))
            }

        awaitClose {
            registration?.remove()
            registration = null
        }
    }

    /**
     * Creates a restock item, preventing duplicates by food id or normalized name.
     */
    suspend fun addShoppingItem(name: String, quantity: Double, unit: String, sourceFoodItemId: String? = null): Result<String> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val cleanName = name.trim()
        val cleanUnit = unit.trim()
        val activeOrBoughtItems = shoppingCollection(householdId)
            .get()
            .await()
            .documents
            .map { it.toShoppingItem() }
            .filter { it.isOpenRestockOrder() || it.status == ShoppingStatus.RECEIVED.name }
        val alreadyListed = activeOrBoughtItems.any { item ->
            val linkedToFood = !sourceFoodItemId.isNullOrBlank() && item.sourceFoodItemId == sourceFoodItemId
            val sameNameWithoutLink = item.sourceFoodItemId.isNullOrBlank() && item.name.normalizedName() == cleanName.normalizedName()
            linkedToFood || sameNameWithoutLink
        }
        require(!alreadyListed) { "$cleanName is already in Restock." }

        val document = shoppingCollection(householdId).document()
        val now = System.currentTimeMillis()
        val item = ShoppingItem(
            id = document.id,
            name = cleanName,
            quantity = quantity,
            unit = cleanUnit,
            status = ShoppingStatus.TO_ORDER.name,
            sourceFoodItemId = sourceFoodItemId,
            addedBy = userId,
            updatedBy = userId,
            createdAt = now,
            updatedAt = now,
            sortOrder = (now % Int.MAX_VALUE).toInt()
        )

        document.set(item.toFirestoreMap()).await()
        activityRepository.addActivityLog(
            actionType = ActivityActionType.ADDED_SHOPPING_ITEM,
            foodItemId = sourceFoodItemId,
            foodName = item.name,
            quantity = item.quantity,
            unit = item.unit,
            xpChange = 0,
            note = "Added to restock list"
        ).getOrThrow()
        document.id
    }

    /**
     * Saves edits to an existing restock item.
     */
    suspend fun updateShoppingItem(item: ShoppingItem): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val updated = item.copy(
            name = item.name.trim(),
            unit = item.unit.trim(),
            updatedBy = userId,
            updatedAt = System.currentTimeMillis()
        )
        shoppingCollection(householdId).document(item.id)
            .set(updated.toFirestoreMap())
            .await()
    }

    /**
     * Persists the user's reordered active restock list for every team member.
     */
    suspend fun updateShoppingOrder(orderedItems: List<ShoppingItem>): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val now = Timestamp.now()
        val batch = firestoreDataSource.db.batch()

        // Each active card gets a simple 0-based sortOrder so all household members see the same sequence.
        orderedItems.forEachIndexed { index, item ->
            val reference = shoppingCollection(householdId).document(item.id)
            batch.update(
                reference,
                mapOf(
                    "sortOrder" to index,
                    "updatedBy" to userId,
                    "updatedAt" to now
                )
            )
        }

        batch.commit().await()
    }

    /**
     * Removes one restock item document.
     */
    suspend fun deleteShoppingItem(itemId: String): Result<Unit> = runCatching {
        val householdId = currentHouseholdId()
        shoppingCollection(householdId).document(itemId).delete().await()
    }

    suspend fun advanceRestockStatus(itemId: String): Result<ShoppingStatus> = runCatching {
        val householdId = currentHouseholdId()
        val item = getShoppingItem(householdId, itemId)
        val nextStatus = item.nextStatus()
        requireNotNull(nextStatus) { "This restock order cannot be advanced." }
        if (nextStatus == ShoppingStatus.RECEIVED) {
            receiveRestockOrder(householdId, item).getOrThrow()
        } else {
            updateStatus(itemId, nextStatus).getOrThrow()
        }
        logRestockStatusChange(item, nextStatus)
        nextStatus
    }

    suspend fun cancelRestockOrder(itemId: String): Result<Unit> = runCatching {
        val householdId = currentHouseholdId()
        val item = getShoppingItem(householdId, itemId)
        require(item.status != ShoppingStatus.RECEIVED.name) { "Received orders cannot be cancelled." }
        require(item.status != ShoppingStatus.STORED.name) { "Stored orders cannot be cancelled." }
        updateStatus(itemId, ShoppingStatus.CANCELLED).getOrThrow()
        activityRepository.addActivityLog(
            actionType = ActivityActionType.ADDED_SHOPPING_ITEM,
            foodItemId = item.sourceFoodItemId,
            foodName = item.name,
            quantity = item.quantity,
            unit = item.unit,
            xpChange = 0,
            note = "Restock order cancelled"
        ).getOrThrow()
    }

    /**
     * Marks a bought shopping item as stored after it has been added back to pantry storage.
     */
    suspend fun markStored(itemId: String): Result<Unit> = updateStatus(itemId, ShoppingStatus.STORED)

    private suspend fun updateStatus(itemId: String, status: ShoppingStatus): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val householdId = currentHouseholdId()
        val now = System.currentTimeMillis()
        shoppingCollection(householdId).document(itemId)
            .update(
                mapOf<String, Any>(
                    "status" to status.name,
                    "updatedBy" to userId,
                    "updatedAt" to now.toFirestoreDateValue()
                ) + status.timestampUpdate(now)
            )
            .await()
    }

    private suspend fun receiveRestockOrder(householdId: String, item: ShoppingItem): Result<Unit> = runCatching {
        val userId = authManager.currentUserId ?: error("You must be logged in.")
        val now = System.currentTimeMillis()
        val orderReference = shoppingCollection(householdId).document(item.id)
        val sourceFoodId = item.sourceFoodItemId

        // Inventory quantity is increased only inside the RECEIVED transition. Earlier
        // statuses are planning/logistics states and must not change stock levels.
        if (sourceFoodId.isNullOrBlank()) {
            orderReference.update(
                mapOf(
                    "status" to ShoppingStatus.RECEIVED.name,
                    "receivedAt" to now.toFirestoreDateValue(),
                    "updatedBy" to userId,
                    "updatedAt" to now.toFirestoreDateValue()
                )
            ).await()
            return@runCatching
        }

        val foodReference = firestoreDataSource.db
            .collection(Constants.HOUSEHOLDS_COLLECTION)
            .document(householdId)
            .collection(Constants.FOODS_COLLECTION)
            .document(sourceFoodId)

        firestoreDataSource.db.runTransaction { transaction ->
            val currentOrderStatus = transaction.get(orderReference).getString("status").orEmpty().toRestockStatus()
            require(currentOrderStatus != ShoppingStatus.RECEIVED) { "This restock order has already been received." }
            val currentQuantity = (transaction.get(foodReference).get("quantity") as? Number)?.toDouble() ?: 0.0
            transaction.update(
                foodReference,
                mapOf(
                    "quantity" to currentQuantity + item.quantity,
                    "updatedBy" to userId,
                    "updatedAt" to now.toFirestoreDateValue()
                )
            )
            transaction.update(
                orderReference,
                mapOf(
                    "status" to ShoppingStatus.RECEIVED.name,
                    "receivedAt" to now.toFirestoreDateValue(),
                    "updatedBy" to userId,
                    "updatedAt" to now.toFirestoreDateValue()
                )
            )
        }.await()
    }

    private suspend fun currentHouseholdId(): String {
        return currentUserProfile()?.currentHouseholdId ?: error("No store selected.")
    }

    private suspend fun currentUserProfile(): UserProfile? {
        val uid = authManager.currentUserId ?: return null
        val snapshot = firestoreDataSource.db.collection(Constants.USERS_COLLECTION)
            .document(uid)
            .get()
            .await()
        return snapshot.toObject(UserProfile::class.java)
    }

    private fun shoppingCollection(householdId: String) =
        firestoreDataSource.db.collection(Constants.HOUSEHOLDS_COLLECTION)
            .document(householdId)
            .collection(Constants.SHOPPING_ITEMS_COLLECTION)

    private suspend fun getShoppingItem(householdId: String, itemId: String): ShoppingItem {
        val snapshot = shoppingCollection(householdId).document(itemId).get().await()
        if (!snapshot.exists()) error("Restock item not found.")
        return snapshot.toShoppingItem()
    }

    private fun DocumentSnapshot.toShoppingItem(): ShoppingItem {
        return ShoppingItem(
            id = getString("id").orEmpty().ifBlank { id },
            name = getString("name").orEmpty(),
            quantity = number("quantity")?.toDouble() ?: 0.0,
            unit = getString("unit").orEmpty(),
            status = getString("status").orEmpty().toRestockStatus().name,
            sourceFoodItemId = getString("sourceFoodItemId"),
            addedBy = getString("addedBy").orEmpty(),
            updatedBy = getString("updatedBy").orEmpty(),
            createdAt = dateMillis("createdAt"),
            updatedAt = dateMillis("updatedAt"),
            orderedAt = dateMillis("orderedAt"),
            inTransitAt = dateMillis("inTransitAt"),
            receivedAt = dateMillis("receivedAt"),
            cancelledAt = dateMillis("cancelledAt"),
            sortOrder = number("sortOrder")?.toInt() ?: 0
        )
    }

    private fun ShoppingItem.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "name" to name,
        "quantity" to quantity,
        "unit" to unit,
        "status" to status,
        "sourceFoodItemId" to sourceFoodItemId,
        "addedBy" to addedBy,
        "updatedBy" to updatedBy,
        "createdAt" to createdAt.toFirestoreDateValue(),
        "updatedAt" to updatedAt.toFirestoreDateValue(),
        "orderedAt" to orderedAt.toFirestoreDateValue(),
        "inTransitAt" to inTransitAt.toFirestoreDateValue(),
        "receivedAt" to receivedAt.toFirestoreDateValue(),
        "cancelledAt" to cancelledAt.toFirestoreDateValue(),
        "sortOrder" to sortOrder
    )

    private suspend fun migrateLegacyShoppingDates(documents: List<DocumentSnapshot>) {
        val batch = firestoreDataSource.db.batch()
        var hasUpdates = false

        documents.forEach { document ->
            val updates = mutableMapOf<String, Any>()
            SHOPPING_DATE_FIELDS.forEach { field ->
                val value = document.get(field)
                if (value is Number && value.toLong() > 0L) {
                    updates[field] = value.toLong().toFirestoreDateValue()
                }
            }
            if (updates.isNotEmpty()) {
                batch.update(document.reference, updates)
                hasUpdates = true
            }
        }

        if (hasUpdates) batch.commit().await()
    }

    private fun DocumentSnapshot.hasLegacyNumericDates(): Boolean =
        SHOPPING_DATE_FIELDS.any { field ->
            val value = get(field)
            value is Number && value.toLong() > 0L
        }

    private fun DocumentSnapshot.dateMillis(field: String): Long =
        when (val value = get(field)) {
            is Timestamp -> value.toDate().time
            is Number -> value.toLong()
            else -> 0L
        }

    private fun Long.toFirestoreDateValue(): Any =
        if (this > 0L) Timestamp(Date(this)) else this

    private fun String.normalizedName(): String = trim().lowercase().replace(Regex("\\s+"), " ")

    private fun String.toRestockStatus(): ShoppingStatus {
        // Compatibility mapping for old Firestore records: previous "active"/"to buy"
        // style values become TO_ORDER, while BOUGHT becomes RECEIVED.
        return when (trim().uppercase()) {
            "", "ACTIVE", "PENDING", "TO_BUY" -> ShoppingStatus.TO_ORDER
            "BOUGHT" -> ShoppingStatus.RECEIVED
            "ORDERED" -> ShoppingStatus.ORDERED
            "IN_TRANSIT", "IN TRANSIT" -> ShoppingStatus.IN_TRANSIT
            "RECEIVED" -> ShoppingStatus.RECEIVED
            "CANCELLED", "CANCELED" -> ShoppingStatus.CANCELLED
            "STORED" -> ShoppingStatus.STORED
            else -> ShoppingStatus.TO_ORDER
        }
    }

    private fun ShoppingItem.isOpenRestockOrder(): Boolean =
        status == ShoppingStatus.TO_ORDER.name ||
            status == ShoppingStatus.ORDERED.name ||
            status == ShoppingStatus.IN_TRANSIT.name

    private fun ShoppingItem.nextStatus(): ShoppingStatus? {
        // Status transitions are intentionally linear for Step 5.
        return when (status) {
            ShoppingStatus.TO_ORDER.name -> ShoppingStatus.ORDERED
            ShoppingStatus.ORDERED.name -> ShoppingStatus.IN_TRANSIT
            ShoppingStatus.IN_TRANSIT.name -> ShoppingStatus.RECEIVED
            else -> null
        }
    }

    private fun ShoppingStatus.timestampUpdate(now: Long): Map<String, Any> {
        return when (this) {
            ShoppingStatus.ORDERED -> mapOf("orderedAt" to now.toFirestoreDateValue())
            ShoppingStatus.IN_TRANSIT -> mapOf("inTransitAt" to now.toFirestoreDateValue())
            ShoppingStatus.RECEIVED -> mapOf("receivedAt" to now.toFirestoreDateValue())
            ShoppingStatus.CANCELLED -> mapOf("cancelledAt" to now.toFirestoreDateValue())
            else -> emptyMap()
        }
    }

    private suspend fun logRestockStatusChange(item: ShoppingItem, status: ShoppingStatus) {
        val note = when (status) {
            ShoppingStatus.ORDERED -> "Restock order marked ordered"
            ShoppingStatus.IN_TRANSIT -> "Restock order marked in transit"
            ShoppingStatus.RECEIVED -> "Restock order received"
            else -> "Restock order updated"
        }
        activityRepository.addActivityLog(
            actionType = if (status == ShoppingStatus.RECEIVED) {
                ActivityActionType.BOUGHT_SHOPPING_ITEM
            } else {
                ActivityActionType.ADDED_SHOPPING_ITEM
            },
            foodItemId = item.sourceFoodItemId,
            foodName = item.name,
            quantity = item.quantity,
            unit = item.unit,
            xpChange = 0,
            note = note
        ).getOrThrow()
    }

    private fun DocumentSnapshot.number(field: String): Number? = get(field) as? Number

    private companion object {
        val SHOPPING_DATE_FIELDS = listOf("createdAt", "updatedAt", "orderedAt", "inTransitAt", "receivedAt", "cancelledAt")
    }
}
