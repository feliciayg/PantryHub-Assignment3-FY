package com.example.pantryhub_assignment3_fy.data.firebase

import com.example.pantryhub_assignment3_fy.util.Constants
import com.google.firebase.auth.FirebaseAuth

/**
 * Small wrapper around FirebaseAuth so repositories can share one login helper.
 */
class FirebaseAuthManager {
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    val currentUserId: String?
        get() = auth.currentUser?.uid

    /**
     * Signs the current user out of Firebase Auth.
     */
    fun signOut() {
        auth.signOut()
    }

    /**
     * Converts an InventoryHub username into a Firebase-compatible email address.
     */
    fun authEmailForUsername(username: String): String {
        // Firebase Auth needs an email, so the app maps a friendly username to a private app-domain email.
        val normalizedUsername = username.trim().lowercase()
        return "$normalizedUsername@${Constants.AUTH_EMAIL_DOMAIN}"
    }

    /**
     * Exposes FirebaseAuth for operations that need Firebase Tasks, such as sign up/login.
     */
    fun firebaseAuth(): FirebaseAuth = auth
}
