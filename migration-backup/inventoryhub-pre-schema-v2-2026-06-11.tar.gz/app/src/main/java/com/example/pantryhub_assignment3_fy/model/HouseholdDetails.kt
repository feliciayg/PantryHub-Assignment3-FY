package com.example.pantryhub_assignment3_fy.model

data class HouseholdDetails(
    val household: Household = Household(),
    val currentUser: UserProfile = UserProfile(),
    val currentMember: HouseholdMember = HouseholdMember(),
    val members: List<HouseholdMember> = emptyList()
)
