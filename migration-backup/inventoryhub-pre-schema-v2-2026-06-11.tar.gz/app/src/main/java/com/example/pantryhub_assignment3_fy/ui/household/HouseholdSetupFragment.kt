package com.example.pantryhub_assignment3_fy.ui.household

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.FragmentHouseholdSetupBinding

class HouseholdSetupFragment : Fragment() {
    private var _binding: FragmentHouseholdSetupBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHouseholdSetupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.createHouseholdButton.setOnClickListener {
            findNavController().navigate(R.id.action_householdSetupFragment_to_createHouseholdFragment)
        }
        binding.joinHouseholdButton.setOnClickListener {
            findNavController().navigate(R.id.action_householdSetupFragment_to_joinHouseholdFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
