package com.example.pantryhub_assignment3_fy.ui.activity

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetActivityDateRangeBinding
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetFilterActivityBinding
import com.example.pantryhub_assignment3_fy.databinding.BottomSheetSortActivityBinding
import com.example.pantryhub_assignment3_fy.databinding.FragmentActivityBinding
import com.example.pantryhub_assignment3_fy.util.DateUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.snackbar.Snackbar
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/**
 * Shows household activity history with date range, filter, sort, and summary statistics.
 */
class ActivityFragment : Fragment() {
    private var _binding: FragmentActivityBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ActivityViewModel by viewModels()
    private val activityAdapter = ActivityAdapter()
    private var scrollToTopAfterNextListUpdate = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentActivityBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.activityRecyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = activityAdapter
        }
        binding.dateRangeButton.setOnClickListener { showDateRangeSheet() }
        binding.sortButton.setOnClickListener { showSortSheet() }
        binding.filterButton.setOnClickListener { showFilterSheet() }

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            render(state)
        }
    }

    /**
     * Binds the filtered ActivityUiState to cards, labels, chips, and the activity list.
     */
    private fun render(state: ActivityUiState) {
        binding.loadingIndicator.isVisible = state.isLoading
        binding.savedCountTextView.text = state.savedCount.toString()
        binding.wastedCountTextView.text = state.wastedCount.toString()
        binding.wasteRateTextView.text = "${state.wasteRate}%"
        binding.dateRangeButton.text = state.dateRangeLabel()
        binding.emptyTextView.isVisible = !state.isLoading && state.visibleLogs.isEmpty()
        activityAdapter.submitList(state.visibleLogs) {
            if (scrollToTopAfterNextListUpdate) {
                binding.activityRecyclerView.scrollToPosition(0)
                scrollToTopAfterNextListUpdate = false
            }
        }

        state.errorMessage?.let {
            Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
        }
    }

    /**
     * Opens the sort bottom sheet and scrolls the list back to the top after applying.
     */
    private fun showSortSheet() {
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetSortActivityBinding.inflate(layoutInflater)
        val currentState = viewModel.uiState.value ?: ActivityUiState()
        val current = currentState.selectedSort
        dialog.setContentView(sheetBinding.root)

        sheetBinding.sortRadioGroup.check(
            when (current) {
                ActivitySortOption.NEWEST_FIRST -> R.id.newestRadioButton
                ActivitySortOption.OLDEST_FIRST -> R.id.oldestRadioButton
                ActivitySortOption.XP_GAINED_FIRST -> R.id.xpRadioButton
                ActivitySortOption.WASTED_FIRST -> R.id.wastedRadioButton
                ActivitySortOption.EXPIRED_FIRST -> R.id.expiredRadioButton
            }
        )
        sheetBinding.cancelButton.setOnClickListener { dialog.dismiss() }
        sheetBinding.applyButton.setOnClickListener {
            val option = when (sheetBinding.sortRadioGroup.checkedRadioButtonId) {
                R.id.oldestRadioButton -> ActivitySortOption.OLDEST_FIRST
                R.id.xpRadioButton -> ActivitySortOption.XP_GAINED_FIRST
                R.id.wastedRadioButton -> ActivitySortOption.WASTED_FIRST
                R.id.expiredRadioButton -> ActivitySortOption.EXPIRED_FIRST
                else -> ActivitySortOption.NEWEST_FIRST
            }
            scrollToTopAfterNextListUpdate = true
            viewModel.sort(option)
            dialog.dismiss()
        }

        dialog.show()
    }

    /**
     * Opens the activity-type filter sheet.
     */
    private fun showFilterSheet() {
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetFilterActivityBinding.inflate(layoutInflater)
        val currentState = viewModel.uiState.value ?: ActivityUiState()
        dialog.setContentView(sheetBinding.root)

        sheetBinding.activityTypeChipGroup.check(filterChipId(currentState.selectedFilter))
        sheetBinding.applyButton.setOnClickListener {
            scrollToTopAfterNextListUpdate = true
            viewModel.filter(filterFromChipId(sheetBinding.activityTypeChipGroup.checkedChipId))
            dialog.dismiss()
        }
        sheetBinding.clearButton.setOnClickListener {
            scrollToTopAfterNextListUpdate = true
            viewModel.filter(ActivityFilter.ALL)
            dialog.dismiss()
        }

        dialog.show()
    }

    /**
     * Opens the date range sheet, including optional custom start/end dates.
     */
    private fun showDateRangeSheet() {
        val dialog = BottomSheetDialog(requireContext())
        val sheetBinding = BottomSheetActivityDateRangeBinding.inflate(layoutInflater)
        val currentState = viewModel.uiState.value ?: ActivityUiState()
        dialog.setContentView(sheetBinding.root)

        sheetBinding.dateRangeRadioGroup.check(
            when (currentState.selectedDateRange) {
                ActivityDateRange.TODAY -> R.id.todayRadioButton
                ActivityDateRange.LAST_7_DAYS -> R.id.lastSevenDaysRadioButton
                ActivityDateRange.LAST_30_DAYS -> R.id.lastThirtyDaysRadioButton
                ActivityDateRange.CUSTOM -> R.id.customRangeRadioButton
                ActivityDateRange.ALL_TIME -> R.id.allTimeRadioButton
            }
        )
        currentState.customStartDate?.let { sheetBinding.startDateEditText.setText(DateUtils.formatInputDate(it)) }
        currentState.customEndDate?.let { sheetBinding.endDateEditText.setText(DateUtils.formatInputDate(it)) }

        fun updateCustomFieldsVisibility() {
            sheetBinding.customDateContainer.isVisible =
                sheetBinding.dateRangeRadioGroup.checkedRadioButtonId == R.id.customRangeRadioButton
        }
        updateCustomFieldsVisibility()
        sheetBinding.dateRangeRadioGroup.setOnCheckedChangeListener { _, _ -> updateCustomFieldsVisibility() }
        sheetBinding.startDateEditText.setOnClickListener {
            showDatePicker { sheetBinding.startDateEditText.setText(DateUtils.formatInputDate(it)) }
        }
        sheetBinding.endDateEditText.setOnClickListener {
            showDatePicker { sheetBinding.endDateEditText.setText(DateUtils.formatInputDate(it)) }
        }
        sheetBinding.cancelButton.setOnClickListener { dialog.dismiss() }
        sheetBinding.applyButton.setOnClickListener {
            sheetBinding.startDateLayout.error = null
            sheetBinding.endDateLayout.error = null
            val dateRange = when (sheetBinding.dateRangeRadioGroup.checkedRadioButtonId) {
                R.id.todayRadioButton -> ActivityDateRange.TODAY
                R.id.lastSevenDaysRadioButton -> ActivityDateRange.LAST_7_DAYS
                R.id.customRangeRadioButton -> ActivityDateRange.CUSTOM
                R.id.allTimeRadioButton -> ActivityDateRange.ALL_TIME
                else -> ActivityDateRange.LAST_30_DAYS
            }
            val customStartDate = sheetBinding.startDateEditText.text.toString().toDateMillisOrNull()
            val customEndDate = sheetBinding.endDateEditText.text.toString().toDateMillisOrNull()

            if (dateRange == ActivityDateRange.CUSTOM) {
                when {
                    customStartDate == null -> {
                        sheetBinding.startDateLayout.error = "Choose a start date."
                        return@setOnClickListener
                    }
                    customEndDate == null -> {
                        sheetBinding.endDateLayout.error = "Choose an end date."
                        return@setOnClickListener
                    }
                    customEndDate < customStartDate -> {
                        sheetBinding.endDateLayout.error = "End date cannot be before start date."
                        return@setOnClickListener
                    }
                }
            }

            // The header date range controls only the activity period; sorting remains in its own sheet.
            scrollToTopAfterNextListUpdate = true
            viewModel.dateRange(dateRange, customStartDate, customEndDate)
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showDatePicker(onSelected: (Long) -> Unit) {
        val picker = MaterialDatePicker.Builder.datePicker()
            .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
            .build()

        picker.addOnPositiveButtonClickListener { utcMillis ->
            // Activity filters store local start-of-day millis so selected ranges include the whole chosen day.
            val selectedDate = Instant.ofEpochMilli(utcMillis)
                .atZone(ZoneOffset.UTC)
                .toLocalDate()
            onSelected(selectedDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli())
        }
        picker.show(parentFragmentManager, "activity_date_picker")
    }

    private fun String.toDateMillisOrNull(): Long? {
        return takeIf { it.isNotBlank() }?.let {
            runCatching { DateUtils.parseInputDate(it) }.getOrNull()
        }
    }

    private fun ActivityUiState.dateRangeLabel(): String {
        val today = LocalDate.now()
        val dates = when (selectedDateRange) {
            ActivityDateRange.ALL_TIME -> return getString(R.string.all_time)
            ActivityDateRange.TODAY -> today to today
            ActivityDateRange.LAST_7_DAYS -> today.minusDays(6) to today
            ActivityDateRange.LAST_30_DAYS -> today.minusDays(29) to today
            ActivityDateRange.CUSTOM -> {
                val start = customStartDate?.toLocalDate() ?: today.minusDays(29)
                val end = customEndDate?.toLocalDate() ?: today
                start to end
            }
        }
        return "${dates.first.toShortLabel()} - ${dates.second.toShortLabel()}"
    }

    private fun Long.toLocalDate(): LocalDate {
        return Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()
    }

    private fun LocalDate.toShortLabel(): String {
        // The activity header mirrors the compact date-range style in the reference image.
        return format(DateTimeFormatter.ofPattern("dd MMM yy"))
    }

    private fun filterChipId(filter: ActivityFilter): Int {
        return when (filter) {
            ActivityFilter.ADDED_FOOD -> R.id.addedFoodChip
            ActivityFilter.USED -> R.id.usedChip
            ActivityFilter.WASTED -> R.id.wastedChip
            ActivityFilter.RESTOCKED -> R.id.restockedChip
            ActivityFilter.ADDED_SHOPPING_ITEM -> R.id.addedShoppingChip
            ActivityFilter.BOUGHT_SHOPPING_ITEM -> R.id.boughtShoppingChip
            ActivityFilter.DELETED_FOOD -> R.id.deletedFoodChip
            ActivityFilter.ALL -> R.id.allChip
        }
    }

    private fun filterFromChipId(chipId: Int): ActivityFilter {
        return when (chipId) {
            R.id.addedFoodChip -> ActivityFilter.ADDED_FOOD
            R.id.usedChip -> ActivityFilter.USED
            R.id.wastedChip -> ActivityFilter.WASTED
            R.id.restockedChip -> ActivityFilter.RESTOCKED
            R.id.addedShoppingChip -> ActivityFilter.ADDED_SHOPPING_ITEM
            R.id.boughtShoppingChip -> ActivityFilter.BOUGHT_SHOPPING_ITEM
            R.id.deletedFoodChip -> ActivityFilter.DELETED_FOOD
            else -> ActivityFilter.ALL
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
