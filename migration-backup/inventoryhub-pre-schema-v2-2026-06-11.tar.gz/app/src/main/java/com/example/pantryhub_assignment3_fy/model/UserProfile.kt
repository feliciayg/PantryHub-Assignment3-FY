package com.example.pantryhub_assignment3_fy.model

import com.google.firebase.Timestamp

data class UserProfile(
    val userId: String = "",
    val username: String = "",
    val displayName: String = "",
    val createdAt: Timestamp? = null,
    val currentHouseholdId: String? = null
)
