package com.example.pantryhub_assignment3_fy.ui.storage

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.databinding.ItemFoodBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.util.DateUtils
import com.example.pantryhub_assignment3_fy.util.loadFoodImage

class FoodAdapter(
    private val onClick: (FoodItem) -> Unit,
    private val onUsed: (FoodItem) -> Unit,
    private val onShop: (FoodItem) -> Unit,
    private val onEdit: (FoodItem) -> Unit,
    private val onDelete: (FoodItem) -> Unit
) : ListAdapter<FoodItem, FoodAdapter.FoodViewHolder>(FoodDiffCallback) {
    private var openFoodId: String? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val binding = ItemFoodBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FoodViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        holder.bind(
            food = getItem(position),
            isOpen = getItem(position).id == openFoodId,
            onClick = { food -> closeOpenItem(); onClick(food) },
            onUsed = { food -> closeOpenItem(); onUsed(food) },
            onShop = { food -> closeOpenItem(); onShop(food) },
            onEdit = { food -> closeOpenItem(); onEdit(food) },
            onDelete = { food -> closeOpenItem(); onDelete(food) },
            onOpened = { food -> setOpenFood(food.id) },
            onClosed = { food -> if (openFoodId == food.id) openFoodId = null }
        )
    }

    override fun onViewRecycled(holder: FoodViewHolder) {
        holder.closeActions(animate = false)
        super.onViewRecycled(holder)
    }

    fun closeOpenItem(): Boolean {
        val openedId = openFoodId ?: return false
        val index = currentList.indexOfFirst { it.id == openedId }
        openFoodId = null
        if (index != -1) notifyItemChanged(index)
        return true
    }

    fun setOpenFood(foodId: String) {
        val previousId = openFoodId
        openFoodId = foodId
        if (previousId != null && previousId != foodId) {
            val previousIndex = currentList.indexOfFirst { it.id == previousId }
            if (previousIndex != -1) notifyItemChanged(previousIndex)
        }
    }

    class FoodViewHolder(
        private val binding: ItemFoodBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        val foregroundView: View get() = binding.foodCard
        private var isRevealed = false

        fun bind(
            food: FoodItem,
            isOpen: Boolean,
            onClick: (FoodItem) -> Unit,
            onUsed: (FoodItem) -> Unit,
            onShop: (FoodItem) -> Unit,
            onEdit: (FoodItem) -> Unit,
            onDelete: (FoodItem) -> Unit,
            onOpened: (FoodItem) -> Unit,
            onClosed: (FoodItem) -> Unit
        ) {
            val context = binding.root.context
            val status = runCatching { FoodStatus.valueOf(food.status) }.getOrDefault(FoodStatus.FRESH)
            binding.nameTextView.text = food.name
            binding.categoryTextView.text = food.category
            binding.quantityTextView.text = "${formatQuantity(food.quantity)} ${food.unit} Left"
            binding.expiryTextView.text = "Expires ${DateUtils.formatDisplayDate(food.expiryDate)}"
            binding.countdownTextView.text = DateUtils.countdownText(food.expiryDate)
            binding.countdownTextView.setTextColor(ContextCompat.getColor(context, colorForStatus(status)))
            binding.statusBorder.setBackgroundColor(ContextCompat.getColor(context, colorForStatus(status)))
            binding.foodImageView.loadFoodImage(food.imageUrl)

            if (isOpen) revealActions(animate = false) else closeActions(animate = false)

            binding.foodCard.setOnClickListener {
                if (isRevealed) {
                    closeActions()
                    onClosed(food)
                } else {
                    onClick(food)
                }
            }
            binding.usedAction.setOnClickListener { onUsed(food) }
            binding.shopAction.setOnClickListener { onShop(food) }
            binding.editAction.setOnClickListener { onEdit(food) }
            binding.deleteAction.setOnClickListener { onDelete(food) }

            binding.foodCard.setOnTouchListener { _, _ ->
                if (isRevealed) onOpened(food)
                false
            }
        }

        fun setSwipeOffset(offset: Float) {
            val clampedOffset = offset.coerceIn(-revealWidth(), 0f)
            binding.swipeActionContainer.isVisible = clampedOffset < 0f
            binding.foodCard.translationX = clampedOffset
            isRevealed = clampedOffset < 0f
        }

        fun settleSwipe(food: FoodItem, onOpened: (FoodItem) -> Unit, onClosed: (FoodItem) -> Unit) {
            // The card snaps open only after a meaningful left drag, matching Gmail-style reveal behavior.
            if (kotlin.math.abs(binding.foodCard.translationX) > revealWidth() * 0.35f) {
                revealActions()
                onOpened(food)
            } else {
                closeActions()
                onClosed(food)
            }
        }

        fun revealActions(animate: Boolean = true) {
            isRevealed = true
            binding.swipeActionContainer.isVisible = true
            moveForegroundTo(-revealWidth(), animate)
        }

        fun closeActions(animate: Boolean = true) {
            isRevealed = false
            moveForegroundTo(0f, animate)
        }

        private fun moveForegroundTo(targetTranslation: Float, animate: Boolean) {
            binding.foodCard.animate().cancel()
            if (animate) {
                binding.foodCard.animate()
                    .translationX(targetTranslation)
                    .setDuration(160L)
                    .withEndAction {
                        binding.swipeActionContainer.isVisible = targetTranslation < 0f
                    }
                    .start()
            } else {
                binding.foodCard.translationX = targetTranslation
                binding.swipeActionContainer.isVisible = targetTranslation < 0f
            }
        }

        private fun revealWidth(): Float {
            val actionWidth = binding.root.resources.getDimensionPixelSize(R.dimen.food_swipe_action_width)
            return actionWidth * 4f
        }

        private fun colorForStatus(status: FoodStatus): Int {
            return when (status) {
                FoodStatus.EXPIRED, FoodStatus.USE_TODAY -> R.color.status_expired
                FoodStatus.EXPIRING_SOON -> R.color.status_expiring
                FoodStatus.LOW_STOCK -> R.color.status_low_stock
                FoodStatus.FRESH -> R.color.status_fresh
                FoodStatus.USED, FoodStatus.WASTED -> R.color.pantry_text_secondary
            }
        }

        private fun formatQuantity(value: Double): String {
            return if (value % 1.0 == 0.0) value.toInt().toString() else value.toString()
        }
    }

    object FoodDiffCallback : DiffUtil.ItemCallback<FoodItem>() {
        override fun areItemsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean = oldItem == newItem
    }
}
