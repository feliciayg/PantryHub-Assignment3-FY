package com.example.pantryhub_assignment3_fy.ui.shopping

import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.ShoppingItem

data class ShoppingUiState(
    val isLoading: Boolean = true,
    val shoppingItems: List<ShoppingItem> = emptyList(),
    val activeItems: List<ShoppingItem> = emptyList(),
    val boughtItems: List<ShoppingItem> = emptyList(),
    val suggestedFoods: List<FoodItem> = emptyList(),
    val selectedFilter: ShoppingFilter = ShoppingFilter.ALL,
    val searchQuery: String = "",
    val errorMessage: String? = null,
    val successMessage: String? = null
)

data class ShoppingFormData(
    val id: String = "",
    val name: String = "",
    val quantity: Double = 0.0,
    val unit: String = "",
    val sourceFoodItemId: String? = null
)

enum class ShoppingFilter(val label: String) {
    ALL("All"),
    TO_BUY("To Order"),
    BOUGHT("Received"),
    LOW_STOCK("Low Stock")
}
