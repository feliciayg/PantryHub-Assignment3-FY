package com.example.pantryhub_assignment3_fy.ui.household

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantryhub_assignment3_fy.data.repository.HouseholdRepository
import com.example.pantryhub_assignment3_fy.util.UiState
import kotlinx.coroutines.launch

/**
 * ViewModel for creating or joining a store/team after login/sign-up.
 */
class HouseholdViewModel(
    private val householdRepository: HouseholdRepository = HouseholdRepository()
) : ViewModel() {
    private val _householdState = MutableLiveData<UiState<String>>(UiState.Idle)
    val householdState: LiveData<UiState<String>> = _householdState

    /**
     * Creates a store/team and links it to the current user profile.
     */
    fun createHousehold(name: String) {
        viewModelScope.launch {
            _householdState.value = UiState.Loading
            // Creating a store/team links the signed-in user as owner before the app opens the main tabs.
            householdRepository.createHousehold(name)
                .onSuccess { _householdState.value = UiState.Success(it) }
                .onFailure { _householdState.value = UiState.Error(it.toFriendlyMessage("Could not create store.")) }
        }
    }

    /**
     * Joins the store/team that matches the entered invite code.
     */
    fun joinHousehold(inviteCode: String) {
        viewModelScope.launch {
            _householdState.value = UiState.Loading
            // Joining uses the invite code to find a shared store/team and add the user as a staff member.
            householdRepository.joinHousehold(inviteCode)
                .onSuccess { _householdState.value = UiState.Success(it) }
                .onFailure { _householdState.value = UiState.Error(it.toFriendlyMessage("Could not join store.")) }
        }
    }

    /**
     * Converts repository exceptions into short form-friendly messages.
     */
    private fun Throwable.toFriendlyMessage(fallback: String): String {
        val rawMessage = message.orEmpty()
        return if (rawMessage.contains("Default FirebaseApp is not initialized")) {
            "Firebase is not configured yet. Add google-services.json before testing store/team actions."
        } else {
            rawMessage.ifBlank { fallback }
        }
    }
}
