package com.example.pantryhub_assignment3_fy.ui.storage

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.pantryhub_assignment3_fy.R
import com.example.pantryhub_assignment3_fy.data.repository.ShoppingRepository
import com.example.pantryhub_assignment3_fy.databinding.FragmentAddEditFoodBinding
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.util.DateUtils
import com.example.pantryhub_assignment3_fy.util.loadFoodImage
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.temporal.ChronoUnit

/**
 * Shared form for adding stock, editing stock, and storing received restock items.
 */
class AddEditFoodFragment : Fragment() {
    private var _binding: FragmentAddEditFoodBinding? = null
    private val binding get() = _binding!!
    private val viewModel: StorageViewModel by activityViewModels()
    private val shoppingRepository = ShoppingRepository()
    private var mode: String = MODE_ADD
    private var foodId: String? = null
    private var sourceShoppingItemId: String? = null
    private var saveInProgress = false
    private var selectedImageUri: String = ""
    private var syncingShelfLifeDates = false
    private val photoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { handleSelectedImage(it) }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddEditFoodBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        mode = arguments?.getString(ARG_MODE) ?: MODE_ADD
        foodId = arguments?.getString(ARG_FOOD_ID)
        sourceShoppingItemId = arguments?.getString(ARG_SOURCE_SHOPPING_ITEM_ID)
        val restoredImageUri = savedInstanceState?.getString(KEY_SELECTED_IMAGE_URI)
        setupToolbar()
        setupDropdowns()
        setupDatePickers()
        setupShelfLifeControls()
        setupMode()
        if (restoredImageUri != null) {
            selectedImageUri = restoredImageUri
            renderSelectedImage()
        }
        binding.photoButton.setOnClickListener { openPhotoPicker() }
        binding.saveButton.setOnClickListener { saveFood() }
        binding.cancelButton.setOnClickListener { findNavController().popBackStack() }

        viewModel.uiState.observe(viewLifecycleOwner) { state ->
            state.errorMessage?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_LONG).show()
                saveInProgress = false
                viewModel.clearMessages()
            }
            state.successMessage?.let {
                if (saveInProgress) {
                    saveInProgress = false
                    Snackbar.make(binding.root, it, Snackbar.LENGTH_SHORT).show()
                    viewModel.clearMessages()
                    markSourceShoppingItemStoredIfNeeded()
                }
            }
        }
    }

    // Saves the selected image URI across configuration changes before the stock item is saved.
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_SELECTED_IMAGE_URI, selectedImageUri)
    }

    // Opens Android's document picker so the user can choose a persistent food photo.
    private fun openPhotoPicker() {
        photoPicker.launch(arrayOf("image/*"))
    }

    // Stores read access for the selected image and updates the form preview immediately.
    private fun handleSelectedImage(uri: Uri) {
        persistImageReadPermission(uri)
        selectedImageUri = uri.toString()
        renderSelectedImage()
    }

    // Keeps permission to read the selected image after the picker activity closes.
    private fun persistImageReadPermission(uri: Uri) {
        runCatching {
            requireContext().contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    // Refreshes the photo preview and button text based on whether an image has been selected.
    private fun renderSelectedImage() {
        binding.foodPhotoImageView.loadFoodImage(selectedImageUri, R.drawable.ic_camera)
        binding.photoButton.text = if (selectedImageUri.isBlank()) {
            getString(R.string.add_photo)
        } else {
            getString(R.string.change_photo)
        }
    }

    private fun setupToolbar() {
        binding.editToolbar.setNavigationIcon(R.drawable.ic_back)
        binding.editToolbar.setNavigationOnClickListener { findNavController().popBackStack() }
    }

    private fun setupDropdowns() {
        // These controlled dropdowns keep saved values identical to filter values used by Storage/Home.
        binding.categoryEditText.setAdapter(dropdownAdapter(categoryDropdownOptions()))
        binding.locationEditText.setAdapter(dropdownAdapter(locationDropdownOptions()))
        binding.unitEditText.setAdapter(dropdownAdapter(FilterOptions.units))
    }

    private fun dropdownAdapter(options: List<String>): ArrayAdapter<String> {
        return ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, options)
    }

    /**
     * Decides whether this screen is Add, Edit, or Add-from-Shopping mode.
     */
    private fun setupMode() {
        if (mode == MODE_EDIT) {
            binding.editToolbar.title = getString(R.string.edit_food)
            binding.saveButton.text = getString(R.string.save_changes)
            binding.cancelButton.isVisible = true
            val existing = foodId?.let { viewModel.findFood(it) }
            if (existing != null) fillForm(existing) else Snackbar.make(binding.root, "Stock item is still loading.", Snackbar.LENGTH_SHORT).show()
        } else {
            binding.editToolbar.title = getString(R.string.add_food)
            binding.saveButton.text = getString(R.string.save_food)
            binding.addedDateEditText.setText(DateUtils.formatInputDate(DateUtils.todayMillis()))
            binding.reminderCheckBox.isChecked = false
            binding.thresholdEditText.setText("1")
            binding.categoryEditText.setText("Other", false)
            binding.locationEditText.setText("Inventory", false)
            binding.unitEditText.setText("pack", false)
            binding.shelfLifeUnitEditText.setText(SHELF_LIFE_DAYS, false)
            renderSelectedImage()
            applyShoppingPrefill()
        }
    }

    private fun applyShoppingPrefill() {
        val name = arguments?.getString(ARG_PREFILL_NAME).orEmpty()
        val quantity = arguments?.getString(ARG_PREFILL_QUANTITY).orEmpty().toDoubleOrNull() ?: 0.0
        val unit = arguments?.getString(ARG_PREFILL_UNIT).orEmpty()

        if (name.isNotBlank()) binding.nameEditText.setText(name)
        if (quantity > 0.0) binding.quantityEditText.setText(quantity.toCleanString())
        if (unit.isNotBlank() && unit in FilterOptions.units) binding.unitEditText.setText(unit, false)
    }

    /**
     * Connects added/expiry date fields to Material date pickers.
     */
    private fun setupDatePickers() {
        binding.addedDateEditText.setOnClickListener {
            showDatePicker {
                binding.addedDateEditText.setText(DateUtils.formatInputDate(it))
                updateExpiryDateFromShelfLife()
            }
        }
        binding.expiryDateEditText.setOnClickListener {
            showDatePicker {
                binding.expiryDateEditText.setText(DateUtils.formatInputDate(it))
                updateShelfLifeFromDates()
            }
        }
    }

    private fun setupShelfLifeControls() {
        binding.shelfLifeUnitEditText.setAdapter(dropdownAdapter(SHELF_LIFE_UNITS))
        binding.shelfLifeUnitEditText.setText(SHELF_LIFE_DAYS, false)
        binding.shelfLifeEditText.addTextChangedListener(simpleTextWatcher {
            updateExpiryDateFromShelfLife()
        })
        binding.shelfLifeUnitEditText.setOnItemClickListener { _, _, _, _ ->
            updateExpiryDateFromShelfLife()
        }
    }

    private fun simpleTextWatcher(afterChanged: () -> Unit): TextWatcher {
        return object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) = afterChanged()
        }
    }

    private fun showDatePicker(onSelected: (Long) -> Unit) {
        val picker = MaterialDatePicker.Builder.datePicker()
            .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
            .build()

        picker.addOnPositiveButtonClickListener { utcMillis ->
            // MaterialDatePicker returns UTC-day millis; convert it back to local start-of-day millis for FoodItem.
            val selectedDate = Instant.ofEpochMilli(utcMillis)
                .atZone(ZoneOffset.UTC)
                .toLocalDate()
            onSelected(selectedDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli())
        }
        picker.show(parentFragmentManager, "food_date_picker")
    }

    private fun fillForm(food: FoodItem) {
        binding.nameEditText.setText(food.name)
        binding.categoryEditText.setText(food.category, false)
        binding.locationEditText.setText(food.storageLocation, false)
        binding.quantityEditText.setText(food.quantity.toCleanString())
        binding.unitEditText.setText(food.unit, false)
        binding.thresholdEditText.setText(food.lowStockThreshold.toCleanString())
        binding.addedDateEditText.setText(DateUtils.formatInputDate(food.addedDate))
        binding.expiryDateEditText.setText(DateUtils.formatInputDate(food.expiryDate))
        binding.shelfLifeEditText.setText(food.shelfLifeDays.toString())
        binding.shelfLifeUnitEditText.setText(SHELF_LIFE_DAYS, false)
        binding.reminderCheckBox.isChecked = food.reminderDaysBefore > 0
        binding.notesEditText.setText(food.notes)
        binding.supplierNameEditText.setText(food.supplierName)
        binding.supplierPhoneEditText.setText(food.supplierPhone)
        binding.supplierEmailEditText.setText(food.supplierEmail)
        selectedImageUri = food.imageUrl
        renderSelectedImage()
    }

    /**
     * Builds and validates the form, then routes to add, edit, or duplicate-merge logic.
     */
    private fun saveFood() {
        clearErrors()
        val form = buildForm() ?: return
        if (mode == MODE_EDIT) {
            saveInProgress = true
            viewModel.updateFood(requireContext().applicationContext, form)
        } else {
            val duplicateFood = viewModel.findExactDuplicateForAdd(form)
            if (duplicateFood == null) {
                addFoodAsNewItem(form)
            } else {
                showDuplicateFoodDialog(duplicateFood, form)
            }
        }
    }

    private fun showDuplicateFoodDialog(existingFood: FoodItem, form: FoodFormData) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(getString(R.string.duplicate_food_title))
            .setMessage(getString(R.string.duplicate_food_message, existingFood.name))
            .setPositiveButton(R.string.add_to_existing) { _, _ ->
                mergeWithExistingFood(existingFood, form)
            }
            .setNegativeButton(R.string.save_separate) { _, _ ->
                addFoodAsNewItem(form)
            }
            .setNeutralButton(R.string.cancel, null)
            .show()
    }

    private fun addFoodAsNewItem(form: FoodFormData) {
        saveInProgress = true
        viewModel.addFood(
            requireContext().applicationContext,
            form,
            restockedFromShopping = !sourceShoppingItemId.isNullOrBlank()
        )
    }

    private fun mergeWithExistingFood(existingFood: FoodItem, form: FoodFormData) {
        saveInProgress = true
        viewModel.mergeDuplicateFood(
            requireContext().applicationContext,
            existingFood,
            form,
            restockedFromShopping = !sourceShoppingItemId.isNullOrBlank()
        )
    }

    /**
     * Reads input fields into FoodFormData, returning null if validation fails.
     */
    private fun buildForm(): FoodFormData? {
        val name = binding.nameEditText.text.toString().trim()
        val category = binding.categoryEditText.text.toString().trim()
        val location = binding.locationEditText.text.toString().trim()
        val unit = binding.unitEditText.text.toString().trim()
        val quantity = binding.quantityEditText.text.toString().toDoubleOrNull()
        val threshold = binding.thresholdEditText.text.toString().toDoubleOrNull()
        val addedDateText = binding.addedDateEditText.text.toString()
        val expiryDateText = binding.expiryDateEditText.text.toString()
        val shelfLifeText = binding.shelfLifeEditText.text.toString()
        val shelfLifeUnit = binding.shelfLifeUnitEditText.text.toString().trim()
        // The form exposes reminders as a simple opt-in checkbox. Checked stores the fixed
        // reminder rule used by FoodReminderScheduler: 1 day before expiry at 9:00 AM.
        val reminder = if (binding.reminderCheckBox.isChecked) DEFAULT_REMINDER_DAYS_BEFORE else 0

        if (name.isBlank()) return errorOn(binding.nameLayout, "Stock item name is required.")
        if (category.isBlank()) return errorOn(binding.categoryLayout, "Category is required.")
        if (category !in categoryDropdownOptions()) return errorOn(binding.categoryLayout, "Choose a category from the list.")
        if (location.isBlank()) return errorOn(binding.locationLayout, "Storage location is required.")
        if (location !in locationDropdownOptions()) return errorOn(binding.locationLayout, "Choose a storage location from the list.")
        if (quantity == null || quantity < 0) return errorOn(binding.quantityLayout, "Quantity must be 0 or more.")
        if (unit.isBlank()) return errorOn(binding.unitLayout, "Unit is required.")
        if (unit !in FilterOptions.units) return errorOn(binding.unitLayout, "Choose a unit from the list.")
        if (threshold == null || threshold < 0) return errorOn(binding.thresholdLayout, "Threshold must be 0 or more.")
        if (addedDateText.isBlank()) return errorOn(binding.addedDateLayout, "Added date is required.")
        if (shelfLifeText.isNotBlank() && shelfLifeText.toIntOrNull() == null) return errorOn(binding.shelfLifeLayout, "Shelf life must be a whole number.")
        if (shelfLifeText.isNotBlank() && shelfLifeText.toInt() <= 0) return errorOn(binding.shelfLifeLayout, "Shelf life must be greater than 0.")
        if (shelfLifeText.isNotBlank() && shelfLifeUnit !in SHELF_LIFE_UNITS) return errorOn(binding.shelfLifeUnitLayout, "Choose a shelf life unit.")
        if (expiryDateText.isBlank()) return errorOn(binding.expiryDateLayout, "Expiry date is required.")
        val addedDate = runCatching { DateUtils.parseInputDate(addedDateText) }.getOrNull()
            ?: return errorOn(binding.addedDateLayout, "Use yyyy-MM-dd.")
        val expiryDate = runCatching { DateUtils.parseInputDate(expiryDateText) }.getOrNull()
            ?: return errorOn(binding.expiryDateLayout, "Use yyyy-MM-dd.")
        if (expiryDate < addedDate) return errorOn(binding.expiryDateLayout, "Expiry date cannot be before added date.")

        val shelfLife = DateUtils.daysBetween(addedDate, expiryDate)

        return FoodFormData(
            id = foodId.orEmpty(),
            name = name,
            category = category,
            storageLocation = location,
            quantity = quantity,
            unit = unit,
            lowStockThreshold = threshold,
            addedDate = addedDate,
            expiryDate = expiryDate,
            shelfLifeDays = shelfLife,
            reminderDaysBefore = reminder,
            notes = binding.notesEditText.text.toString(),
            supplierName = binding.supplierNameEditText.text.toString(),
            supplierPhone = binding.supplierPhoneEditText.text.toString(),
            supplierEmail = binding.supplierEmailEditText.text.toString(),
            imageUrl = selectedImageUri
        )
    }

    private fun <T> errorOn(layout: com.google.android.material.textfield.TextInputLayout, message: String): T? {
        layout.error = message
        return null
    }

    private fun clearErrors() {
        binding.nameLayout.error = null
        binding.categoryLayout.error = null
        binding.locationLayout.error = null
        binding.quantityLayout.error = null
        binding.unitLayout.error = null
        binding.thresholdLayout.error = null
        binding.addedDateLayout.error = null
        binding.expiryDateLayout.error = null
        binding.shelfLifeLayout.error = null
        binding.shelfLifeUnitLayout.error = null
    }

    /**
     * Calculates expiry date when the user edits shelf-life controls.
     */
    private fun updateExpiryDateFromShelfLife() {
        if (syncingShelfLifeDates) return
        val addedDate = binding.addedDateEditText.text.toString().toLocalDateOrNull() ?: return
        val shelfLifeAmount = binding.shelfLifeEditText.text.toString().toLongOrNull() ?: return
        val shelfLifeUnit = binding.shelfLifeUnitEditText.text.toString().trim().ifBlank { SHELF_LIFE_DAYS }
        if (shelfLifeAmount <= 0 || shelfLifeUnit !in SHELF_LIFE_UNITS) return

        syncingShelfLifeDates = true
        // Expiry date is derived from added date plus the selected shelf-life amount and unit.
        val expiryDate = addedDate.plusShelfLife(shelfLifeAmount, shelfLifeUnit)
        binding.expiryDateEditText.setText(DateUtils.formatInputDate(expiryDate.toStartOfDayMillis()))
        syncingShelfLifeDates = false
    }

    /**
     * Recalculates shelf-life days when the user edits the date fields directly.
     */
    private fun updateShelfLifeFromDates() {
        if (syncingShelfLifeDates) return
        val addedDate = binding.addedDateEditText.text.toString().toLocalDateOrNull() ?: return
        val expiryDate = binding.expiryDateEditText.text.toString().toLocalDateOrNull() ?: return
        val days = ChronoUnit.DAYS.between(addedDate, expiryDate)
        if (days < 0) return

        syncingShelfLifeDates = true
        // Manual expiry-date selection falls back to an exact day count because that is what FoodItem stores.
        binding.shelfLifeUnitEditText.setText(SHELF_LIFE_DAYS, false)
        binding.shelfLifeEditText.setText(days.toString())
        syncingShelfLifeDates = false
    }

    private fun LocalDate.plusShelfLife(amount: Long, unit: String): LocalDate {
        return when (unit) {
            SHELF_LIFE_WEEKS -> plusWeeks(amount)
            SHELF_LIFE_MONTHS -> plusMonths(amount)
            else -> plusDays(amount)
        }
    }

    private fun String.toLocalDateOrNull(): LocalDate? {
        return runCatching {
            Instant.ofEpochMilli(DateUtils.parseInputDate(this)).atZone(ZoneId.systemDefault()).toLocalDate()
        }.getOrNull()
    }

    private fun LocalDate.toStartOfDayMillis(): Long {
        return atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }

    private fun categoryDropdownOptions(): List<String> = FilterOptions.categories.filterNot { it == FilterOptions.ALL_CATEGORY }

    private fun locationDropdownOptions(): List<String> = FilterOptions.locations.filterNot { it == FilterOptions.ALL_LOCATION }

    private fun markSourceShoppingItemStoredIfNeeded() {
        val shoppingItemId = sourceShoppingItemId
        if (mode != MODE_ADD || shoppingItemId.isNullOrBlank()) {
            findNavController().popBackStack()
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            shoppingRepository.markStored(shoppingItemId)
                .onFailure {
                    Snackbar.make(binding.root, it.message ?: "Stock item saved, but restock item was not updated.", Snackbar.LENGTH_LONG).show()
                }
            findNavController().popBackStack()
        }
    }

    private fun Double.toCleanString(): String {
        return if (this % 1.0 == 0.0) toInt().toString() else toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val ARG_MODE = "mode"
        const val ARG_FOOD_ID = "foodId"
        const val ARG_PREFILL_NAME = "prefillName"
        const val ARG_PREFILL_QUANTITY = "prefillQuantity"
        const val ARG_PREFILL_UNIT = "prefillUnit"
        const val ARG_SOURCE_SHOPPING_ITEM_ID = "sourceShoppingItemId"
        const val MODE_ADD = "add"
        const val MODE_EDIT = "edit"
        private const val KEY_SELECTED_IMAGE_URI = "selectedImageUri"
        private const val SHELF_LIFE_DAYS = "days"
        private const val SHELF_LIFE_WEEKS = "weeks"
        private const val SHELF_LIFE_MONTHS = "months"
        private const val DEFAULT_REMINDER_DAYS_BEFORE = 1
        private val SHELF_LIFE_UNITS = listOf(SHELF_LIFE_DAYS, SHELF_LIFE_WEEKS, SHELF_LIFE_MONTHS)
    }
}
