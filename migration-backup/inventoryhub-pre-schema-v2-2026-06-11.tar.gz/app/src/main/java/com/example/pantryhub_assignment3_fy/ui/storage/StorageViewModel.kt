package com.example.pantryhub_assignment3_fy.ui.storage

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantryhub_assignment3_fy.data.repository.FoodRepository
import com.example.pantryhub_assignment3_fy.data.repository.ShoppingRepository
import com.example.pantryhub_assignment3_fy.model.FoodItem
import com.example.pantryhub_assignment3_fy.model.FoodStatus
import com.example.pantryhub_assignment3_fy.model.ShoppingItem
import com.example.pantryhub_assignment3_fy.model.ShoppingStatus
import com.example.pantryhub_assignment3_fy.ui.shopping.ShoppingSectionRules
import com.example.pantryhub_assignment3_fy.util.DateUtils
import com.example.pantryhub_assignment3_fy.util.update
import com.example.pantryhub_assignment3_fy.notification.FoodReminderScheduler
import kotlinx.coroutines.launch

/**
 * ViewModel for the Inventory page and stock detail/edit flows.
 *
 * It observes inventory items, applies local search/filter/sort, forwards CRUD
 * actions to FoodRepository, and keeps expiry reminders in sync after changes.
 */
class StorageViewModel(
    private val foodRepository: FoodRepository = FoodRepository(),
    private val shoppingRepository: ShoppingRepository = ShoppingRepository()
) : ViewModel() {
    private val _uiState = MutableLiveData(StorageUiState())
    val uiState: LiveData<StorageUiState> = _uiState

    init {
        observeFoods()
        observeShoppingItems()
    }

    private fun observeFoods() {
        viewModelScope.launch {
            // The repository emits live Firestore updates from the current store/team's foods collection.
            foodRepository.observeFoods().collect { result ->
                result
                    .onSuccess { foods ->
                        _uiState.update {
                            val next = it.copy(isLoading = false, foods = foods, errorMessage = null)
                            next.copy(
                                visibleFoods = applySearchFilterSort(next),
                                readyToStoreItems = deriveReadyToStoreItems(next)
                            )
                        }
                    }
                    .onFailure { throwable ->
                        _uiState.update {
                            it.copy(isLoading = false, errorMessage = throwable.message ?: "Could not load stock items.")
                        }
                    }
            }
        }
    }

    private fun observeShoppingItems() {
        viewModelScope.launch {
            // Restock data is observed here only for the Low Stock workflow: received items
            // should move out of Need to Restock and into the received inventory handoff.
            shoppingRepository.observeShoppingItems().collect { result ->
                result
                    .onSuccess { shoppingItems ->
                        _uiState.update {
                            val next = it.copy(shoppingItems = shoppingItems, errorMessage = null)
                            next.copy(
                                visibleFoods = applySearchFilterSort(next),
                                readyToStoreItems = deriveReadyToStoreItems(next)
                            )
                        }
                    }
                    .onFailure { throwable ->
                        _uiState.update {
                            it.copy(errorMessage = throwable.message ?: "Could not load ready-to-store items.")
                        }
                    }
            }
        }
    }

    /**
     * Applies a text search to the current Storage list.
     */
    fun search(query: String) {
        _uiState.update {
            val next = it.copy(searchQuery = query)
            next.copy(
                visibleFoods = applySearchFilterSort(next),
                readyToStoreItems = deriveReadyToStoreItems(next)
            )
        }
    }

    /**
     * Applies location, category, and status filters together.
     */
    fun filter(location: String, category: String, status: String) {
        _uiState.update {
            val next = it.copy(
                selectedLocation = location,
                selectedCategory = category,
                selectedStatus = status
            )
            next.copy(
                visibleFoods = applySearchFilterSort(next),
                readyToStoreItems = deriveReadyToStoreItems(next)
            )
        }
    }

    /**
     * Applies a local sort option to visible foods.
     */
    fun sort(sortOption: SortOption) {
        _uiState.update {
            val next = it.copy(sortOption = sortOption)
            next.copy(
                visibleFoods = applySearchFilterSort(next),
                readyToStoreItems = deriveReadyToStoreItems(next)
            )
        }
    }

    /**
     * Creates a new food item and schedules its expiry reminder if enabled.
     */
    fun addFood(context: Context, form: FoodFormData, restockedFromShopping: Boolean = false) {
        viewModelScope.launch {
            foodRepository.addFood(form.toFoodItem(), restockedFromShopping)
                .onSuccess { foodId ->
                    FoodReminderScheduler.schedule(context, form.toFoodItem().copy(id = foodId))
                    showSuccess("Stock item saved.")
                }
                .onFailure { showError(it.message ?: "Could not save stock item.") }
        }
    }

    /**
     * Adds quantity into an existing matching food instead of saving a duplicate item.
     */
    fun mergeDuplicateFood(context: Context, existingFood: FoodItem, form: FoodFormData, restockedFromShopping: Boolean = false) {
        viewModelScope.launch {
            foodRepository.mergeFoodQuantity(existingFood.id, form.quantity, restockedFromShopping)
                .onSuccess {
                    FoodReminderScheduler.schedule(context, existingFood.copy(quantity = existingFood.quantity + form.quantity))
                    showSuccess("Added quantity to existing ${existingFood.name}.")
                }
                .onFailure { showError(it.message ?: "Could not update existing stock item.") }
        }
    }

    /**
     * Updates an existing food and reschedules its expiry reminder.
     */
    fun updateFood(context: Context, form: FoodFormData) {
        viewModelScope.launch {
            foodRepository.updateFood(form.toFoodItem())
                .onSuccess {
                    FoodReminderScheduler.schedule(context, form.toFoodItem())
                    showSuccess("Stock item updated.")
                }
                .onFailure { showError(it.message ?: "Could not update stock item.") }
        }
    }

    /**
     * Deletes food and cancels any local reminder alarm for it.
     */
    fun deleteFood(context: Context, foodId: String) {
        viewModelScope.launch {
            foodRepository.deleteFood(foodId)
                .onSuccess {
                    FoodReminderScheduler.cancel(context, foodId)
                    showSuccess("Stock item deleted.")
                }
                .onFailure { showError(it.message ?: "Could not delete stock item.") }
        }
    }

    /**
     * Marks part or all of a food item as used.
     */
    fun markUsed(context: Context, foodId: String, quantityUsed: Double) {
        val existingFood = findFood(foodId)
        viewModelScope.launch {
            // Quantity used decreases the item; a fully consumed item becomes USED.
            foodRepository.markUsed(foodId, quantityUsed)
                .onSuccess {
                    updateReminderAfterQuantityChange(context, existingFood, quantityUsed)
                    showSuccess("Marked as used.")
                }
                .onFailure { showError(it.message ?: "Could not mark item as used.") }
        }
    }

    /**
     * Records waste quantity/reason and updates reminders if stock remains.
     */
    fun logWaste(context: Context, foodId: String, quantityWasted: Double, reason: String) {
        val existingFood = findFood(foodId)
        viewModelScope.launch {
            // Quantity wasted decreases the item and records the selected waste reason in notes for Step 2.
            foodRepository.logWaste(foodId, quantityWasted, reason)
                .onSuccess {
                    updateReminderAfterQuantityChange(context, existingFood, quantityWasted)
                    showSuccess("Waste logged.")
                }
                .onFailure { showError(it.message ?: "Could not log waste.") }
        }
    }

    /**
     * Creates a restock-list entry from a low-stock inventory item.
     */
    fun addFoodToShopping(food: FoodItem) {
        viewModelScope.launch {
            val quantityToBuy = food.lowStockThreshold.coerceAtLeast(1.0)
            shoppingRepository.addShoppingItem(food.name, quantityToBuy, food.unit, food.id)
                .onSuccess { showSuccess("${food.name} added to Restock.") }
                .onFailure { showError(it.message ?: "Could not add item to Restock.") }
        }
    }

    fun prepareInventoryCsvExport() {
        _uiState.update {
            it.copy(
                csvExportContent = StorageCsv.exportFoods(it.foods),
                successMessage = "Inventory CSV is ready to save."
            )
        }
    }

    fun clearCsvExportContent() {
        _uiState.update { it.copy(csvExportContent = null) }
    }

    fun clearCsvSummary() {
        _uiState.update { it.copy(csvSummaryTitle = null, csvSummaryMessage = null) }
    }

    fun importInventoryCsv(context: Context, csv: String) {
        viewModelScope.launch {
            val parsed = StorageCsv.parseRows(csv)
            if (parsed.errors.isNotEmpty()) {
                showError(parsed.errors.joinToString(separator = "\n"))
                return@launch
            }

            val existingFoods = currentState().foods.associateBy { it.id }
            var importedCount = 0
            var updatedCount = 0
            val rowErrors = mutableListOf<String>()

            parsed.rows.forEach { row ->
                val form = row.toFoodForm(existingFoods[row.value("id")])
                if (form == null) {
                    rowErrors += row.validationError()
                    return@forEach
                }

                // CSV import uses id-based matching only: matching ids update existing documents,
                // missing or unknown ids create new documents with generated Firestore ids.
                val existing = existingFoods[form.id]
                val result = if (existing != null) {
                    foodRepository.updateFood(form.toFoodItem())
                } else {
                    foodRepository.addFood(form.toFoodItem(), restockedFromShopping = false)
                }

                result
                    .onSuccess { value ->
                        val savedFood = if (existing != null) form.toFoodItem() else form.toFoodItem().copy(id = value as? String ?: "")
                        FoodReminderScheduler.schedule(context, savedFood)
                        if (existing != null) updatedCount++ else importedCount++
                    }
                    .onFailure { rowErrors += "Row ${row.rowNumber}: ${it.message ?: "Could not save row."}" }
            }

            showCsvSummary(
                title = "Inventory CSV import summary",
                message = buildCsvSummaryMessage(
                    counts = listOf(
                        "Created" to importedCount,
                        "Updated" to updatedCount,
                        "Skipped" to rowErrors.size,
                        "Errors" to rowErrors.size
                    ),
                    rowErrors = rowErrors
                )
            )
        }
    }

    fun importSalesCsv(csv: String) {
        viewModelScope.launch {
            val parsed = StorageCsv.parseSalesRows(csv)
            if (parsed.errors.isNotEmpty()) {
                showError(parsed.errors.joinToString(separator = "\n"))
                return@launch
            }

            val foods = currentState().foods
            val foodsById = foods.associateBy { it.id }
            val foodsByName = foods.groupBy { it.name.trim().lowercase() }
            var deductedCount = 0
            val rowErrors = mutableListOf<String>()

            parsed.rows.forEach { row ->
                val quantitySold = row.value("quantitysold").toDoubleOrNull()
                val itemId = row.value("itemid")
                val name = row.value("name")

                // Sales rows match by itemId first, then exact case-insensitive inventory name.
                val matchedFood = itemId.takeIf { it.isNotBlank() }?.let { foodsById[it] }
                    ?: name.takeIf { it.isNotBlank() }?.let { foodsByName[it.lowercase()]?.singleOrNull() }

                // Invalid or unmatched rows are skipped so one bad POS row cannot stop the full import.
                when {
                    itemId.isBlank() && name.isBlank() -> rowErrors += "Row ${row.rowNumber}: itemId or name is required."
                    quantitySold == null || quantitySold <= 0.0 -> rowErrors += "Row ${row.rowNumber}: quantitySold must be a positive number."
                    matchedFood == null -> rowErrors += "Row ${row.rowNumber}: no matching inventory item."
                    quantitySold > matchedFood.quantity -> rowErrors += "Row ${row.rowNumber}: quantitySold cannot reduce ${matchedFood.name} below 0."
                    else -> {
                        foodRepository.deductSalesImport(
                            matchedFood.id,
                            quantitySold,
                            row.value("note").ifBlank { row.value("solddate").takeIf { it.isNotBlank() }?.let { "soldDate: $it" }.orEmpty() }
                        )
                            .onSuccess { deductedCount++ }
                            .onFailure { rowErrors += "Row ${row.rowNumber}: ${it.message ?: "Could not deduct stock."}" }
                    }
                }
            }

            showCsvSummary(
                title = "Sales CSV import summary",
                message = buildCsvSummaryMessage(
                    counts = listOf(
                        "Deducted" to deductedCount,
                        "Skipped" to rowErrors.size,
                        "Errors" to rowErrors.size
                    ),
                    rowErrors = rowErrors
                )
            )
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }

    fun findFood(foodId: String): FoodItem? {
        return currentState().foods.firstOrNull { it.id == foodId }
    }

    /**
     * Checks whether the Add Food form exactly matches an existing pantry item.
     */
    fun findExactDuplicateForAdd(form: FoodFormData): FoodItem? {
        val newFood = form.toFoodItem()

        // A duplicate means the same pantry batch details, except quantity. Quantity is the
        // value the user may choose to merge into the existing card instead of creating another.
        return currentState().foods.firstOrNull { existing ->
            existing.quantity > 0.0 &&
                existing.name.normalizedName() == newFood.name.normalizedName() &&
                existing.category == newFood.category &&
                existing.storageLocation == newFood.storageLocation &&
                existing.unit == newFood.unit &&
                existing.lowStockThreshold == newFood.lowStockThreshold &&
                existing.addedDate == newFood.addedDate &&
                existing.expiryDate == newFood.expiryDate &&
                existing.shelfLifeDays == newFood.shelfLifeDays &&
                existing.reminderDaysBefore == newFood.reminderDaysBefore &&
                existing.notes.trim() == newFood.notes.trim() &&
                existing.imageUrl == newFood.imageUrl
        }
    }

    /**
     * Recreates local reminder alarms after the app has loaded the latest pantry data.
     */
    fun scheduleLoadedFoodReminders(context: Context) {
        FoodReminderScheduler.scheduleAll(context, currentState().foods)
    }

    private fun updateReminderAfterQuantityChange(context: Context, food: FoodItem?, quantityChanged: Double) {
        if (food == null) return
        val remainingQuantity = (food.quantity - quantityChanged).coerceAtLeast(0.0)

        // A food item with no remaining stock should not notify later. Partial usage/waste keeps
        // the same reminder date because the item still exists and can still expire.
        if (remainingQuantity <= 0.0) {
            FoodReminderScheduler.cancel(context, food.id)
        } else {
            FoodReminderScheduler.schedule(context, food.copy(quantity = remainingQuantity))
        }
    }

    private fun applySearchFilterSort(state: StorageUiState): List<FoodItem> {
        // Search, filter, and sort are applied locally so the UI can combine them without extra Firestore indexes.
        val activeFoods = state.foods.filter { it.shouldShowInStorage(state.selectedStatus) }
        val searched = activeFoods.filter { food ->
            state.searchQuery.isBlank() || food.name.contains(state.searchQuery, ignoreCase = true)
        }
        val filtered = searched
            .filter { state.selectedLocation == FilterOptions.ALL_LOCATION || it.storageLocation == state.selectedLocation }
            .filter { state.selectedCategory == FilterOptions.ALL_CATEGORY || it.category == state.selectedCategory }
            .filter { food ->
                food.matchesStatusFilter(state.selectedStatus)
            }

        return when (state.sortOption) {
            SortOption.EXPIRY_SOONEST -> filtered.sortedBy { it.expiryDate }
            SortOption.EXPIRY_LATEST -> filtered.sortedByDescending { it.expiryDate }
            SortOption.NAME_ASC -> filtered.sortedBy { it.name.lowercase() }
            SortOption.NAME_DESC -> filtered.sortedByDescending { it.name.lowercase() }
            SortOption.CATEGORY -> filtered.sortedWith(compareBy<FoodItem> { it.category }.thenBy { it.name })
            SortOption.QUANTITY_LOW -> filtered.sortedBy { it.quantity }
            SortOption.RECENTLY_ADDED -> filtered.sortedByDescending { it.createdAt }
        }
    }

    private fun deriveReadyToStoreItems(state: StorageUiState): List<ShoppingItem> {
        if (state.selectedStatus != FilterOptions.LOW_STOCK_STATUS) return emptyList()

        // Storage reuses the same Received rule as Restock so both pages show
        // the same items and users do not see different versions of the same workflow.
        return ShoppingSectionRules.boughtReadyToStoreItems(state.shoppingItems, state.searchQuery)
    }

    private fun FoodItem.shouldShowInStorage(selectedStatus: String): Boolean {
        // Fully consumed or fully wasted food stays in Firestore for history, but is hidden from the normal Storage list.
        val isArchivedZeroStock = quantity <= 0.0 &&
            (status == FoodStatus.USED.name || status == FoodStatus.WASTED.name)
        if (!isArchivedZeroStock) return true

        // Used-up food stays hidden normally, but Low Stock should reveal it as an out-of-stock
        // restock candidate. Wasted food only appears when explicitly filtering Wasted.
        return selectedStatus.toStatusName() == status ||
            (status == FoodStatus.USED.name && selectedStatus == FilterOptions.LOW_STOCK_STATUS)
    }

    private fun FoodItem.matchesStatusFilter(selectedStatus: String): Boolean {
        if (selectedStatus == FilterOptions.ALL_STATUS) return true

        // Low Stock is a quantity condition, not only a saved status. This keeps Storage aligned
        // with Home even when expiry urgency has priority over LOW_STOCK in FoodStatusCalculator.
        if (selectedStatus == FilterOptions.LOW_STOCK_STATUS) {
            return isRestockCandidate() && !hasActiveOrBoughtShoppingItem()
        }

        return status == selectedStatus.toStatusName()
    }

    private fun String.toStatusName(): String {
        return if (this == "Priority Today") FoodStatus.USE_TODAY.name else uppercase().replace(" ", "_")
    }

    private fun FoodItem.isRestockCandidate(): Boolean {
        val isFullyUsed = status == FoodStatus.USED.name && quantity <= 0.0
        val isActiveLowStock = status != FoodStatus.WASTED.name && quantity <= lowStockThreshold

        // Used-up food is hidden from normal Storage, but Low Stock can still treat it as
        // out-of-stock until it is added to Restock or received.
        return isFullyUsed || isActiveLowStock
    }

    private fun FoodItem.hasActiveOrBoughtShoppingItem(): Boolean {
        return currentState().shoppingItems
            .filter {
                it.status == ShoppingStatus.TO_ORDER.name ||
                    it.status == ShoppingStatus.ORDERED.name ||
                    it.status == ShoppingStatus.IN_TRANSIT.name ||
                    it.status == ShoppingStatus.RECEIVED.name
            }
            .any { it.matchesFood(this) }
    }

    private fun ShoppingItem.matchesFood(food: FoodItem): Boolean {
        val linkedToFood = !sourceFoodItemId.isNullOrBlank() && sourceFoodItemId == food.id
        val sameRestockName = name.normalizedName() == food.name.normalizedName()
        return linkedToFood || sameRestockName
    }

    private fun String.normalizedName(): String {
        val compactName = trim()
            .lowercase()
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // Match simple singular/plural food names so grape/grapes do not split the workflow.
        return compactName.split(" ").joinToString(" ") { word ->
            when {
                word.endsWith("ies") && word.length > 3 -> word.dropLast(3) + "y"
                word.endsWith("oes") && word.length > 3 -> word.dropLast(2)
                word.endsWith("ses") || word.endsWith("xes") || word.endsWith("ches") || word.endsWith("shes") -> word.dropLast(2)
                word.endsWith("s") && word.length > 1 -> word.dropLast(1)
                else -> word
            }
        }
    }

    private fun FoodFormData.toFoodItem(): FoodItem {
        return FoodItem(
            id = id,
            name = name.trim(),
            category = category,
            storageLocation = storageLocation,
            quantity = quantity,
            unit = unit,
            lowStockThreshold = lowStockThreshold,
            addedDate = addedDate,
            expiryDate = expiryDate,
            shelfLifeDays = shelfLifeDays.takeIf { it > 0 } ?: DateUtils.daysBetween(addedDate, expiryDate),
            reminderDaysBefore = reminderDaysBefore,
            notes = notes.trim(),
            supplierName = supplierName.trim(),
            supplierPhone = supplierPhone.trim(),
            supplierEmail = supplierEmail.trim(),
            imageUrl = imageUrl,
            status = FoodStatus.FRESH.name
        )
    }

    private fun CsvRow.toFoodForm(existing: FoodItem?): FoodFormData? {
        val name = value("name")
        val quantity = value("quantity").toDoubleOrNull()
        val unit = value("unit")
        val lowStockThreshold = value("lowstockthreshold").takeIf { it.isNotBlank() }?.toDoubleOrNull()
        val expiryDate = value("expirydate").takeIf { it.isNotBlank() }?.let {
            runCatching { DateUtils.parseInputDate(it) }.getOrNull()
        }

        // Row validation is intentionally strict for required numeric/date fields so bad CSV rows
        // are skipped instead of creating misleading stock records.
        if (name.isBlank() || quantity == null || quantity < 0.0 || unit.isBlank()) return null
        if (value("lowstockthreshold").isNotBlank() && lowStockThreshold == null) return null
        if (value("expirydate").isNotBlank() && expiryDate == null) return null

        val addedDate = existing?.addedDate?.takeIf { it > 0L } ?: DateUtils.todayMillis()
        val finalExpiryDate = expiryDate ?: existing?.expiryDate?.takeIf { it > 0L } ?: DateUtils.todayMillis()
        return FoodFormData(
            id = existing?.id.orEmpty(),
            name = name,
            category = value("category").ifBlank { existing?.category ?: "Other" },
            storageLocation = value("storagelocation").ifBlank { existing?.storageLocation ?: "Inventory" },
            quantity = quantity,
            unit = unit,
            lowStockThreshold = lowStockThreshold ?: existing?.lowStockThreshold ?: 1.0,
            addedDate = addedDate,
            expiryDate = finalExpiryDate,
            shelfLifeDays = DateUtils.daysBetween(addedDate, finalExpiryDate),
            reminderDaysBefore = existing?.reminderDaysBefore ?: 0,
            notes = value("notes").ifBlank { existing?.notes.orEmpty() },
            supplierName = value("suppliername").ifBlank { existing?.supplierName.orEmpty() },
            supplierPhone = value("supplierphone").ifBlank { existing?.supplierPhone.orEmpty() },
            supplierEmail = value("supplieremail").ifBlank { existing?.supplierEmail.orEmpty() },
            imageUrl = existing?.imageUrl.orEmpty()
        )
    }

    private fun CsvRow.validationError(): String {
        return when {
            value("name").isBlank() -> "Row $rowNumber: name is required."
            value("quantity").toDoubleOrNull() == null -> "Row $rowNumber: quantity must be a number."
            value("quantity").toDoubleOrNull()?.let { it < 0.0 } == true -> "Row $rowNumber: quantity must be 0 or more."
            value("unit").isBlank() -> "Row $rowNumber: unit is required."
            value("lowstockthreshold").isNotBlank() && value("lowstockthreshold").toDoubleOrNull() == null -> "Row $rowNumber: lowStockThreshold must be a number."
            value("expirydate").isNotBlank() && runCatching { DateUtils.parseInputDate(value("expirydate")) }.isFailure -> "Row $rowNumber: expiryDate must be yyyy-MM-dd."
            else -> "Row $rowNumber: could not import row."
        }
    }

    private fun showSuccess(message: String) {
        _uiState.update { it.copy(successMessage = message) }
    }

    private fun showError(message: String) {
        _uiState.update { it.copy(errorMessage = message) }
    }

    private fun showCsvSummary(title: String, message: String) {
        _uiState.update { it.copy(csvSummaryTitle = title, csvSummaryMessage = message) }
    }

    private fun buildCsvSummaryMessage(counts: List<Pair<String, Int>>, rowErrors: List<String>): String {
        val summary = counts.joinToString(separator = "\n") { "${it.first}: ${it.second}" }
        val sampleErrors = rowErrors.take(5)
        return if (sampleErrors.isEmpty()) {
            summary
        } else {
            "$summary\n\nFirst issues:\n${sampleErrors.joinToString(separator = "\n")}"
        }
    }

    private fun currentState(): StorageUiState = _uiState.value ?: StorageUiState()
}
